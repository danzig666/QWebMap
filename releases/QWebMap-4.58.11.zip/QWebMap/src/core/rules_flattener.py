"""
rules_flattener.py

RulesFlattener — walks every visible vector layer in the current QGIS project,
converts any non-rule-based renderer / labeling system to rule-based, then
recursively flattens the rule hierarchy with full property inheritance
(scale range, filter expression, symbol layers).

Depends on: config, zoom_levels, flattened_rule
"""

import html
import math
import re
from typing import Dict, List, Optional, Union

from qgis.core import (
    Qgis,
    QgsProject,
    QgsVectorLayer,
    QgsRuleBasedRenderer,
    QgsRuleBasedLabeling,
    QgsPalLayerSettings,
    QgsTextFormat,
    QgsTextBackgroundSettings,
    QgsGraduatedSymbolRenderer,
    QgsCategorizedSymbolRenderer,
    QgsReadWriteContext,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils,
    QgsSimpleLineSymbolLayer,
    QgsFillSymbol,
    QgsSymbolLayer,
    QgsSimpleFillSymbolLayer,
    QgsProperty,
    QgsFontUtils,
    QgsUnitTypes
    )
from qgis.PyQt.QtCore import QPointF
from qgis.PyQt.QtGui import QFont

from ..utils.config import Qt
from ..utils.qt_compat import (CURVED_AT_VERTICES, CURVED_DEFAULT, MULTIPART_LARGEST,
                               MULTIPART_SPLIT, curved_label_mode, enum_int,
                               label_multipart_mode, symbol_layer_key)
from ..utils.config import QDomDocument
from ..utils.crs_ref import crs_ref
from ..utils.flattened_rule import FlattenedRule
from ..utils.zoom_levels import ZoomLevels
from .fidelity.diagnostics import DiagnosticCollector
from .fidelity.model import OverzoomPolicy, ZoomInterval
from .fidelity import expressions as ex
from .fidelity import zoom as fidelity_zoom
from .fidelity import map_view
from .fidelity.units import MERCATOR_UNITS_PER_DEGREE, LengthConverter
from .fidelity.qgis_expr import (SCALE_VARIABLES, and_filters, enabled_condition, enclosed,
                                 map_scale_reads, scale_thresholds, substitute_geometry,
                                 uses_map_scale, with_map_scale)
from .fidelity.materialize import coerce_to_symbol_type
from .materializer import SymbolMaterializer



def combine_scale_ranges(low_a: float, high_a: float, low_b: float, high_b: float):
    """Intersection of two QGIS scale ranges (minimum = zoomed-out limit,
    maximum = zoomed-in limit; 0 = no limit)."""
    lows = [v for v in (low_a, low_b) if v]
    highs = [v for v in (high_a, high_b) if v]
    return (min(lows) if lows else 0.0), (max(highs) if highs else 0.0)


def bind_symbol_color(symbol, color=None) -> None:
    """Replace ``@symbol_color`` in the data-defined properties of a symbol's
    layers with the colour QGIS gives it, before the symbol is split into
    one rule per layer (each piece would have a colour of its own): the
    colour of the symbol whose features are drawn, also inside its marker
    lines, hashes and patterns; a geometry generator's sub-symbol is drawn
    as a symbol of its own, with its own colour."""
    from qgis.core import QgsSymbolLayerUtils  # pylint: disable=import-outside-toplevel
    color = symbol.color() if color is None else color
    literal = "'" + QgsSymbolLayerUtils.encodeColor(color) + "'"
    for layer in symbol.symbolLayers():
        props = layer.dataDefinedProperties()
        for key in props.propertyKeys():
            prop = props.property(key)
            if prop is not None and enum_int(prop.propertyType()) == 3 and \
                    re.search(r"@symbol_color\b", prop.expressionString()):
                prop.setExpressionString(re.sub(r"@symbol_color\b", literal,
                                                prop.expressionString()))
                props.setProperty(key, prop)
        sub = layer.subSymbol()
        if sub is not None:
            bind_symbol_color(sub, None if layer.layerType() == "GeometryGenerator" else color)


def _drop_inactive_properties(element) -> None:
    """Remove the switched-off data-defined properties from a saved style:
    QGIS keeps their expressions, which it does not use. (A parcel fill
    whose unused outline width read @map_scale became a dataset per zoom.)"""
    inactive = []
    options = element.elementsByTagName("Option")
    for i in range(options.count()):
        option = options.item(i).toElement()
        if option.attribute("type") != "Map":
            continue
        child = option.firstChildElement("Option")
        while not child.isNull():
            if child.attribute("name") == "active":
                if child.attribute("value") == "false":
                    inactive.append(option)
                break
            child = child.nextSiblingElement("Option")
    for option in inactive:
        option.parentNode().removeChild(option)


class RulesFlattener:
    """Flatten QGIS rule-based styling with full property inheritance."""

    RULE_TYPES = {0: "renderer", 1: "labeling"}

    def __init__(self, min_zoom: int, max_zoom: int, utils_dir, feedback,
                 diagnostics: Optional[DiagnosticCollector] = None, layer_ids=None,
                 scale_limits=None, extent=None, fast_markers: bool = False,
                 lengths: Optional[LengthConverter] = None,
                 overzoom: OverzoomPolicy = OverzoomPolicy.PERSIST,
                 overzoom_to: Optional[int] = None, min_label_px: float = 0.0,
                 features_from=None):
        """``overzoom_to``: the last zoom the map is viewed at (the browser
        overzooms the max_zoom tiles up to it; None: MapLibre's 22).
        ``min_label_px``: labels sized in map units are hidden where their
        text is smaller than this on screen (0: off)."""
        self.min_zoom = min_zoom
        self.min_label_px = float(min_label_px or 0.0)
        # {QGIS layer id: zoom}: the layer's features (not its labels) only
        # from that zoom on (drawn as QGIS images below it: LayerConfig.zoomed_out).
        self.features_from = {k: int(v) for k, v in (features_from or {}).items()}
        # Beyond the archive's last zoom the browser keeps drawing its tiles
        # (PERSIST, the viewer zooms in to 22 by default): rules that start
        # there are drawn from them, and values that depend on the scale are
        # evaluated per zoom up to this zoom (the last one stays open).
        self.overzoom = OverzoomPolicy(overzoom)
        # The one overzoom top of the export: the viewer's last zoom
        # (overzoom_to, MapLibre's 22 by default), the last tile zoom when
        # the map stops there.
        self.overzoom_top = max_zoom if self.overzoom == OverzoomPolicy.STOP else \
            max(max_zoom, fidelity_zoom.MAX_TILE_ZOOM if overzoom_to is None else int(overzoom_to))
        # Unit converter of the style (map-unit context of the project): the
        # pixel sizes of labels laid out at export time.
        self.lengths = lengths or LengthConverter()
        self.extent = extent  # export extent (EPSG:3857), for renderer statistics
        # {layer id: (min scale, max scale)}: extra scale range of a layer
        # (publishing, web only), on top of its own; 0 = no limit.
        self.scale_limits = dict(scale_limits or {})
        self.max_zoom = max_zoom
        self.utils_dir = utils_dir
        self.layer_tree_root = QgsProject.instance().layerTreeRoot()
        # Publishing: exactly these layers, visible or not (None: visible layers).
        self.layer_ids = None if layer_ids is None else set(layer_ids)
        self._legend_keys: dict = {}
        self._current_provenance = None
        self.flattened_rules: List[FlattenedRule] = []
        self.feedback = feedback
        self.diagnostics = diagnostics or DiagnosticCollector()
        # Converted/cloned rule systems are kept alive here instead of being
        # assigned to the project layers: exporting must never modify the
        # user's project (renderer, labeling, ELSE rules, scale visibility).
        self._rule_systems: list = []
        self.materializer = SymbolMaterializer(self.diagnostics, max_zoom=max_zoom,
                                               fast_markers=fast_markers, min_zoom=min_zoom,
                                               overzoom_top=self.overzoom_top, extent=extent)
        # Depth -> first rule number of the next parent's children: rule
        # numbers ("r") are unique per depth within a (layer, rule type) pass.
        self._child_base = {}
        # Draw order: rule sequence within a layer (QGIS draws a feature's
        # rules in tree pre-order, later rules on top) and whether the layer's
        # renderer honours symbol-layer rendering passes.
        self._draw_seq = 0
        self._honor_passes = False
        # Layers whose renderer draws features (not "No symbols"): QGIS
        # labels only the features drawn.
        self._drawn_layers = set()
        # Renderer rules whose symbol draws nothing (no brush, no pen): no
        # tiles, but QGIS renders their features and labels them.
        self._invisible_rules: List[FlattenedRule] = []
        # What the project's selective masking source sets mask (QGIS 4),
        # resolved in flatten_all_rules.
        from .fidelity import masks  # pylint: disable=import-outside-toplevel
        self._set_masks = masks.SourceSetMasks()

    def flatten_all_rules(self) -> List[FlattenedRule]:
        """Extract and flatten all rules from visible vector layers."""
        from .fidelity import masks  # pylint: disable=import-outside-toplevel
        exported = [node.layer() for node in self.layer_tree_root.findLayers()
                    if self._is_valid_layer(node.layer())]
        self._exported_ids = {layer.id() for layer in exported}
        self._set_masks = masks.resolve_source_sets(exported)
        for layer_idx, node in enumerate(self.layer_tree_root.findLayers()):
            if self._is_valid_layer(node.layer()):
                self._process_layer_rules(node.layer(), layer_idx)

        if self.flattened_rules:
            self._clone_rule_objects()

        self._cut_features_below()
        self._remove_unusable_rules()
        self._share_fill_datasets()
        return self.flattened_rules

    def _cut_features_below(self) -> None:
        """Layers drawn as QGIS images zoomed out (``features_from``): their
        renderer rules only from that zoom on. After the labels were matched
        to the renderer rules, so the labels keep every zoom (QGIS labels
        the features it draws: below that zoom it draws them, as images)."""
        if not self.features_from:
            return
        for rule in list(self.flattened_rules):
            first = self.features_from.get(rule.layer.id())
            if first is None or rule.get_attr("t") != 0 or rule.get_attr("o") >= first:
                continue
            if rule.get_attr("i") < first:  # drawn only zoomed out: images alone
                self.flattened_rules.remove(rule)
                continue
            rule.set_attr("o", first)
            if rule.visibility is not None and rule.visibility.min_zoom < first:
                rule.visibility = ZoomInterval(float(first), rule.visibility.max_zoom)

    # Rule fields that change the exported geometry or which features are
    # exported: an outline shares its fill's dataset only where all agree.
    _DATASET_FIELDS = ("visibility", "pre_generator", "merge", "point_group", "feature_filter",
                       "shift", "scale_zoom", "z_order")

    def _share_fill_datasets(self):
        """A simple fill's outline drawn from the fill's polygons (MapLibre
        strokes polygon rings with a line layer): one copy of the polygons
        in the tiles instead of the polygons and their rings as lines (half
        the tile data and browser memory of e.g. parcels)."""
        fills = {}
        for rule in self.flattened_rules:
            if rule.get_attr("t") == 0 and rule.get_attr("c") == 2 and rule.recipe is None \
                    and not rule.fill_outline:
                fills.setdefault((rule.layer.id(), re.sub(r"c\d+", "c02", rule.output_dataset, count=1)), rule)
        for rule in self.flattened_rules:
            # An inverted polygon's rings include the export area's frame,
            # which the outline does not draw: it keeps its own lines.
            if not rule.fill_outline or rule.recipe is not None or rule.get_attr("c") != 1 \
                    or rule.merge == "invert":
                continue
            fill = fills.get((rule.layer.id(), re.sub(r"c\d+", "c02", rule.output_dataset, count=1)))
            if fill is None or fill.rule.filterExpression() != rule.rule.filterExpression() \
                    or any(getattr(fill, name) != getattr(rule, name) for name in self._DATASET_FIELDS):
                continue
            rule.output_dataset = fill.output_dataset
            rule.shares_dataset = True

    def _remove_unusable_rules(self):
        """Remove rules without a symbol (renderer) or label expression (labeling)."""
        for flat_rule in list(self.flattened_rules):
            usable = False
            if flat_rule.get_attr("t") == 0 and flat_rule.rule.symbol():
                usable = True
            elif flat_rule.get_attr("t") == 1 and flat_rule.rule.settings():
                if flat_rule.rule.settings().getLabelExpression().expression():
                    usable = True
            if not usable:
                self.flattened_rules.remove(flat_rule)

    def _clone_rule_objects(self):
        """Clone each rule's underlying object to prevent shared-property mutations."""
        for flat_rule in self.flattened_rules:
            rule = flat_rule.rule
            rule_type = flat_rule.get_attr("t")

            if rule_type == 0:
                clone = QgsRuleBasedRenderer.Rule(None)
            else:
                clone = QgsRuleBasedLabeling.Rule(None)

            clone.setDescription(rule.description())
            clone.setFilterExpression(rule.filterExpression())
            clone.setMinimumScale(rule.minimumScale())
            clone.setMaximumScale(rule.maximumScale())

            if rule_type == 0 and rule.symbol():
                clone.setSymbol(rule.symbol().clone())
            elif rule_type == 1 and rule.settings():
                new_settings = QgsPalLayerSettings(rule.settings())
                new_format = QgsTextFormat(new_settings.format())
                new_bg = QgsTextBackgroundSettings(new_format.background())
                if new_bg.markerSymbol():
                    new_bg.setMarkerSymbol(new_bg.markerSymbol().clone())
                new_format.setBackground(new_bg)
                new_settings.setFormat(new_format)
                clone.setSettings(new_settings)

            flat_rule.rule = clone

    def _is_valid_layer(self, layer) -> bool:
        """Return True if the layer is a visible non-geometry-collection vector layer."""
        if layer is None:  # a legend entry whose layer QGIS could not create
            return False
        is_vector = enum_int(layer.type()) == 0 and enum_int(layer.geometryType()) != 4
        if self.layer_ids is not None:
            return is_vector and layer.id() in self.layer_ids
        node = self.layer_tree_root.findLayer(layer.id())
        is_visible = node.isVisible() if node is not None else False
        return is_vector and is_visible

    def _process_layer_rules(self, layer: QgsVectorLayer, layer_idx: int):
        """Process both renderer and labeling rules for a single layer."""
        for rule_type, type_name in self.RULE_TYPES.items():
            rule_system = self._get_or_convert_rule_system(layer, rule_type)
            if not rule_system:
                if rule_type == 0:  # "No symbols" (or not drawable): its diagrams still are
                    self._child_base = {}
                    self._add_diagram_rules(layer, layer_idx)
                continue
            self._legend_keys = self._legend_key_map(layer, rule_system, rule_type)
            self._apply_reference_scale(layer, rule_system, rule_type)
            self._rule_systems.append(rule_system)
            self._drop_missing_field_properties(rule_system, layer, rule_type)
            if rule_type == 0:
                self._knock_out_mask_markers(rule_system, layer)
            else:
                self._add_set_label_masks(rule_system, layer)
            root_rule = self._prepare_root_rule(rule_system, layer, rule_type)
            if rule_type == 0:
                self._draw_seq = 0
                self._honor_passes = self._renderer_honors_passes(layer.renderer())
                if layer.renderer() is not None and layer.renderer().type() != "nullSymbol":
                    self._drawn_layers.add(layer.id())
            if root_rule:
                self._child_base = {}  # reset per (layer, rule_type) pass
                before = len(self.flattened_rules)
                self._flatten_rule(layer, layer_idx, root_rule, rule_type, 0, 0)
                mode = self._merge_mode(layer.renderer()) if rule_type == 0 else ""
                heatmap = self._heatmap_spec(layer) if rule_type == 0 and \
                    layer.renderer() is not None and layer.renderer().type() == "heatmapRenderer" else None
                for flat_rule in self.flattened_rules[before:]:
                    flat_rule.merge = mode
                    flat_rule.heatmap = heatmap
                if rule_type == 0 and layer.renderer() is not None and \
                        layer.renderer().type() in self.POINT_GROUP_MODES and \
                        layer.renderer().embeddedRenderer() is not None:
                    self._expand_point_groups(layer, before)
            if rule_type == 0:
                self._add_diagram_rules(layer, layer_idx)

    def _knock_out_mask_markers(self, rule_system, layer) -> None:
        """Mask markers as their shape in the background colour
        (fidelity.masks), on the cloned rule system."""
        from .fidelity import masks  # pylint: disable=import-outside-toplevel
        colour = masks.background_colour()
        exported = getattr(self, "_exported_ids", None)
        layer_masks = masks.layer_masks(layer.renderer(), self._set_masks, layer.id(), exported)
        count = sum(masks.knock_out_mask_markers(rule.symbol(), colour, layer_masks, exported)
                    for rule in rule_system.rootRule().descendants())
        if count:
            self.diagnostics.add(
                "Q2VT_MASK_APPROXIMATE",
                f"Layer '{layer.name()}': {count} mask marker(s) drawn as their shape in the "
                f"background colour (covering every layer below, not only the masked ones).",
                layer_id=layer.id())

    def _add_set_label_masks(self, rule_system, layer) -> None:
        """Labels masking through a source set (QGIS 4) mask as with the
        mask's own list: the set's symbol layers join the list, on the
        cloned rule system. QGIS names a label source by its labeling
        provider: the rule key, "" for simple labeling."""
        from .fidelity import masks  # pylint: disable=import-outside-toplevel
        if not self._set_masks.labels:
            return
        rule_based = isinstance(layer.labeling(), QgsRuleBasedLabeling)
        for rule in rule_system.rootRule().descendants():
            settings = rule.settings()
            refs = self._set_masks.labels.get((layer.id(), rule.ruleKey() if rule_based else ""))
            if settings is None or not refs:
                continue
            settings = QgsPalLayerSettings(settings)
            if masks.add_masked_symbol_layers(settings, refs):
                rule.setSettings(settings)

    def _add_diagram_rules(self, layer, layer_idx: int) -> None:
        """The layer's diagrams as one more renderer rule: a placeholder marker
        at each diagram's position carrying its values (fidelity.diagrams),
        drawn above the features of every layer (QGIS draws diagrams with the
        labels) and only in the diagrams' scale range."""
        from .fidelity import diagrams  # pylint: disable=import-outside-toplevel
        spec, notes = diagrams.diagram_spec(layer)
        for note in notes:
            self.diagnostics.add("Q2VT_DIAGRAM_APPROXIMATE", f"Layer '{layer.name()}': {note}.",
                                 layer_id=layer.id())
        if spec is None:
            return
        most_in, most_out = spec["scaleRange"] or (0.0, 0.0)
        root = QgsRuleBasedRenderer.Rule(None)
        root.appendChild(QgsRuleBasedRenderer.Rule(
            diagrams.placeholder_symbol(spec, layer.geometryType()), int(most_in), int(most_out),
            spec["show"], "Diagram"))
        before = len(self.flattened_rules)
        # Numbered after the layer's renderer rules (the renderer pass left
        # their count in _child_base): a dataset name of its own.
        self._child_base = getattr(self, "_child_base", None) or {}
        self._flatten_rule(layer, layer_idx, root, 0, 0, 0)
        for flat_rule in self.flattened_rules[before:]:
            flat_rule.diagram = spec
            flat_rule.order = (1_000_000, -layer_idx) + tuple(flat_rule.order or ())

    def _apply_reference_scale(self, layer, rule_system, rule_type: int) -> None:
        """Screen-unit sizes of a layer with a symbology reference scale
        (symbols and labels, as QgsVectorLayerRenderer / QgsLabelingEngine
        apply it) as map units of their size at that scale, on this copy."""
        from .reference_scale import ReferenceScaleConverter, apply_to_rules  # pylint: disable=import-outside-toplevel
        renderer = layer.renderer()
        reference = renderer.referenceScale() if renderer is not None else -1.0
        if not reference or reference <= 0:
            return
        converter = ReferenceScaleConverter(
            reference, self.lengths.map_context.scale_metres_per_map_unit,
            self.lengths.map_context.mercator_per_map_unit, crs_ref(layer.crs()))
        apply_to_rules(rule_system, rule_type, converter)
        if converter.unhandled:
            self.diagnostics.add(
                "Q2VT_REFERENCE_SCALE",
                f"Layer '{layer.name()}' (reference scale 1:{reference:g}): "
                f"{', '.join(sorted(set(converter.unhandled)))} keep their screen size.",
                layer_id=layer.id())
        if converter.map_unit_sizes:
            self.diagnostics.add(
                "Q2VT_REFERENCE_SCALE",
                f"Layer '{layer.name()}' (reference scale 1:{reference:g}): "
                f"{', '.join(sorted(set(converter.map_unit_sizes)))} in map units keep their "
                "map size; QGIS also scales map-unit sizes by the reference scale.",
                layer_id=layer.id())

    @staticmethod
    @staticmethod
    def _leader_provenance(pinned):
        import dataclasses  # pylint: disable=import-outside-toplevel
        if pinned.provenance is None:
            return None
        return dataclasses.replace(pinned.provenance, component="leader")

    @staticmethod
    def _legend_key_map(layer, rule_system, rule_type: int) -> dict:
        """{rule key in ``rule_system``: (legend key, legend label)} of the
        original renderer, for publication provenance.

        Rule-based renderers keep their rule keys when cloned (identity);
        single/categorized/graduated renderers were converted to rules in
        the order of their legend items, which carry the stable
        category/range keys. Labeling rules keep their own keys."""
        mapping = {}
        if rule_type != 0:
            for index, rule in enumerate(rule_system.rootRule().children()):
                mapping[rule.ruleKey()] = (rule.ruleKey() if isinstance(layer.labeling(), QgsRuleBasedLabeling)
                                           else "labels", rule.description() or "")
            return mapping
        renderer = layer.renderer()
        if renderer is None or isinstance(renderer, QgsRuleBasedRenderer):
            return mapping
        try:
            items = [item for item in renderer.legendSymbolItems()
                     if item.symbol() is not None]
        except (AttributeError, RuntimeError):
            return mapping
        for rule, item in zip(rule_system.rootRule().children(), items):
            mapping[rule.ruleKey()] = (item.ruleKey() or "single", item.label() or "")
        return mapping

    def _provenance(self, layer, rule, rule_type: int, origin, ancestors) -> object:
        """RuleProvenance of a rule about to be flattened (see
        publishing.provenance); ``origin`` is the rule an ELSE variant was
        split from."""
        from ..publishing.provenance import RuleProvenance  # pylint: disable=import-outside-toplevel
        source = origin if origin is not None else rule
        key = self._rule_key(source)
        legend_key, label = self._legend_keys.get(key, (key, ""))
        if not label:
            label = (source.label() if rule_type == 0 else source.description()) or ""
        parents = tuple(self._legend_keys.get(self._rule_key(a), (self._rule_key(a), ""))[0]
                        for a in ancestors if self._rule_key(a))
        return RuleProvenance(
            layer_id=layer.id(), layer_name=layer.name(),
            kind="symbology" if rule_type == 0 else "labeling",
            rule_key=legend_key, rule_label=label, parent_keys=parents,
            else_rule=self._is_else_rule(source))

    def _drop_missing_field_properties(self, rule_system, layer, rule_type: int) -> None:
        """Switch off data-defined properties that read a field the layer does
        not have. QGIS cannot prepare such a property and draws the static
        value (Szabályozás övezetkódok: a colour rule on "beep_szant" leaves
        the labels dark grey in QGIS; the export evaluated it to blue).

        Works on the cloned rule system: the project is not changed."""
        fields = {field.name().lower() for field in layer.fields()}
        # Qgis.PropertyType (3.36+) or QgsProperty.Type (older).
        kinds = getattr(Qgis, "PropertyType", None)
        field_kind = getattr(kinds, "Field", None) if kinds else QgsProperty.FieldBasedProperty
        expression_kind = getattr(kinds, "Expression", None) if kinds else \
            QgsProperty.ExpressionBasedProperty

        def missing(prop) -> List[str]:
            if enum_int(prop.propertyType()) == enum_int(field_kind):
                names = [prop.field()]
            elif enum_int(prop.propertyType()) == enum_int(expression_kind):
                names = list(QgsExpression(prop.asExpression()).referencedColumns())
            else:
                return []
            return [name for name in names if name and not name.startswith("#!")
                    and name.lower() not in fields]

        def clean(collection, where: str) -> bool:
            changed = False
            for key in collection.propertyKeys():
                prop = collection.property(key)
                if not prop.isActive():
                    continue
                absent = missing(prop)
                if absent:
                    prop.setActive(False)
                    collection.setProperty(key, prop)
                    changed = True
                    self.diagnostics.add(
                        "Q2VT_DDP_MISSING_FIELD",
                        f'Layer "{layer.name()}", {where}: field(s) {", ".join(sorted(set(absent)))} '
                        f"not found; the static value is used, as in QGIS.",
                        layer_id=layer.id(), detail=prop.asExpression())
            return changed

        def clean_symbol(symbol, where: str) -> None:
            if symbol is None:
                return
            properties = symbol.dataDefinedProperties()
            if clean(properties, where):
                symbol.setDataDefinedProperties(properties)
            for layer_index in range(symbol.symbolLayerCount()):
                symbol_layer = symbol.symbolLayer(layer_index)
                properties = symbol_layer.dataDefinedProperties()
                if clean(properties, f"{where}, symbol layer {layer_index + 1}"):
                    symbol_layer.setDataDefinedProperties(properties)
                clean_symbol(symbol_layer.subSymbol(), where)

        for rule in rule_system.rootRule().descendants():
            if rule_type == 0:
                clean_symbol(rule.symbol(), f"symbol of rule '{rule.label() or rule.description()}'")
                continue
            settings = rule.settings()
            if settings is None:
                continue
            where = f"labels of rule '{rule.description()}'" if rule.description() else "labels"
            properties = settings.dataDefinedProperties()
            changed = clean(properties, where)
            text_format = settings.format()
            format_properties = text_format.dataDefinedProperties()
            if clean(format_properties, where):
                text_format.setDataDefinedProperties(format_properties)
                settings.setFormat(text_format)
                changed = True
            if changed:  # in place: setSettings() would delete these very settings
                settings.setDataDefinedProperties(properties)

    @staticmethod
    def _renderer_honors_passes(renderer) -> bool:
        """QGIS orders symbol layers by rendering pass for rule-based renderers
        always, for other renderers only with symbol levels enabled."""
        if renderer is None:
            return False
        if isinstance(renderer, QgsRuleBasedRenderer):
            return True
        try:
            return bool(renderer.usingSymbolLevels())
        except (AttributeError, RuntimeError):
            return False

    def _get_or_convert_rule_system(self, layer: QgsVectorLayer, rule_type: int):
        """Return the layer's rule system, converting from single/graduated/categorized if needed."""
        if rule_type == 0:
            return self._convert_renderer_to_rules(layer)
        return self._convert_labeling_to_rules(layer)

    # --- point cluster / point displacement renderers -------------------------
    POINT_GROUP_MODES = {"pointCluster": "cluster", "pointDisplacement": "displacement"}
    # Extra rules carry a constant (always true) filter naming their role.
    POINT_GROUP_ROLES = ("cluster", "center", "circle", "grid")

    @staticmethod
    def _role_filter(role: str) -> str:
        return f"'q2vt:{role}' = 'q2vt:{role}'"

    def _point_group_rules(self, renderer):
        """Rules of a point cluster / displacement renderer: its cluster symbol
        (or displacement circle / grid and centre symbol) first, then the
        embedded renderer's rules one level down (their ELSE rules stay
        among their own siblings). _expand_point_groups exports them per
        zoom from the grouped points (RulesExporter._point_groups)."""
        from qgis.core import QgsLineSymbol  # pylint: disable=import-outside-toplevel
        root = QgsRuleBasedRenderer.Rule(None)
        if renderer.type() == "pointCluster":
            if renderer.clusterSymbol() is not None:
                root.appendChild(QgsRuleBasedRenderer.Rule(
                    renderer.clusterSymbol().clone(), 0, 0, self._role_filter("cluster"), "Cluster"))
        else:
            line = QgsSimpleLineSymbolLayer(renderer.circleColor(), renderer.circleWidth())
            line.setWidthUnit(Qgis.RenderUnit.Millimeters)
            role = "grid" if enum_int(renderer.placement()) == 2 else "circle"
            root.appendChild(QgsRuleBasedRenderer.Rule(
                QgsLineSymbol([line]), 0, 0, self._role_filter(role), "Displacement " + role))
            if renderer.centerSymbol() is not None:
                root.appendChild(QgsRuleBasedRenderer.Rule(
                    renderer.centerSymbol().clone(), 0, 0, self._role_filter("center"),
                    "Displacement centre"))
        embedded = self._as_rule_renderer(renderer.embeddedRenderer().clone())
        if embedded is not None:
            group = QgsRuleBasedRenderer.Rule(None, 0, 0, "", "Points")
            for child in embedded.rootRule().children():
                group.appendChild(child.clone())
            root.appendChild(group)
        return QgsRuleBasedRenderer(root)

    def _map_units_per_mm(self, layer, zoom: float) -> float:
        """Project CRS map units per screen millimetre at ``zoom``."""
        from qgis.core import QgsUnitTypes  # pylint: disable=import-outside-toplevel
        crs = QgsProject.instance().crs() if QgsProject.instance().crs().isValid() else layer.crs()
        if crs.isGeographic():
            # Degrees per mm as QGIS's map-to-pixel at the browser's ground
            # resolution (see SymbolMaterializer._map_units_per_mm).
            return fidelity_zoom.WEB_MERCATOR_TOP_SCALE / 2.0 ** zoom / 1000.0 / \
                MERCATOR_UNITS_PER_DEGREE
        metres = (ZoomLevels.zoom_to_scale(0) or 0.0) / 2.0 ** zoom / 1000.0
        return metres * QgsUnitTypes.fromUnitToUnitFactor(Qgis.DistanceUnit.Meters, crs.mapUnits())

    def _point_group_params(self, renderer, layer, zoom: float) -> tuple:
        """Grouping and placement of a point cluster / displacement renderer in
        project map units at ``zoom`` (QgsPointDistanceRenderer converts its
        tolerance with the render context; QgsPointDisplacementRenderer sizes
        in painter units)."""
        from qgis.core import QgsRenderContext  # pylint: disable=import-outside-toplevel
        from .fidelity.units import normalize_unit  # pylint: disable=import-outside-toplevel
        from .materializer import _to_mm  # pylint: disable=import-outside-toplevel
        per_mm = self._map_units_per_mm(layer, zoom)

        def map_units(value, unit):
            if normalize_unit(unit) == "map":
                return float(value)
            mm = _to_mm(value, unit)
            return float(mm or 0.0) * per_mm

        crs = QgsProject.instance().crs() if QgsProject.instance().crs().isValid() else layer.crs()
        params = [("tolerance", map_units(renderer.tolerance(), renderer.toleranceUnit())),
                  ("crs", crs_ref(crs))]
        if renderer.type() == "pointDisplacement":
            sizes = [map_units(symbol.size(), symbol.sizeUnit())
                     for symbol in renderer.embeddedRenderer().symbols(QgsRenderContext())
                     if hasattr(symbol, "sizeUnit")]
            center = renderer.centerSymbol()
            params += [
                ("placement", enum_int(renderer.placement())),
                ("symbol_diagonal", math.sqrt(2) * max(sizes or [0.0])),
                ("center_diagonal", math.sqrt(2) * map_units(center.size(), center.sizeUnit())
                 if center is not None else 0.0),
                ("addition", map_units(renderer.circleRadiusAddition(), Qgis.RenderUnit.Millimeters)),
                ("label_factor", float(renderer.labelDistanceFactor()))]
        return tuple(params)

    @staticmethod
    def _cluster_variables(symbol) -> None:
        """@cluster_size / @cluster_color in the symbol's data-defined
        properties read the fields RulesExporter._point_groups writes."""
        from .fidelity.materialize import CLUSTER_COLOR_FIELD, CLUSTER_SIZE_FIELD  # pylint: disable=import-outside-toplevel
        if symbol is None:
            return
        for index in range(symbol.symbolLayerCount()):
            layer = symbol.symbolLayer(index)
            props = layer.dataDefinedProperties()
            for key in props.propertyKeys():
                prop = props.property(key)
                if enum_int(prop.propertyType()) == enum_int(QgsProperty.Type.ExpressionBasedProperty):
                    text = prop.expressionString()
                    new = text.replace("@cluster_size", f'"{CLUSTER_SIZE_FIELD}"').replace(
                        "@cluster_color", f'"{CLUSTER_COLOR_FIELD}"')
                    if new != text:
                        layer.setDataDefinedProperty(symbol_layer_key(key), QgsProperty.fromExpression(new, prop.isActive()))
            RulesFlattener._cluster_variables(layer.subSymbol())

    def _group_points(self, layer):
        """The layer's points in the export extent, in drawing (feature)
        order, in project map units: what QGIS groups."""
        from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,  # pylint: disable=import-outside-toplevel
                               QgsFeatureRequest)
        project = QgsProject.instance()
        crs = project.crs() if project.crs().isValid() else layer.crs()
        to_project = QgsCoordinateTransform(layer.crs(), crs, project.transformContext())
        request = QgsFeatureRequest()
        if self.extent is not None:
            web = QgsCoordinateReferenceSystem("EPSG:3857")
            request.setFilterRect(QgsCoordinateTransform(web, layer.crs(), project.transformContext())
                                  .transformBoundingBox(self.extent))
        points = []
        for feature in layer.getFeatures(request):
            geometry = feature.geometry()
            if geometry.isEmpty():
                continue
            point = geometry.centroid().asPoint() if geometry.isMultipart() else geometry.asPoint()
            point = to_project.transform(point)
            points.append((point.x(), point.y()))
        return points

    # Grouping is evaluated in eighths of a zoom (tolerance within +-4 % of
    # QGIS's); eighths that group alike (and displace nothing) are merged.
    POINT_GROUP_STEPS = 8

    def _point_group_bands(self, renderer, layer, zoom: int, points):
        """[(start zoom, end zoom, params, groups, moves)] of one zoom: where
        the grouping (or a displacement's sizes) changes; ``moves``: a
        displacement moves points apart."""
        from .fidelity import point_groups as pg  # pylint: disable=import-outside-toplevel
        cluster = renderer.type() == "pointCluster"
        bands = []
        steps = self.POINT_GROUP_STEPS
        for step in range(steps):
            start, end = zoom + step / steps, zoom + (step + 1) / steps
            params = self._point_group_params(renderer, layer, (start + end) / 2)
            groups = pg.group_points(points, dict(params)["tolerance"])
            moves = not cluster and any(len(g) > 1 for g in groups)
            if bands and bands[-1][3] == groups and not moves and not bands[-1][4]:
                first = bands[-1][0]
                params = self._point_group_params(renderer, layer, (first + end) / 2)
                bands[-1] = (first, end, params, groups, False)
            else:
                bands.append((start, end, params, groups, moves))
        return bands

    def _expand_point_groups(self, layer, before: int) -> None:
        """Every component of a point cluster / displacement layer, one rule
        per zoom band (grouping depends on the scale), with its role."""
        from .fidelity import point_groups as pg  # pylint: disable=import-outside-toplevel
        renderer = layer.renderer()
        mode = self.POINT_GROUP_MODES[renderer.type()]
        components = self.flattened_rules[before:]
        del self.flattened_rules[before:]
        points = self._group_points(layer)
        bands = {}
        label = self._displacement_label(renderer, layer) if mode == "displacement" else None
        labelled = []  # the bands labelled once (members split into symbol layers)
        for flat_rule in components:
            expression = flat_rule.rule.filterExpression() or ""
            role = next((r for r in self.POINT_GROUP_ROLES if self._role_filter(r) in expression),
                        "members")
            if role in ("circle", "grid"):
                flat_rule.set_attr("g", 1)  # drawn on generated lines
            if role in ("cluster", "center"):
                self._cluster_variables(flat_rule.rule.symbol())
            # Overzoom included: the grouping distance is a screen size. Those
            # zooms are drawn from the last tiles: one that groups like the
            # zoom before (and moves nothing) extends its rule, the points
            # that stay alone from the first of them on are written once
            # (stable_members), and the rest is within the last tiles' budget.
            per_zoom = self.materializer._per_zoom(flat_rule, overzoom=True)  # pylint: disable=protected-access
            over = [r for r in per_zoom if r.get_attr("v") is not None]
            stable = None  # grouping distance of stable_members, once written
            if over:
                tolerance = dict(self._point_group_params(
                    renderer, layer, float(over[0].get_attr("v"))))["tolerance"]
                grouped = len(points) - len(pg.isolated(points, tolerance))
            previous = None  # (rule, groups, moves) of the last band written
            for index, rule in enumerate(per_zoom):
                zoom = int(rule.evaluation_zoom())
                if zoom not in bands:
                    bands[zoom] = self._point_group_bands(renderer, layer, zoom, points)
                visible = rule.visibility or ZoomInterval(
                    float(zoom), None if index == len(per_zoom) - 1 else zoom + 1.0)
                overzoom = rule.get_attr("v") is not None
                if overzoom and previous is not None and len(bands[zoom]) == 1 and \
                        bands[zoom][0][3] == previous[1] and not bands[zoom][0][4] and \
                        not previous[2] and previous[0].visibility.max_zoom is not None and \
                        abs(previous[0].visibility.max_zoom - visible.min_zoom) < 1e-9:
                    previous[0].visibility = ZoomInterval(previous[0].visibility.min_zoom,
                                                          visible.max_zoom)
                    continue
                if overzoom:
                    # A copy of the grouped points per band, in the last tiles' budget.
                    if not self.materializer._overzoom_take(  # pylint: disable=protected-access
                            flat_rule, [grouped * len(bands[zoom])], report=False):
                        self.materializer._report_overzoom_budget(  # pylint: disable=protected-access
                            flat_rule, zoom - self.materializer.max_zoom - 1)
                        if previous is not None:
                            previous[0].visibility = ZoomInterval(
                                previous[0].visibility.min_zoom, None)
                        break
                    if stable is None and role == "members":
                        stable = dict(self._point_group_params(
                            renderer, layer, visible.min_zoom))["tolerance"]
                        self.flattened_rules.append(self._stable_members(
                            flat_rule, rule, mode, visible.min_zoom, bands[zoom][0][2], stable))
                for band, (start, end, params, groups, moves) in enumerate(bands[zoom]):
                    last = band == len(bands[zoom]) - 1 and visible.max_zoom is None
                    interval = visible.intersect(ZoomInterval(start, None if last else end))
                    if interval.is_empty:
                        continue
                    if rule.scale_zoom is not None and previous is not None and \
                            previous[1] == groups and not moves and not previous[2]:
                        # Beyond the last tile zoom, grouped as the band before.
                        previous[0].visibility = self._visibility_hull(previous[0].visibility,
                                                                       interval)
                        continue
                    banded = rule.derive()
                    banded.visibility = interval
                    banded.set_attr("b", band)
                    if stable is not None:
                        params = params + (("stable", stable),)
                    banded.point_group = (mode, role, round((start + end) / 2, 4), params)
                    self.flattened_rules.append(banded)
                    previous = (banded, groups, moves)
                    if role == "members" and label is not None and banded.rule.symbol() is not None \
                            and banded.visibility not in labelled:
                        labelled.append(banded.visibility)
                        label_rule = self._displacement_label_rule(banded, label)
                        if label_rule is not None:
                            self.flattened_rules.append(label_rule)
        self.diagnostics.add(
            "Q2VT_SYMBOL_APPROXIMATE",
            f"{'Point cluster' if mode == 'cluster' else 'Point displacement'} renderer: points "
            "grouped per zoom level (QGIS groups at every scale, within the visible area).",
            layer_id=layer.id())

    @staticmethod
    def _displacement_label(renderer, layer) -> Optional[dict]:
        """A point displacement renderer's own labels (its label attribute,
        font and colour; QgsPointDistanceRenderer::drawLabels) or None. An
        idea of QGIS2VectorTiles 4.1 (GallPeters/QGIS2VectorTiles)."""
        name = renderer.labelAttributeName()
        if not name or layer.fields().lookupField(name) < 0:
            return None
        font = renderer.labelFont()
        color = renderer.labelColor()
        return {"field": layer.fields().at(layer.fields().lookupField(name)).name(),
                "family": font.family(), "style": font.styleName(), "bold": font.bold(),
                "italic": font.italic(), "size_pt": float(font.pointSizeF()),
                "color": (color.red(), color.green(), color.blue(), color.alphaF()),
                "min_scale": float(renderer.minimumLabelScale())}

    def _displacement_label_rule(self, members, label: dict):
        """The labels of a band of displaced points: one point per member
        where QGIS writes its label (RulesExporter._point_groups, role
        "label"), drawn as text from the label attribute. Only at scales
        larger than the minimum label scale (QGIS: rendererScale < it)."""
        rule = members.derive()
        rule.set_attr("s", 98)  # a dataset of its own
        mode, _role, zoom, params = members.point_group
        rule.point_group = (mode, "label", zoom, params)
        rule.displacement_label = dict(label)
        if label["min_scale"] > 0:
            from .fidelity import zoom as fidelity_zoom  # pylint: disable=import-outside-toplevel
            first = fidelity_zoom.scale_to_zoom(label["min_scale"])
            if rule.visibility is not None:
                rule.visibility = rule.visibility.intersect(ZoomInterval(float(first), None))
                if rule.visibility.is_empty:
                    return None
        return rule

    def _stable_members(self, flat_rule, rule, mode: str, zoom: float, params: tuple,
                        tolerance: float):
        """The members role's points with no other point within ``tolerance``
        (the grouping distance at ``zoom``, the first overzoom written, see
        point_groups.isolated): alone at every zoom above, so written once,
        visible from ``zoom`` on; the per-zoom rules leave them out
        (point_group param "stable")."""
        stable = rule.derive()
        stable.visibility = flat_rule.visibility.intersect(ZoomInterval(float(zoom), None))
        stable.set_attr("b", self.POINT_GROUP_STEPS)
        stable.point_group = (mode, "members", float(zoom), params + (
            ("stable", tolerance), ("part", "stable")))
        return stable

    @staticmethod
    def _heatmap_weight(heatmap, fields) -> str:
        """The weight expression with QGIS's NULL rule made explicit: a weight
        naming a numeric field reads the attribute, whose NULL weighs 0 (a
        typed null converts to 0); any other NULL or non-number weighs 1
        (QgsHeatmapRenderer keeps 1 when the value does not convert; the
        web's fallback)."""
        weight = heatmap.weightExpression()
        if not weight:
            return ""
        index = fields.lookupField(weight)
        expression = QgsExpression(weight)
        if index < 0 and expression.isField():  # a quoted field name
            index = fields.lookupField(next(iter(expression.referencedColumns())))
        if index < 0:
            return weight
        column = QgsExpression.quotedColumnRef(fields.at(index).name())
        if fields.at(index).isNumeric():
            return f"coalesce({column}, 0)"
        # A text field: its value converted as QGIS does (toDouble), 1 when it
        # is no number.
        return f"coalesce(try(to_real({column})), 1)"

    @classmethod
    def _heatmap_placeholder(cls, heatmap, fields):
        """One rule exporting the points; its marker only carries the weight
        expression (Size) into the tiles. The style draws a MapLibre heatmap
        instead (FlattenedRule.heatmap)."""
        from qgis.core import QgsMarkerSymbol  # pylint: disable=import-outside-toplevel
        symbol = QgsMarkerSymbol.createSimple({"name": "circle", "size": "1"})
        weight = cls._heatmap_weight(heatmap, fields)
        if weight:
            symbol.symbolLayer(0).setDataDefinedProperty(QgsSymbolLayer.Property.PropertySize,
                                                         QgsProperty.fromExpression(weight))
        root = QgsRuleBasedRenderer.Rule(None)
        root.appendChild(QgsRuleBasedRenderer.Rule(symbol, 0, 0, "", "Heatmap"))
        return QgsRuleBasedRenderer(root)

    def _heatmap_spec(self, layer):
        """fidelity.heatmap spec of a heatmap renderer: ramp, radius and the
        maximum density per zoom, from the points inside the export extent."""
        from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,  # pylint: disable=import-outside-toplevel
                               QgsExpressionContext, QgsExpressionContextUtils,
                               QgsFeatureRequest, QgsPointXY)
        from .fidelity import heatmap as hm  # pylint: disable=import-outside-toplevel
        from .fidelity.units import normalize_unit  # pylint: disable=import-outside-toplevel
        from .materializer import _to_mm  # pylint: disable=import-outside-toplevel
        renderer = layer.renderer()
        project = QgsProject.instance()
        crs = project.crs() if project.crs().isValid() else layer.crs()
        to_project = QgsCoordinateTransform(layer.crs(), crs, project.transformContext())
        request = QgsFeatureRequest()
        latitude = 0.0
        if self.extent is not None:
            web = QgsCoordinateReferenceSystem("EPSG:3857")
            request.setFilterRect(QgsCoordinateTransform(web, layer.crs(), project.transformContext())
                                  .transformBoundingBox(self.extent))
            center = QgsCoordinateTransform(web, QgsCoordinateReferenceSystem("EPSG:4326"),
                                            project.transformContext()).transform(self.extent.center())
            latitude = center.y()
        context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer)
                                       + [map_view.scope()])
        expression = self._heatmap_weight(renderer, layer.fields())
        weight = QgsExpression(expression) if expression else None
        if weight is not None:
            weight.prepare(context)
        points = []
        for feature in layer.getFeatures(request):
            geometry = feature.geometry()
            if geometry.isEmpty():
                continue
            context.setFeature(feature)
            value = 1.0
            if weight is not None:
                try:
                    value = float(weight.evaluate(context))
                except (TypeError, ValueError):
                    value = 1.0  # as QGIS: a weight that does not convert counts 1
            for part in geometry.constParts():
                point = to_project.transform(QgsPointXY(part.x(), part.y()))
                points.append((point.x(), point.y(), value))
            if len(points) > 200000:
                break
        unit = renderer.radiusUnit()
        screen = normalize_unit(unit) != "map" and _to_mm(1.0, unit) is not None
        # Intensity per zoom up to the style's last zoom (24) while the
        # browser overzooms the last tiles: above the last stop MapLibre keeps
        # its maximum, of a radius many times larger in map units (a pale
        # heatmap when zoomed in past the tiles). Up to the last tile zoom
        # when the map stops there.
        top = self.overzoom_top if self.overzoom == OverzoomPolicy.STOP else \
            max(int(self.overzoom_top), 24)
        zooms = list(range(int(self.min_zoom), int(top) + 1))
        if crs.isGeographic():
            self.diagnostics.add("Q2VT_HEATMAP_APPROXIMATE",
                                 "Heatmap in a geographic project CRS: map-unit radius and density "
                                 "are approximated.", layer_id=layer.id())
        if not renderer.maximumValue():
            self.diagnostics.add("Q2VT_HEATMAP_APPROXIMATE",
                                 "Heatmap with an automatic maximum: QGIS scales it to the densest "
                                 "spot in view; the web map uses the densest spot of the exported "
                                 "data at each zoom.", layer_id=layer.id())
        return hm.build_spec(renderer.colorRamp(), renderer.radius(), "screen" if screen else "map",
                             float(renderer.maximumValue() or 0.0), points, zooms,
                             latitude=latitude, mercator=crs.authid() == "EPSG:3857",
                             mm_per_unit=_to_mm(1.0, unit) if screen else None)

    @staticmethod
    def _merge_mode(renderer) -> str:
        """"merge" / "invert" for renderers drawing a symbol's features
        together (merged features, inverted polygons), else ""."""
        kind = renderer.type() if renderer is not None else ""
        return {"mergedFeatureRenderer": "merge", "invertedPolygonRenderer": "invert"}.get(kind, "")

    def _convert_renderer_to_rules(self, layer: QgsVectorLayer):
        """Convert any renderer to a QgsRuleBasedRenderer, preserving active items only."""
        system = layer.renderer()
        if not system:
            return None

        system = system.clone()
        if isinstance(system, QgsRuleBasedRenderer):
            return system
        self._quote_class_fields(system, layer.fields())
        if system.type() == "heatmapRenderer":
            return self._heatmap_placeholder(system, layer.fields())
        if system.type() in self.POINT_GROUP_MODES and system.embeddedRenderer() is not None:
            return self._point_group_rules(system)
        rules = self._as_rule_renderer(system)
        if rules is None and system.type() != "nullSymbol":
            # QGIS cannot express it as rules (2.5D, embedded symbols, plugin
            # renderers): the layer draws nothing on the web map.
            self.diagnostics.add(
                "Q2VT_UNSUPPORTED_RENDERER",
                f"Layer '{layer.name()}': the {system.type()} renderer is not supported; "
                "the layer is not drawn on the web map.",
                layer_id=layer.id(), detail=system.type())
        return rules

    @classmethod
    def _quote_class_fields(cls, renderer, fields) -> None:
        """A categorized / graduated attribute that names a field is that
        field, as QGIS reads it (lookupField first, an expression only
        otherwise). convertFromRenderer parses it as an expression first:
        a field named "a/b" became the division a / b."""
        if isinstance(renderer, (QgsCategorizedSymbolRenderer, QgsGraduatedSymbolRenderer)):
            attribute = renderer.classAttribute()
            if attribute and not attribute.startswith('"') and fields.lookupField(attribute) >= 0:
                renderer.setClassAttribute(QgsExpression.quotedColumnRef(attribute))
        embedded = getattr(renderer, "embeddedRenderer", None)
        if callable(embedded) and embedded() is not None:
            cls._quote_class_fields(embedded(), fields)

    def _as_rule_renderer(self, system):
        """Rule-based copy of a (non rule-based) renderer; unchecked items
        become inactive rules. QGIS draws nothing for the features of an
        unchecked category (they never fall to "all other values"), so
        they stay as siblings that the ELSE rule excludes."""
        if isinstance(system, QgsRuleBasedRenderer):
            return system.clone()
        inactive_indices = self._get_inactive_item_indices(system)
        rule_renderer = QgsRuleBasedRenderer.convertFromRenderer(system)

        if rule_renderer and inactive_indices:
            children = rule_renderer.rootRule().children()
            for idx in inactive_indices:
                if idx < len(children):
                    children[idx].setActive(False)

        return rule_renderer

    def _get_inactive_item_indices(self, system) -> List[int]:
        """Return indices of inactive items from graduated or categorized renderers."""
        items_method = None
        if isinstance(system, QgsGraduatedSymbolRenderer):
            items_method = "ranges"
        elif isinstance(system, QgsCategorizedSymbolRenderer):
            items_method = "categories"

        if items_method:
            items = getattr(system, items_method)()
            return [i for i, item in enumerate(items) if not item.renderState()]
        return []

    def _convert_labeling_to_rules(self, layer: QgsVectorLayer):
        """Convert any labeling system to QgsRuleBasedLabeling."""
        system = layer.labeling()
        if not system or not layer.labelsEnabled():
            return None

        system = system.clone()
        if isinstance(system, QgsRuleBasedLabeling):
            return system

        rule = QgsRuleBasedLabeling.Rule(QgsPalLayerSettings(system.settings()))
        root = QgsRuleBasedLabeling.Rule(QgsPalLayerSettings())
        root.appendChild(rule)
        return QgsRuleBasedLabeling(root)

    def _prepare_root_rule(self, rule_system, layer: QgsVectorLayer, rule_type: int = 0):
        """Set layer-level scale visibility on the root rule: the layer's own
        range, the web-only limits (min scale, max scale) and, for its labels,
        the web-only labels limit (a third value, zoomed-out edge)."""
        root_rule = rule_system.rootRule()
        low, high = (layer.minimumScale(), layer.maximumScale()) \
            if layer.hasScaleBasedVisibility() else (0.0, 0.0)
        limits = tuple(self.scale_limits.get(layer.id(), ())) + (0.0, 0.0, 0.0)
        low, high = combine_scale_ranges(low, high, limits[0] or 0.0, limits[1] or 0.0)
        if rule_type == 1 and limits[2]:
            low, high = combine_scale_ranges(low, high, limits[2], 0.0)
        if low or high:
            root_rule.setMinimumScale(low)
            root_rule.setMaximumScale(high)
        return root_rule

    def _set_rule_attributes(
        self,
        flat_rule: FlattenedRule,
        layer_idx: int,
        rule_type: int,
        rule_level: int,
        rule_idx: int,
    ):
        """Stamp identification and zoom attributes onto the flat rule."""
        flat_rule.set_attr("l", layer_idx)
        flat_rule.set_attr("t", rule_type)
        flat_rule.set_attr("d", rule_level)
        flat_rule.set_attr("r", rule_idx)
        flat_rule.set_attr("g", flat_rule.layer.geometryType())
        flat_rule.set_attr("c", flat_rule.layer.geometryType())
        flat_rule.visibility = self._rule_visibility(flat_rule.rule)
        flat_rule.set_attr("o", self._rule_min_zoom(flat_rule.rule))
        flat_rule.set_attr("i", self._rule_max_zoom(flat_rule.rule))
        # "s" = symbol layer index for renderer; "f" = renderer index for labeling
        flat_rule.set_attr("s" if rule_type == 0 else "f", 0)

    def _rule_min_zoom(self, rule) -> int:
        return int(ZoomLevels.scale_to_zoom(rule.minimumScale(), "o"))

    def _rule_max_zoom(self, rule) -> int:
        return int(ZoomLevels.scale_to_zoom(rule.maximumScale(), "i"))

    def _rule_visibility(self, rule) -> ZoomInterval:
        """Exact browser interval of an (inherited) rule's scale range.

        Inheritance replaces "unbounded" by the extreme zoom-0/zoom-22 scales;
        an upper bound at the last tile zoom is therefore treated as open, so
        the overzoom policy (not an accidental constant) decides what happens
        beyond the archive's maxzoom.
        """
        interval = fidelity_zoom.interval_from_scales(rule.minimumScale(), rule.maximumScale())
        if interval.max_zoom is not None and interval.max_zoom >= fidelity_zoom.MAX_TILE_ZOOM - 1e-6:
            interval = ZoomInterval(interval.min_zoom, None)
        return interval.intersect(ZoomInterval(float(self.min_zoom), None))

    def _flatten_rule(
        self,
        layer: QgsVectorLayer,
        layer_idx: int,
        rule: Union[QgsRuleBasedLabeling.Rule, QgsRuleBasedRenderer.Rule],
        rule_type: int,
        rule_level: int,
        rule_idx: int,
        inherited_parent=None,
        origin=None,
        ancestors=(),
        segment=None,
    ):
        """Recursively flatten the rule hierarchy with property inheritance.

        ``origin``: the original rule of a split ELSE variant; ``ancestors``:
        original parent rules (both only for publication provenance);
        ``segment``: the variant's number when an ELSE rule was split into
        several (its own dataset)."""
        # Children of an unprocessed node (the root) inherit from the node itself;
        # children of a processed node inherit from its accumulated (flattened) state.
        parent_for_children = rule
        if rule.parent() or rule_level > 0:  # split ELSE variants are parentless clones
            self._current_provenance = self._provenance(layer, rule, rule_type, origin, ancestors)
            inheritance_source = self._process_rule(
                layer, layer_idx, rule, rule_type, rule_level, rule_idx, inherited_parent,
                segment=segment,
            )
            if inheritance_source is not None:
                parent_for_children = inheritance_source
        child_ancestors = tuple(ancestors) + ((origin or rule,) if rule_level > 0 else ())
        # Rule numbers are unique per depth: the children of two parents (a
        # nested rule-based renderer) would otherwise share an id and a
        # dataset - and the style its duplicate layer ids (no map at all).
        base = self._child_base.get(rule_level + 1, 0)
        self._child_base[rule_level + 1] = base + len(rule.children())
        for child_idx, child in enumerate(rule.children()):
            if not child.active():
                continue
            variants = [child]
            if self._is_else_rule(child):
                variants = self._split_else_rule(child, rule, layer, rule_type)
            for number, variant in enumerate(variants):
                self._flatten_rule(
                    layer, layer_idx, variant, rule_type, rule_level + 1, base + child_idx,
                    parent_for_children, origin=child if variant is not child else None,
                    ancestors=child_ancestors, segment=number if len(variants) > 1 else None,
                )

    @staticmethod
    def _rule_key(rule) -> str:
        try:
            return rule.ruleKey()
        except AttributeError:
            return ""

    @staticmethod
    def _is_else_rule(rule) -> bool:
        try:
            return bool(rule.isElse())
        except AttributeError:
            return rule.filterExpression() == "ELSE"

    @staticmethod
    def _scale_interval(rule) -> ZoomInterval:
        return fidelity_zoom.interval_from_scales(rule.minimumScale(), rule.maximumScale())

    def _split_else_rule(self, else_rule, parent_rule, layer, rule_type: int = 0) -> list:
        """Replace an ELSE rule by explicit exclusion rules.

        QGIS 3.34 applies an ELSE rule to the features no sibling *matched*.
        A sibling matches a feature its filter passes even where it draws
        nothing: switched off, or (renderer only) out of its scale range, as
        no symbol levels were prepared; it then returns "Inactive", which the
        ELSE rule counts as matched. Only an active sibling with nothing to
        draw never matches. A renderer ELSE therefore excludes every sibling
        at every scale. Rule-based labels check a sibling's scale range
        first (Filtered outside it), so a label ELSE is split at every
        sibling scale breakpoint; each piece excludes the siblings (checked
        or not) whose scale range covers it.
        """
        siblings = [
            sibling for sibling in parent_rule.children()
            if sibling is not else_rule and not self._is_else_rule(sibling)
            and (not sibling.active() or sibling.children() or self._rule_has_payload(sibling))
        ]
        if any(sibling.children() for sibling in siblings):
            self.diagnostics.add(
                "Q2VT_ELSE_NESTED_SIBLINGS",
                f"ELSE rule of layer '{layer.name()}': sibling rules with nested children "
                "are treated as matching whenever their own filter matches.",
                layer_id=layer.id(), rule_id=self._rule_key(else_rule),
            )
        if rule_type == 0:
            variant = else_rule.clone()
            variant.setFilterExpression(self._exclusion_filter(
                [sibling.filterExpression() for sibling in siblings]))
            return [variant]
        # The label ELSE's own range, narrowed by its settings' scale
        # visibility (no empty pieces outside it).
        scaled = else_rule.clone()
        self._apply_label_scale_visibility(scaled, layer)
        own = self._scale_interval(scaled)
        breakpoints = {own.min_zoom}
        for sibling in siblings:
            interval = self._scale_interval(sibling)
            for value in (interval.min_zoom, interval.max_zoom):
                if value is not None and own.contains(value):
                    breakpoints.add(value)
        edges = sorted(breakpoints) + [own.max_zoom]
        variants = []
        for low, high in zip(edges[:-1], edges[1:]):
            segment = ZoomInterval(low, high)
            if segment.is_empty:
                continue
            probe = segment.min_zoom + (1e-3 if segment.max_zoom is None
                                        else (segment.max_zoom - segment.min_zoom) / 2)
            filters = [sibling.filterExpression() for sibling in siblings
                       if self._scale_interval(sibling).contains(probe)]
            variant = else_rule.clone()
            variant.setMinimumScale(fidelity_zoom.zoom_to_scale(segment.min_zoom)
                                    if segment.min_zoom > 0 else else_rule.minimumScale())
            variant.setMaximumScale(fidelity_zoom.zoom_to_scale(segment.max_zoom)
                                    if segment.max_zoom is not None else 0)
            variant.setFilterExpression(self._exclusion_filter(filters))
            variants.append(variant)
        return variants

    @staticmethod
    def _exclusion_filter(filters) -> str:
        """Filter of the features no expression in ``filters`` matches."""
        if any(not f for f in filters):
            # A sibling without a filter matches every feature.
            return "FALSE"
        if filters:
            # "OR FALSE" turns a single sibling's value into a boolean as the
            # OR of several does: a truthy 5 or strpos() result is not "IS 1".
            return f'NOT ({" OR ".join(enclosed(f) for f in filters)} OR FALSE) IS 1'
        return ""

    @staticmethod
    def _is_feature_dependent(expression: str) -> bool:
        parsed = QgsExpression(expression)
        return bool(parsed.referencedColumns()) or parsed.needsGeometry() or \
            bool({"feature", "id", "geometry"} & set(parsed.referencedVariables()))

    @staticmethod
    def _screen_interval_markers(symbol, except_index: int) -> bool:
        """Whether another layer of ``symbol`` places markers (or hashes) at a
        screen-unit interval: letters or ticks along the line, which a
        dashed line of the symbol often leaves gaps for."""
        from .ddp_fetcher import dense_marker_line  # pylint: disable=import-outside-toplevel
        interval = int(getattr(Qgis.MarkerLinePlacement.Interval, "value",
                               Qgis.MarkerLinePlacement.Interval))
        for index, layer in enumerate(symbol.symbolLayers()):
            if index == except_index or not layer.enabled() or \
                    layer.layerType() not in ("MarkerLine", "HashLine"):
                continue
            flags = int(getattr(layer.placements(), "value", layer.placements()))
            if flags & interval and layer.interval() > 0 and not dense_marker_line(layer) and \
                    layer.intervalUnit() not in (Qgis.RenderUnit.MapUnits,
                                                 Qgis.RenderUnit.MetersInMapUnits):
                return True
        return False

    def _fold_enabled_property(self, flat_rule: FlattenedRule, symbol_layer):
        """Turn a feature-dependent data-defined *enabled* into a rule filter.

        The legacy export ignored it, drawing the component on every feature.
        Scale-only expressions keep the per-zoom handling.
        """
        props = symbol_layer.dataDefinedProperties()
        prop = props.property(QgsSymbolLayer.Property.PropertyLayerEnabled)
        if not prop or not prop.isActive() or not self._is_feature_dependent(prop.asExpression()):
            return
        if flat_rule.label_filter is None:
            flat_rule.label_filter = flat_rule.rule.filterExpression()
        flat_rule.rule.setFilterExpression(and_filters(
            flat_rule.rule.filterExpression(), enabled_condition(prop.asExpression())))
        prop.setActive(False)
        props.setProperty(QgsSymbolLayer.Property.PropertyLayerEnabled, prop)

    def _fold_show_property(self, rule):
        """Turn a data-defined label *Show* into part of the rule filter."""
        settings = rule.settings()
        if settings is None:
            return
        props = settings.dataDefinedProperties()
        key = QgsPalLayerSettings.Property.Show
        prop = props.property(key)
        if not prop or not prop.isActive():
            return
        rule.setFilterExpression(and_filters(rule.filterExpression(),
                                             enabled_condition(prop.asExpression())))
        prop.setActive(False)
        props.setProperty(key, prop)
        settings.setDataDefinedProperties(props)

    @staticmethod
    def _rule_has_payload(rule) -> bool:
        if hasattr(rule, "symbol"):
            return rule.symbol() is not None
        return rule.settings() is not None

    def _process_rule(
        self,
        layer: QgsVectorLayer,
        layer_idx: int,
        rule,
        rule_type: int,
        rule_level: int,
        rule_idx: int,
        inherited_parent,
        segment=None,
    ):
        """Inherit, validate, split, register; return the cumulative source for descendants."""
        inherited_rule = self._inherit_rule_properties(rule, rule_type, inherited_parent)
        if not inherited_rule:
            return None

        # Snapshot cumulative state (AND-chain filter, intersected scales, stacked
        # symbols) BEFORE applying NOT-children — descendants must not see the
        # output-only exclusion (otherwise C inherits "... AND NOT C" from B*).
        inheritance_source = inherited_rule.clone()
        if rule_type == 1:
            # After the snapshot: a label's Show condition and its settings'
            # scale visibility must not restrict the labels of child rules.
            self._fold_show_property(inherited_rule)
            self._apply_label_scale_visibility(inherited_rule, layer)
        # self._exclude_children_from_filter(inherited_rule, rule)

        flat_rule = FlattenedRule(inherited_rule, layer,
                                  provenance=getattr(self, "_current_provenance", None))
        flat_rule.rule.setDescription("")
        self._set_rule_attributes(flat_rule, layer_idx, rule_type, rule_level, rule_idx)
        if segment is not None:
            # ELSE variants differ only in filter and exact visibility: two
            # inside one tile zoom had the same dataset (one filter for both).
            flat_rule.set_attr("e", segment)

        if flat_rule.visibility.is_empty:
            self.diagnostics.add(
                "Q2VT_ZOOM_EMPTY_INTERVAL",
                f"Rule '{rule.description() or rule.filterExpression() or rule_idx}' of layer "
                f"'{layer.name()}' is never visible (scale range {rule.minimumScale():g} – "
                f"{rule.maximumScale():g}).",
                layer_id=layer.id(), rule_id=self._rule_key(rule),
            )
            return inheritance_source

        if not self._is_within_zoom_range(flat_rule):
            self.diagnostics.add(
                "Q2VT_ZOOM_EMPTY_INTERVAL",
                f"Rule '{rule.description() or rule.filterExpression() or rule_idx}' of layer "
                f"'{layer.name()}' is shown only beyond the export's maximum zoom + 1, where the "
                "web map hides every layer (scale range "
                f"{rule.minimumScale():g} – {rule.maximumScale():g}).",
                layer_id=layer.id(), rule_id=self._rule_key(rule),
            )
            return inheritance_source
        # Shown only beyond the last tile zoom: drawn from its tiles.
        for edge in ("o", "i"):
            if flat_rule.get_attr(edge) > self.max_zoom:
                flat_rule.set_attr(edge, self.max_zoom)

        if rule_type == 0:
            self._draw_seq += 1
        split_rules = self._split_rule(flat_rule, rule_type)
        if rule_type == 0 and not split_rules and flat_rule.rule.symbol() is not None:
            self._invisible_rules.append(flat_rule)
        if rule_type == 1:
            split_rules = [part for rule in split_rules for part in self._split_pinned_labels(rule)]
        self._clip_rules_to_zoom_range(split_rules)
        # Components split by zoom (e.g. dense patterns) may fall outside the export.
        split_rules = [r for r in split_rules if r.get_attr("o") <= r.get_attr("i")]
        for split_rule in split_rules:
            for zoom_rule in self._split_by_scale_expressions(split_rule):
                self.flattened_rules.extend(self._split_line_label_windows(zoom_rule))
        return inheritance_source

    SCALE_VISIBILITY_KEYS = (QgsPalLayerSettings.Property.ScaleVisibility,
                             QgsPalLayerSettings.Property.MinimumScale,
                             QgsPalLayerSettings.Property.MaximumScale)

    def _apply_label_pixel_limits(self, rule, layer, settings) -> None:
        """Hide labels sized in map units where their text is too small (or,
        with QGIS's "Pixel size-based visibility", too large) on screen.

        A data-defined size is limited per feature (a @map_scale condition
        in the rule's filter, split into zooms later). Sizes with their own
        scale limits are left alone."""
        text = settings.format()
        unit = int(getattr(text.sizeUnit(), "value", text.sizeUnit()))
        map_units = int(getattr(Qgis.RenderUnit.MapUnits, "value", Qgis.RenderUnit.MapUnits))
        metres_unit = int(getattr(Qgis.RenderUnit.MetersInMapUnits, "value",
                                  Qgis.RenderUnit.MetersInMapUnits))
        if unit not in (map_units, metres_unit):
            return
        size_prop = settings.dataDefinedProperties().property(QgsPalLayerSettings.Property.Size)
        varying = size_prop is not None and size_prop.isActive()
        limits = text.sizeMapUnitScale()
        if (text.size() <= 0 and not varying) or limits.minScale or limits.maxScale:
            return
        if unit == metres_unit:
            factor = 1.0
        else:
            project_crs = QgsProject.instance().crs()
            crs = project_crs if project_crs.isValid() else layer.crs()
            if not crs.isValid() or crs.isGeographic():
                return
            factor = QgsUnitTypes.fromUnitToUnitFactor(crs.mapUnits(), Qgis.DistanceUnit.Meters)
        smallest, largest = self.min_label_px, 0.0
        if settings.fontLimitPixelSize:
            smallest = max(smallest, float(settings.fontMinPixelSize))
            largest = float(settings.fontMaxPixelSize)
        if varying:
            self._limit_varying_label_size(rule, layer, size_prop.asExpression(), float(text.size()),
                                           factor * 96.0 / 0.0254, smallest, largest)
            return
        # On-screen px of the text at 1:scale (96 dpi): metres * 96 / 0.0254 / scale.
        per_px = text.size() * factor * 96.0 / 0.0254
        low = per_px / smallest if smallest > 0 else 0.0
        high = per_px / largest if largest > 0 else 0.0
        if low or high:
            self._intersect_scale_range(rule, low, high)

    # Size levels of a data-defined label size: each feature is shown from
    # the threshold of the largest level it reaches (exact for up to this
    # many distinct sizes, a little late in between otherwise).
    MAX_LABEL_SIZE_LEVELS = 16

    def _limit_varying_label_size(self, rule, layer, expression: str, static: float,
                                  px_scale: float, smallest: float, largest: float) -> None:
        """The pixel limits of a data-defined label size (``px_scale``: the
        scale denominator at which one size unit is one pixel). The sizes
        the layer's features take are compared with fixed scales, so the
        rule is cut at those scales only (one piece per zoom, up to the
        overzoom top, made a copy of the labels per zoom)."""
        if (smallest <= 0 and largest <= 0) or uses_map_scale(expression):
            return
        size = f"coalesce(to_real({enclosed(expression)}), {static!r})"
        levels = self._label_size_levels(layer, size)
        if not levels:
            return
        conditions = []
        if smallest > 0:
            conditions.append(" OR ".join(f"({size} >= {v!r} AND @map_scale <= {v * px_scale / smallest!r})"
                                          for v in levels))
        if largest > 0:
            conditions.append(" OR ".join(f"({size} <= {v!r} AND @map_scale >= {v * px_scale / largest!r})"
                                          for v in levels))
        rule.setFilterExpression(and_filters(rule.filterExpression(),
                                             " AND ".join(f"({c})" for c in conditions)))

    def _label_size_levels(self, layer, size: str) -> List[float]:
        """The positive values ``size`` takes on the layer's features, or
        MAX_LABEL_SIZE_LEVELS levels spread (geometrically) between their
        least and greatest value (each value rounded down to one)."""
        from qgis.core import QgsExpressionContext, QgsExpressionContextUtils, QgsFeatureRequest  # pylint: disable=import-outside-toplevel
        expression = QgsExpression(size)
        context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer)
                                       + [map_view.scope()])
        expression.prepare(context)
        request = QgsFeatureRequest()
        if not expression.needsGeometry():
            request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
        values = set()
        for feature in layer.getFeatures(request):
            context.setFeature(feature)
            value = expression.evaluate(context)
            try:
                value = float(value)
            except (TypeError, ValueError):
                continue
            if value > 0 and math.isfinite(value):
                values.add(value)
        if len(values) <= self.MAX_LABEL_SIZE_LEVELS:
            return sorted(values)
        low, high = min(values), max(values)
        steps = self.MAX_LABEL_SIZE_LEVELS - 1
        return [low * (high / low) ** (k / steps) for k in range(steps + 1)]

    def _apply_label_scale_visibility(self, rule, layer) -> None:
        """Apply the label settings' scale visibility (Rendering tab) to the rule.

        QGIS checks the rule's scale range and these settings both: the
        ranges intersect. Data-defined visibility or scales that depend on
        the feature (or the scale) become part of the rule filter."""
        settings = rule.settings()
        if settings is None:
            return
        props = settings.dataDefinedProperties()
        active = {key: props.property(key).asExpression() for key in self.SCALE_VISIBILITY_KEYS
                  if props.property(key) and props.property(key).isActive()}
        visibility_key, min_key, max_key = self.SCALE_VISIBILITY_KEYS
        if any(self._is_feature_dependent(expression)
               or uses_map_scale(expression)
               for expression in active.values()):
            def value(key, static):
                return f"coalesce(to_real({enclosed(active[key])}), {static!r})" if key in active \
                    else repr(static)
            visible = (f"coalesce({enclosed(active[visibility_key])}, "
                       f"{str(settings.scaleVisibility).upper()})"
                       if visibility_key in active else str(settings.scaleVisibility).upper())
            condition = (
                f"with_variable('q2vt_low', {value(min_key, float(settings.minimumScale))}, "
                f"with_variable('q2vt_high', {value(max_key, float(settings.maximumScale))}, "
                f"NOT if({visible}, TRUE, FALSE) OR ("
                "(@q2vt_high = 0 OR @map_scale >= if(@q2vt_high < 0, 1 / abs(@q2vt_high), @q2vt_high))"
                " AND (@q2vt_low = 0 OR @map_scale <= if(@q2vt_low < 0, 1 / abs(@q2vt_low), @q2vt_low)))))")
            rule.setFilterExpression(and_filters(rule.filterExpression(), condition))
        else:
            context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer)
                                           + [map_view.scope()])
            use, low, high = settings.scaleVisibility, settings.minimumScale, settings.maximumScale
            if visibility_key in active:
                use = props.valueAsBool(visibility_key, context, use)[0]
            if min_key in active:
                low = props.valueAsDouble(min_key, context, low)[0]
            if max_key in active:
                high = props.valueAsDouble(max_key, context, high)[0]
            if use:
                self._intersect_scale_range(rule, low, high)
        self._apply_label_pixel_limits(rule, layer, settings)
        settings.scaleVisibility = False
        for key in active:
            prop = props.property(key)
            prop.setActive(False)
            props.setProperty(key, prop)
        settings.setDataDefinedProperties(props)

    @staticmethod
    def _intersect_scale_range(rule, low: float, high: float) -> None:
        """Narrow the rule's scale range to ``low`` (zoomed-out edge) ..
        ``high`` (zoomed-in edge); 0 is no limit, a negative scale -s is
        1:1/s (closer than 1:1), as QGIS reads label scales."""
        low = 1 / abs(low) if low < 0 else low
        high = 1 / abs(high) if high < 0 else high
        if low:
            rule.setMinimumScale(min(rule.minimumScale(), low) if rule.minimumScale() else low)
        if high:
            rule.setMaximumScale(max(rule.maximumScale(), high) if rule.maximumScale() else high)

    def _inherit_rule_properties(self, rule, rule_type: int, inherited_parent):
        """Clone and inherit scale range, filter expression, and symbol layers from cumulative parent."""
        clone = rule.clone()
        self._inherit_min_scale(clone, rule, inherited_parent)
        self._inherit_max_scale(clone, rule, inherited_parent)
        self._inherit_filter_expression(clone, rule, inherited_parent)
        # if rule_type == 0:
        #     self._inherit_symbol_layers(clone, rule, inherited_parent)
        return clone

    def _inherit_min_scale(self, clone, rule, inherited_parent):
        """Inherit minimum scale; 0 means no restriction → use the largest available scale.

        The 0-substitution is applied symmetrically to both the rule's own scale
        and the parent's scale; otherwise an unrestricted ancestor would zero out
        every descendant when min(child, 0) is computed.
        """
        rule_scale = rule.minimumScale() if rule.minimumScale() != 0 else max(ZoomLevels.SCALES)
        parent_min = inherited_parent.minimumScale()
        parent_scale = parent_min if parent_min != 0 else max(ZoomLevels.SCALES)
        clone.setMinimumScale(min(rule_scale, parent_scale))

    def _inherit_max_scale(self, clone, rule, inherited_parent):
        """Inherit maximum scale; 0 means no restriction → use the smallest available scale."""
        rule_scale = rule.maximumScale() if rule.maximumScale() != 0 else min(ZoomLevels.SCALES)
        parent_max = inherited_parent.maximumScale()
        parent_scale = parent_max if parent_max != 0 else min(ZoomLevels.SCALES)
        clone.setMaximumScale(max(rule_scale, parent_scale))

    def _inherit_filter_expression(self, clone, rule, inherited_parent):
        """Combine cumulative ancestor filter with this rule's filter (AND-chain only).

        NOT-children exclusion is NOT applied here — it would poison the snapshot
        used for descendant inheritance. It is applied to the output clone in
        _exclude_children_from_filter after the snapshot is taken.
        """
        parent_filter = inherited_parent.filterExpression() if inherited_parent is not None else ""
        rule_filter = rule.filterExpression()

        if parent_filter and rule_filter:
            combined = f"{enclosed(parent_filter)} AND {enclosed(rule_filter)}"
        else:
            combined = parent_filter or rule_filter or ""

        clone.setFilterExpression(combined)

    def _exclude_children_from_filter(self, clone, rule):
        """Exclude this rule's children's filter conditions (output-only — descendants must
        not see this exclusion or grandchildren would inherit a tautologically-false filter)."""
        child_filters = [
            enclosed(child.filterExpression())
            for child in rule.children()
            if child.filterExpression() and child.filterExpression() != "ELSE"
        ]
        if not child_filters:
            return
        children_expr = " OR ".join(child_filters)
        combined = clone.filterExpression()
        final = f"{enclosed(combined)} AND NOT ({children_expr})" if combined \
            else f"NOT ({children_expr})"
        clone.setFilterExpression(final)

    def _inherit_symbol_layers(self, clone, rule, inherited_parent):
        """Append the cumulative parent's symbol layers to the cloned rule's symbol."""
        clone_symbol = clone.symbol()
        parent_symbol = inherited_parent.symbol() if inherited_parent is not None else None
        if parent_symbol and clone_symbol:
            for i in range(parent_symbol.symbolLayerCount()):
                clone_symbol.appendSymbolLayer(parent_symbol.symbolLayer(i).clone())

    def _split_rule(self, flat_rule: FlattenedRule, rule_type: int) -> List[FlattenedRule]:
        """Split rule by symbol layers (renderer) or matching renderers (labeling)."""
        if rule_type == 0:
            return self._split_by_symbol_layers(flat_rule)
        return self._split_by_matching_renderers(flat_rule)

    def _is_within_zoom_range(self, flat_rule: FlattenedRule) -> bool:
        """Return True if the rule is shown within the export: its browser
        interval overlaps the exported zooms, or the zooms beyond them while
        the browser keeps drawing the last tiles (a rule from 1:1000, zoom
        18.2, is drawn from the zoom-16 tiles of a 0-16 export; comparing
        the tile zooms dropped it)."""
        top = None if self.overzoom == OverzoomPolicy.PERSIST else float(self.max_zoom + 1)
        return not flat_rule.visibility.intersect(
            ZoomInterval(float(self.min_zoom), top)).is_empty

    def _clip_rules_to_zoom_range(self, flat_rules: List[FlattenedRule]):
        """Clamp each rule's zoom range to the global min/max zoom."""
        for flat_rule in flat_rules:
            if flat_rule.get_attr("o") < self.min_zoom:
                flat_rule.set_attr("o", self.min_zoom)
            if flat_rule.get_attr("i") > self.max_zoom:
                flat_rule.set_attr("i", self.max_zoom)

    @classmethod
    def _flatten_generators(cls, symbol):
        """Symbol whose nested geometry generators are composed into single ones.

        A generator whose sub-symbol holds further generators (e.g. an outer
        ``$geometry`` drawn as a line around an inner ``wave($geometry)``)
        becomes one generator per sub-symbol layer: the inner expression with
        its geometry replaced by the outer one. Returns None when nothing is
        nested.
        """
        from qgis.core import QgsGeometryGeneratorSymbolLayer  # pylint: disable=import-outside-toplevel
        nested = any(
            layer.layerType() == "GeometryGenerator" and layer.subSymbol() is not None and any(
                sub.layerType() == "GeometryGenerator" for sub in layer.subSymbol().symbolLayers())
            for layer in symbol.symbolLayers())
        if not nested:
            return None
        result = symbol.clone()
        for index in reversed(range(result.symbolLayerCount())):
            result.deleteSymbolLayer(index)

        def generator(expression, sub_symbol, template):
            layer = QgsGeometryGeneratorSymbolLayer.create({
                "geometryModifier": expression,
                "SymbolType": {0: "Marker", 1: "Line", 2: "Fill"}[int(getattr(
                    sub_symbol.type(), "value", sub_symbol.type()))]})
            layer.setSubSymbol(sub_symbol)
            layer.setUnits(template.units())
            layer.setEnabled(template.enabled())
            layer.setRenderingPass(template.renderingPass())
            return layer

        def expand(layer, expression):
            sub = layer.subSymbol()
            for index in range(sub.symbolLayerCount()):
                inner = sub.symbolLayer(index)
                if inner.layerType() == "GeometryGenerator" and inner.subSymbol() is not None:
                    # The inner generator receives the outer output coerced to
                    # the outer sub-symbol's type (rings for a line symbol...).
                    received = coerce_to_symbol_type(
                        expression, int(getattr(sub.type(), "value", sub.type())))
                    # Inside another symbol QGIS evaluates a generator on the
                    # painter geometry (y down), scaled back to its units
                    # (QgsGeometryGeneratorSymbolLayer::render /
                    # evaluateGeometryInPainterUnits): mirror, evaluate, mirror.
                    mirrored = f"scale({enclosed(received)}, 1, -1, make_point(0, 0))"
                    composed = (f"scale({enclosed(substitute_geometry(inner.geometryExpression(), mirrored))}"
                                f", 1, -1, make_point(0, 0))")
                    yield from expand(inner, composed)
                else:
                    single = sub.clone()
                    for i in reversed(range(single.symbolLayerCount())):
                        if i != index:
                            single.deleteSymbolLayer(i)
                    yield generator(expression, single, layer)

        for layer in symbol.symbolLayers():
            if layer.layerType() == "GeometryGenerator" and layer.subSymbol() is not None:
                for part in expand(layer, layer.geometryExpression()):
                    result.appendSymbolLayer(part)
            else:
                result.appendSymbolLayer(layer.clone())
        return result

    @staticmethod
    def _screen_generator_indices(symbol) -> List[int]:
        """Indices of the enabled geometry generators in screen units."""
        from .fidelity.units import normalize_unit, physical_factor  # pylint: disable=import-outside-toplevel
        return [index for index, layer in enumerate(symbol.symbolLayers())
                if layer.enabled() and layer.layerType() == "GeometryGenerator"
                and physical_factor(normalize_unit(layer.units())) is not None]

    def _screen_generator_rules(self, flat_rule: FlattenedRule,
                                indices: List[int]) -> List[FlattenedRule]:
        """A symbol with geometry generators in mm / px / pt / in: QGIS
        evaluates them on the painter geometry in those units (fixed screen
        sizes, y down), so each zoom gets its own generator in map units; the
        symbol's other layers are split as usual. Overzoomed zooms (up to
        ``overzoom_top``) get bands of the last tile zoom (attribute "b"),
        each with its own generator, so sizes stay fixed on screen there too."""
        from .fidelity.qgis_expr import in_screen_units  # pylint: disable=import-outside-toplevel
        from .fidelity.units import normalize_unit, physical_factor  # pylint: disable=import-outside-toplevel
        rest = flat_rule.derive()
        for index in indices:
            rest.rule.symbol().symbolLayer(index).setEnabled(False)
        rules = self._split_by_symbol_layers(rest)
        layer_crs = crs_ref(flat_rule.layer.crs())
        per_zoom = self.materializer._per_zoom(flat_rule)  # pylint: disable=protected-access
        slices = []
        for position, zoom_rule in enumerate(per_zoom):
            zoom = int(zoom_rule.get_attr("o"))
            last = position == len(per_zoom) - 1
            visible = zoom_rule.visibility or ZoomInterval(float(zoom), None if last else zoom + 1.0)
            if not last:
                slices.append((zoom_rule, zoom))
                continue
            top = self.overzoom_top if visible.max_zoom is None else \
                min(self.overzoom_top, int(math.ceil(visible.max_zoom)) - 1)
            if top <= zoom:
                slices.append((zoom_rule, zoom))
                continue
            for band, at_zoom in enumerate(range(zoom, top + 1)):
                interval = visible.intersect(ZoomInterval(
                    float(at_zoom), None if at_zoom == top else at_zoom + 1.0))
                if interval.is_empty:
                    continue
                banded = zoom_rule.derive()
                banded.visibility = interval
                banded.set_attr("b", band)
                banded.scale_zoom = float(at_zoom)
                slices.append((banded, at_zoom))
        for zoom_rule, zoom in slices:
            # Web Mercator units per CSS px at this zoom (512 px tiles).
            mercator_per_px = 40075016.68557849 / (512.0 * 2.0 ** zoom)
            symbol = zoom_rule.rule.symbol()
            for index, layer in enumerate(symbol.symbolLayers()):
                if index not in indices:
                    layer.setEnabled(False)
                    continue
                per_unit = mercator_per_px * physical_factor(normalize_unit(layer.units()))
                # @map_scale of this slice's zoom (an overzoom band keeps the
                # last tile zoom as "o", which the exporter would bind).
                expression = with_map_scale(layer.geometryExpression(),
                                            fidelity_zoom.zoom_to_scale(zoom))
                layer.setGeometryExpression(in_screen_units(
                    expression, per_unit, "EPSG:3857", layer_crs))
                layer.setUnits(Qgis.RenderUnit.MapUnits)
            rules.extend(self._split_by_symbol_layers(zoom_rule))
        return rules

    def _split_by_symbol_layers(self, flat_rule: FlattenedRule) -> List[FlattenedRule]:
        """Split a renderer rule into one rule per enabled symbol layer."""
        symbol = flat_rule.rule.symbol()
        if not symbol:
            return [flat_rule]
        bind_symbol_color(symbol)
        flattened = self._flatten_generators(symbol)
        if flattened is not None:
            del symbol  # deleted by setSymbol: no stale wrapper (see below)
            flat_rule.rule.setSymbol(flattened)
            symbol = flat_rule.rule.symbol()
        screen_generators = self._screen_generator_indices(symbol)
        if screen_generators:
            return self._screen_generator_rules(flat_rule, screen_generators)

        layer_count = symbol.symbolLayerCount()
        split_rules = []
        buffered = self._split_buffer(symbol)

        clone_symbol = clone_symbol_layer = rule_clone = None
        for layer_idx in reversed(range(layer_count)):
            # Materializing can replace the previous clone's symbol layer
            # (changeSymbolLayer deletes it): drop those wrappers before the
            # next clone allocates (see the outline note below).
            clone_symbol = clone_symbol_layer = None
            symbol_layer = symbol.symbolLayer(layer_idx)
            if not symbol_layer.enabled():
                continue
            sub_symbol = symbol_layer.subSymbol()
            layer_type = symbol_layer.layerType() if symbol_layer else None
            if layer_type == "GeometryGenerator" and sub_symbol is not None and \
                    int(getattr(sub_symbol.type(), "value", sub_symbol.type())) in (1, 2):
                split_rules.extend(self._generated_line_rules(flat_rule, symbol_layer, layer_idx))
                continue
            if layer_type == "VectorField" and sub_symbol is not None:
                split_rules.extend(self._vector_field_rules(flat_rule, symbol_layer, layer_idx))
                continue
            if layer_type == "GeometryGenerator":
                symbol_type = sub_symbol.type()
            elif layer_type == "CentroidFill":
                symbol_type = 0
            else:
                symbol_type = symbol_layer.type()

            rule_clone = flat_rule.derive()
            rule_clone.set_attr("c", symbol_type)
            # Its own dataset, also for a marker generator: on a point layer
            # (same c) the generated points renamed to s00 were the dataset
            # of symbol layer 0, which was then drawn at the generated position.
            rule_clone.set_attr("s", layer_idx)

            clone_symbol = rule_clone.rule.symbol()
            for remove_idx in reversed(range(layer_count)):
                if remove_idx != layer_idx:
                    clone_symbol.deleteSymbolLayer(remove_idx)


            if buffered:  # drawn once, under the whole symbol (below)
                clone_symbol.bufferSettings().setEnabled(False)
            clone_symbol_layer = clone_symbol.symbolLayers()[0]
            self._fold_enabled_property(rule_clone, clone_symbol_layer)
            draw_pass = clone_symbol_layer.renderingPass() if self._honor_passes else 0
            # Bottom first: lower layer tree position, pass, feature-order
            # stratum (0 here; fidelity.feature_order), rule, symbol layer, part.
            order = (-flat_rule.get_attr("l"), draw_pass, 0, self._draw_seq, layer_idx)
            rule_clone.order = order + (0,)
            rule_clone.band_dashes = layer_type == "SimpleLine" and \
                self._screen_interval_markers(symbol, layer_idx)
            materialized = self.materializer.materialize(rule_clone, clone_symbol_layer)
            if materialized is not None:
                for part, component in enumerate(materialized):
                    component.order = order + (part,)
                split_rules.extend(materialized)
                continue
            if rule_clone and layer_type == "SimpleFill":
                split_rules.extend(self._simple_fill_rules(rule_clone, clone_symbol_layer, order))
                continue
            if rule_clone:
                split_rules.append(rule_clone)

        if buffered:
            split_rules.append(self._buffer_rule(flat_rule, symbol, layer_count))
        return split_rules

    @staticmethod
    def _split_buffer(symbol) -> bool:
        """A marker symbol of several enabled layers with a symbol buffer
        (QGIS 3.40+). QGIS buffers the shape of the whole rendered symbol
        once and draws it under all its layers (QgsSymbol::drawPreviewIcon,
        renderFeature); kept on every split layer, each layer got a buffer
        of its own (one around every part, over the layers below)."""
        settings = getattr(symbol, "bufferSettings", lambda: None)()
        if settings is None or not settings.enabled() or settings.fillSymbol() is None:
            return False
        if int(getattr(symbol.type(), "value", symbol.type())) != 0:
            return False  # line and fill symbols: drawn by MapLibre, without the buffer
        return sum(1 for layer in symbol.symbolLayers() if layer.enabled()) > 1

    def _buffer_rule(self, flat_rule: FlattenedRule, symbol, layer_count: int) -> FlattenedRule:
        """The rule drawing a split marker symbol's buffer: the whole
        symbol, whose image is only its buffer (SymbolImage buffer_only),
        under the layers' rules. An idea of QGIS2VectorTiles 4.2
        (GallPeters/QGIS2VectorTiles), which keeps the buffer on the bottom
        layer; here it surrounds the whole symbol, as in QGIS."""
        rule = flat_rule.derive()
        rule.set_attr("c", 0)
        rule.set_attr("s", layer_count)  # a dataset of its own (after the layers')
        rule.buffer_only = True
        passes = [layer.renderingPass() for layer in symbol.symbolLayers() if layer.enabled()] \
            if self._honor_passes else [0]
        rule.order = (-flat_rule.get_attr("l"), min(passes or [0]), 0, self._draw_seq, -1, 0)
        return rule

    def _simple_fill_rules(self, rule_clone: FlattenedRule, fill_layer, order: tuple):
        """A simple fill as its fill and its outline: QGIS strokes the polygon
        with the pen's width, unit, dashes and join, which MapLibre's
        fill-outline (one device pixel) cannot, so the stroke is a line rule
        on the polygon's rings, above its fill. A map-unit offset moves the
        exported polygon (outline too)."""
        rules = []
        shift = self._map_offset_shift(fill_layer, rule_clone)
        if shift is not None:
            # The exported polygon is moved (outline too); no translate.
            rule_clone.shift = shift
            fill_layer.setOffset(QPointF())
            fill_layer.setDataDefinedProperty(QgsSymbolLayer.Property.PropertyOffset, QgsProperty())
        if fill_layer.strokeStyle() != Qt.PenStyle.NoPen:
            outline_rule = rule_clone.derive()
            outline_rule.set_attr("c", 1)
            outline_rule.fill_outline = True
            # No Python reference to the fill symbol may outlive
            # setSymbol() below, which deletes it: SIP would hand
            # that stale QgsFillSymbol wrapper back for the next
            # object QGIS allocates at the same address (seen on
            # Windows: "'QgsFillSymbol' object has no attribute
            # 'sizeUnit'" for a point pattern's marker).
            outline_symbol = self._convert_fill_outline_to_line_symbol(
                outline_rule.rule.symbol())
            if outline_symbol:
                outline_rule.order = order + (1,)  # stroke above its fill
                outline_rule.translate = self._fill_offset(fill_layer)
                outline_rule.rule.setSymbol(outline_symbol)
                rules.append(outline_rule)
                fill_layer.setStrokeStyle(Qt.PenStyle.NoPen)
        if fill_layer.brushStyle() != Qt.BrushStyle.NoBrush and not self._transparent_fill(fill_layer):
            rules.append(rule_clone)
        return rules

    @staticmethod
    def _transparent_fill(fill_layer) -> bool:
        """A fill of a fully transparent colour (not data-defined) draws
        nothing in QGIS, like "No brush": no polygon is exported for it.
        Exported, an outline-only polygon covering a large area put a
        full-tile polygon into every tile inside it, up to the last zoom
        (hundreds of millions of tiles for an Arctic map); its outline
        stays, as lines."""
        if fill_layer.color().alpha() > 0:
            return False
        properties = fill_layer.dataDefinedProperties()
        return not properties.isActive(QgsSymbolLayer.Property.PropertyFillColor)

    def _vector_field_rules(self, flat_rule: FlattenedRule, field_layer, layer_idx: int):
        """A vector field marker: QGIS draws its line sub-symbol from each
        point to the point moved by the vector (x, y attributes; or length and
        angle; or a height) times the scale, in map units (project CRS) or on
        screen. Exported as a line geometry generator; screen distances get one
        rule per zoom, converted at the middle of the zoom."""
        from qgis.core import QgsGeometryGeneratorSymbolLayer, QgsVectorFieldSymbolLayer  # pylint: disable=import-outside-toplevel
        from .fidelity.units import normalize_unit  # pylint: disable=import-outside-toplevel
        from .materializer import _to_mm  # pylint: disable=import-outside-toplevel
        x_name, y_name = field_layer.xAttribute(), field_layer.yAttribute()
        x = f"to_real({QgsExpression.quotedColumnRef(x_name)})" if x_name else "0"
        y = f"to_real({QgsExpression.quotedColumnRef(y_name)})" if y_name else "0"
        kind = field_layer.vectorFieldType()
        if kind == QgsVectorFieldSymbolLayer.Polar:
            angle = y if field_layer.angleUnits() == QgsVectorFieldSymbolLayer.Radians else f"radians({y})"
            if field_layer.angleOrientation() == QgsVectorFieldSymbolLayer.ClockwiseFromNorth:
                dx, dy = f"{x} * sin({angle})", f"{x} * cos({angle})"
            else:
                dx, dy = f"{x} * cos({angle})", f"{x} * sin({angle})"
        elif kind == QgsVectorFieldSymbolLayer.Height:
            dx, dy = "0", y
        else:
            dx, dy = x, y
        if abs(field_layer.offset().x()) > 1e-9 or abs(field_layer.offset().y()) > 1e-9:
            self.diagnostics.add("Q2VT_SYMBOL_APPROXIMATE", "Vector field offset is not applied.",
                                 layer_id=flat_rule.layer.id(), rule_id=flat_rule.rule_id)
        project_crs = crs_ref(QgsProject.instance().crs()) or crs_ref(flat_rule.layer.crs())
        layer_crs = crs_ref(flat_rule.layer.crs())

        def generator(factor):
            point = "$geometry" if project_crs == layer_crs else \
                f"transform($geometry, '{layer_crs}', '{project_crs}')"
            line = (f"make_line({point}, translate({point}, ({dx}) * {factor!r}, "
                    f"({dy}) * {factor!r}))")
            if project_crs != layer_crs:
                line = f"transform({line}, '{project_crs}', '{layer_crs}')"
            gen = QgsGeometryGeneratorSymbolLayer.create({"geometryModifier": line, "SymbolType": "Line"})
            gen.setSubSymbol(field_layer.subSymbol().clone())
            gen.setRenderingPass(field_layer.renderingPass())
            return gen

        unit = field_layer.distanceUnit()
        scale = float(field_layer.scale())
        if normalize_unit(unit) == "map" or _to_mm(1.0, unit) is None:
            return self._generated_line_rules(flat_rule, generator(scale), layer_idx)
        rules = []
        # Every zoom the map is viewed at, overzoom included (on the last
        # tiles, within their budget: a line per feature and sub-symbol layer).
        features = self.materializer._layer_totals(flat_rule.layer)[2]  # pylint: disable=protected-access
        lines = features * max(field_layer.subSymbol().symbolLayerCount(), 1)
        for rule in self.materializer._per_zoom(flat_rule, overzoom=True, elements=lines):  # pylint: disable=protected-access
            zoom = self.materializer.rule_zoom(rule)
            factor = scale * _to_mm(1.0, unit) * ZoomLevels.map_units_per_mm(zoom) / math.sqrt(2)
            rules.extend(self._generated_line_rules(rule, generator(factor), layer_idx))
        return rules

    def _generated_line_rules(self, flat_rule: FlattenedRule, generator, layer_idx: int):
        """A geometry generator drawn with a line (or fill) symbol, as line
        (fill) rules on the generated geometry: one per sub-symbol layer,
        exported like the layers of a line (polygon) layer (exact marker
        positions, hash lines, offsets, materialized patterns, a fill's
        stroke as a line ...). ``pre_generator`` makes the exporter generate
        the geometry first and evaluate geometry-dependent properties on
        every generated part, as QGIS does
        (``length(geometry_n($geometry, @geometry_part_num))`` is one
        segment's length)."""
        sub_symbol = generator.subSymbol()
        kind = int(getattr(sub_symbol.type(), "value", sub_symbol.type()))
        expression = generator.geometryExpression()
        if kind == 2:
            # A fill sub-symbol draws polygons: QgsGeometryGeneratorSymbolLayer
            # coerces lines to MultiPolygon (each part closed into a ring);
            # points are not drawn.
            g = "@q2vt_generated"
            expression = (f"with_variable('q2vt_generated', {enclosed(expression)}, if(geometry_type({g}) = "
                          f"'Polygon', {g}, if(geometry_type({g}) = 'Line', if(is_multipart({g}), "
                          f"collect_geometries(array_foreach(generate_series(1, num_geometries({g})), "
                          f"make_polygon(geometry_n({g}, @element)))), make_polygon({g})), NULL)))")
        elif kind == 1:
            # A line sub-symbol draws lines: polygons are coerced to their
            # rings (MultiLineString), points are not drawn.
            g = "@q2vt_generated"
            expression = (f"with_variable('q2vt_generated', {enclosed(expression)}, if(geometry_type({g}) = "
                          f"'Line', {g}, if(geometry_type({g}) = 'Polygon', boundary({g}), NULL)))")
        rules = []
        clone_layer = None
        for inner_idx in reversed(range(sub_symbol.symbolLayerCount())):
            clone_layer = None  # may have been replaced (deleted) by materialize()
            inner = sub_symbol.symbolLayer(inner_idx)
            if not inner.enabled():
                continue
            rule_clone = flat_rule.derive()
            single = sub_symbol.clone()
            for remove_idx in reversed(range(single.symbolLayerCount())):
                if remove_idx != inner_idx:
                    single.deleteSymbolLayer(remove_idx)
            # The sub-symbol keeps its own opacity: QgsGeometryGeneratorSymbolLayer
            # renders it with its own render context (QgsSymbol::startRender
            # reads its mOpacity), never the parent symbol's opacity.
            rule_clone.rule.setSymbol(single)
            rule_clone.set_attr("g", kind)
            # Each fill sub-layer is drawn like a fill layer's: centroid
            # markers as points, line layers (an outline) on the rings.
            if kind == 2:
                rule_clone.set_attr("c", 0 if inner.layerType() == "CentroidFill"
                                    else int(getattr(inner.type(), "value", inner.type())))
            else:
                rule_clone.set_attr("c", kind)
            # A distinct dataset per sub-symbol layer (their recipes differ),
            # apart from the ordinary symbol layers' (s = their index): with
            # layer_idx * 100 the generator at layer 0 gave its sub-layer 1
            # the dataset of symbol layer 1, drawn on the source geometry.
            rule_clone.set_attr("s", (layer_idx + 1) * 100 + inner_idx)
            rule_clone.pre_generator = expression
            clone_layer = single.symbolLayers()[0]
            self._fold_enabled_property(rule_clone, clone_layer)
            draw_pass = generator.renderingPass() if self._honor_passes else 0
            order = (-flat_rule.get_attr("l"), draw_pass, 0, self._draw_seq, layer_idx, inner_idx)
            rule_clone.order = order + (0,)
            materialized = self.materializer.materialize(rule_clone, clone_layer)
            if materialized is not None:
                for part, component in enumerate(materialized):
                    component.order = order + (part,)
                rules.extend(materialized)
            elif kind == 2 and clone_layer.layerType() == "SimpleFill":
                rules.extend(self._simple_fill_rules(rule_clone, clone_layer, order))
            else:
                rules.append(rule_clone)
        return rules

    def _map_offset_shift(self, fill_layer, flat_rule: FlattenedRule) -> Optional[tuple]:
        """A simple fill's offset in map units or meters at scale as a shift
        of the polygon in project map units, y up (QgsSimpleFillSymbolLayer::
        renderPolygon translates the painter by it: x right, y down). A
        data-defined offset is shifted by its static value (reported as such
        by the converter). None when there is none, or a map unit scale
        limits it within the rule's zooms (then a zoom-curve translate draws
        it: a translated fill is cut at the tile edges when overzoomed). A
        data-defined offset: each feature's ("x,y" or [x, y]; not a point:
        the static one), as QGIS (QgsSymbolLayerUtils::toPoint); an idea of
        QGIS2VectorTiles 4.2 (GallPeters/QGIS2VectorTiles)."""
        from .fidelity.units import normalize_unit  # pylint: disable=import-outside-toplevel
        offset = fill_layer.offset()
        unit = normalize_unit(fill_layer.offsetUnit())
        key = QgsSymbolLayer.Property.PropertyOffset
        dd = fill_layer.dataDefinedProperties().property(key) \
            if fill_layer.dataDefinedProperties().isActive(key) else None
        if unit not in ("map", "m") or (dd is None and abs(offset.x()) <= 1e-9 and abs(offset.y()) <= 1e-9):
            return None
        scale = fill_layer.offsetMapUnitScale()
        min_zoom = flat_rule.get_attr("o") or 0
        if any(self._map_unit_scale_limits(value, unit, scale, min_zoom)
               for value in (offset.x(), offset.y())):
            self.diagnostics.add(
                "Q2VT_SYMBOL_APPROXIMATE", "Fill offset limited by a map unit scale is drawn "
                "as a translate: overzoomed tiles may show gaps at their edges.",
                layer_id=flat_rule.layer.id(), rule_id=flat_rule.rule_id)
            return None
        factor = 1.0
        if unit == "m":
            # QgsRenderContext::convertMetersToMapUnits: a plain unit factor
            # for projected CRSs, measured at the latitude for degrees.
            from qgis.core import QgsProject, QgsUnitTypes  # pylint: disable=import-outside-toplevel
            map_units = QgsProject.instance().crs().mapUnits()
            if map_units == Qgis.DistanceUnit.Degrees:
                context = self.lengths.map_context
                factor = context.mercator_per_meter / context.mercator_per_map_unit
            else:
                factor = QgsUnitTypes.fromUnitToUnitFactor(Qgis.DistanceUnit.Meters, map_units)
        if dd is not None:
            point = (f"with_variable('q2vt_o', {enclosed(dd.asExpression())}, "
                     "if(try(array_length(@q2vt_o)) IS NOT NULL, @q2vt_o, string_to_array(to_string(@q2vt_o), ',')))")
            # Not a point (QgsSymbolLayerUtils::toPoint fails): the static offset.
            ok = f"try(to_real(array_get({point}, 0))) IS NOT NULL AND try(to_real(array_get({point}, 1))) IS NOT NULL"
            x = f"if({ok}, to_real(array_get({point}, 0)), {offset.x()!r}) * {factor!r}"
            y = f"-if({ok}, to_real(array_get({point}, 1)), {offset.y()!r}) * {factor!r}"
            return x, y
        return offset.x() * factor, -offset.y() * factor

    def _map_unit_scale_limits(self, value: float, unit: str, scale, min_zoom: int) -> bool:
        """True if ``scale`` (a QgsMapUnitScale) changes the drawn size of
        ``value`` map units (meters) at some zoom from ``min_zoom`` to the
        curves' last zoom (QgsMapUnitScale::computeMapUnitsPerPixel, then
        the min/max size in mm)."""
        from .fidelity import units  # pylint: disable=import-outside-toplevel
        if abs(value) <= 1e-9:
            return False
        z_lo, z_hi = float(min_zoom), units.CURVE_MAX_ZOOM
        if scale.minScale and units.scale_to_zoom(scale.minScale) > z_lo:
            return True
        if scale.maxScale and units.scale_to_zoom(scale.maxScale) < z_hi:
            return True
        context = self.lengths.map_context
        per_unit = context.mercator_per_map_unit if unit == "map" else context.mercator_per_meter
        mm = units.physical_factor(units.MM, self.lengths.dpi)
        px_per_unit = per_unit * units.WORLD_SIZE_PX / units.EARTH_CIRCUMFERENCE
        if scale.minSizeMMEnabled and abs(value) * px_per_unit * 2.0 ** z_lo < scale.minSizeMM * mm:
            return True
        return bool(scale.maxSizeMMEnabled and
                    abs(value) * px_per_unit * 2.0 ** z_hi > scale.maxSizeMM * mm)

    @staticmethod
    def _fill_offset(fill_layer) -> Optional[tuple]:
        """A simple fill's offset as a rule translate: QGIS shifts the whole
        polygon, outline too (the fill itself is shifted by its own
        fill-translate), in any unit; map units keep their map unit scale."""
        from qgis.core import QgsUnitTypes  # pylint: disable=import-outside-toplevel
        from .fidelity.units import normalize_unit  # pylint: disable=import-outside-toplevel
        offset = fill_layer.offset()
        if abs(offset.x()) <= 1e-9 and abs(offset.y()) <= 1e-9:
            return None
        translate = (offset.x(), offset.y(), QgsUnitTypes.encodeUnit(fill_layer.offsetUnit()))
        if normalize_unit(fill_layer.offsetUnit()) in ("map", "m"):
            translate += (fill_layer.offsetMapUnitScale(),)
        return translate

    @staticmethod
    def _convert_fill_outline_to_line_symbol(fill_symbol: QgsFillSymbol) -> Optional[QgsFillSymbol]:
        """ Convert a QgsFillSymbol containing a single QgsSimpleFillSymbolLayer into 
        a cloned QgsFillSymbol containing a single QgsSimpleLineSymbolLayer representing
        the original outline.
        """
        if not isinstance(fill_symbol, QgsFillSymbol):
            return None

        layers = fill_symbol.symbolLayers()
        if len(layers) != 1:
            return None

        fill_layer = layers[0]
        if not isinstance(fill_layer, QgsSimpleFillSymbolLayer):
            return None

        new_symbol = fill_symbol.clone()
        line_layer = QgsSimpleLineSymbolLayer()

        line_layer.setColor(fill_layer.strokeColor())
        line_layer.setWidth(fill_layer.strokeWidth())
        line_layer.setWidthUnit(fill_layer.strokeWidthUnit())
        # Min/max size and scale limits of a map-unit outline (e.g. "max
        # 0.5 mm" to keep a border thin when zoomed in).
        line_layer.setWidthMapUnitScale(fill_layer.strokeWidthMapUnitScale())
        line_layer.setPenStyle(fill_layer.strokeStyle())
        line_layer.setPenJoinStyle(fill_layer.penJoinStyle())

        property_keys = [
            QgsSymbolLayer.Property.PropertyStrokeColor,
            QgsSymbolLayer.Property.PropertyStrokeWidth,
            QgsSymbolLayer.Property.PropertyStrokeStyle,
            QgsSymbolLayer.Property.PropertyJoinStyle
        ]

        for key in property_keys:
            prop = fill_layer.dataDefinedProperties().property(key)
            if prop is not None and prop.isActive():
                line_layer.setDataDefinedProperty(key, QgsProperty(prop))
        # The fill's paint effect (a blur, a glow) is drawn on its outline too.
        effect = fill_layer.paintEffect()
        if effect is not None and effect.enabled():
            line_layer.setPaintEffect(effect.clone())

        new_symbol.changeSymbolLayer(0, line_layer)

        return new_symbol


    # Leaders are drawn with the labels, above every layer's features.
    _CALLOUT_ORDER = (1 << 30, 0, 0, 0, 0)

    def _split_pinned_labels(self, label_rule: FlattenedRule) -> List[FlattenedRule]:
        """Separate labels with a data-defined position ("pinned" labels).

        QGIS places a label whose X and Y are both data-defined exactly at that
        point (layer CRS); other features of the rule are placed normally. The
        pinned features become their own point dataset, and a straight callout
        leader (if callouts are enabled) becomes a line dataset drawn with the
        callout's line symbol.
        """
        settings = label_rule.rule.settings()
        if settings is None:
            return [label_rule]
        props = settings.dataDefinedProperties()
        P = QgsPalLayerSettings.Property
        x_prop, y_prop = props.property(P.PositionX), props.property(P.PositionY)
        if not (x_prop and y_prop and x_prop.isActive() and y_prop.isActive()):
            return [label_rule]
        x, y = x_prop.asExpression(), y_prop.asExpression()
        # QGIS takes a position only when both convert to numbers (a text
        # that does not is no position: the label is placed normally).
        condition = f"try(to_real({enclosed(x)})) IS NOT NULL AND try(to_real({enclosed(y)})) IS NOT NULL"
        base_filter = label_rule.rule.filterExpression()

        free = label_rule.derive()
        free.rule.setFilterExpression(and_filters(base_filter, f"NOT ({condition})"))
        free_settings = free.rule.settings()
        free_props = free_settings.dataDefinedProperties()
        for key in (P.PositionX, P.PositionY):
            prop = free_props.property(key)
            prop.setActive(False)
            free_props.setProperty(key, prop)
        free_settings.setDataDefinedProperties(free_props)

        pinned = label_rule.derive()
        pinned.rule.setFilterExpression(and_filters(base_filter, condition))
        pinned.set_attr("p", 1)
        pinned.set_attr("c", 0)
        parts = [free, pinned]

        callout = settings.callout()
        if callout is not None and callout.enabled():
            leader = self._callout_leader(pinned, callout, x, y)
            if leader is not None:
                parts.append(leader)
        return parts

    def _callout_leader(self, pinned: FlattenedRule, callout, x: str, y: str):
        from .fidelity.materialize import Recipe  # pylint: disable=import-outside-toplevel
        symbol = callout.lineSymbol() if hasattr(callout, "lineSymbol") else None
        if symbol is None:
            self.diagnostics.add(
                "Q2VT_CALLOUT_APPROX", f"Callout type '{callout.type()}' is not exported.",
                layer_id=pinned.layer.id())
            return None
        if callout.type() != "simple":
            self.diagnostics.add(
                "Q2VT_CALLOUT_APPROX",
                f"'{callout.type()}' callouts are drawn as straight leaders.",
                layer_id=pinned.layer.id())
        self.diagnostics.add(
            "Q2VT_CALLOUT_APPROX",
            "Callout leaders end at the label's anchor point (QGIS: nearest point of "
            "the label box); pinned labels are always shown so leaders never dangle.",
            layer_id=pinned.layer.id())
        rule = QgsRuleBasedRenderer.Rule(symbol.clone())
        rule.setFilterExpression(pinned.rule.filterExpression())
        rule.setMinimumScale(pinned.rule.minimumScale())
        rule.setMaximumScale(pinned.rule.maximumScale())
        rule.setDescription(pinned.rule.description())
        try:
            anchor = int(getattr(callout.anchorPoint(), "value", callout.anchorPoint()))
        except (AttributeError, TypeError, ValueError):
            anchor = 0
        recipe = Recipe("callout", params=(("x", x), ("y", y), ("anchor", anchor),
                                           ("crs", crs_ref(pinned.layer.crs()))))
        leader = FlattenedRule(rule, pinned.layer, "", pinned.visibility, recipe,
                               self._CALLOUT_ORDER, provenance=self._leader_provenance(pinned))
        leader.set_attr("t", 0)
        leader.set_attr("c", 1)
        leader.set_attr("s", 0)
        return leader

    # Data-defined label properties that change a curved label's size, shape,
    # repeat or anchor per feature: such labels keep MapLibre's placement.
    _WINDOW_DDP = ("Size", "Bold", "Italic", "Family", "FontStyle", "FontSizeUnit", "FontCase",
                   "FontLetterSpacing", "FontWordSpacing", "FontStretchFactor", "RepeatDistance",
                   "RepeatDistanceUnit", "CurvedCharAngleInOut", "LabelAllParts",
                   "MultiLineWrapChar", "LineAnchorPercent", "LineAnchorType",
                   "LineAnchorTextPoint", "OverrunDistance", "CurvedLabelMode")

    # A repeated line label's repeat distance from which the web viewer lays
    # it out on the visible part of the line (CSS px, a tile): QGIS chops the
    # line clipped to the map extent, so the visible stretch always has a
    # label; labels laid out on the whole line (windows, MapLibre's own
    # spacing) this far apart left most views without one.
    VISIBLE_REPEAT_PX = 512.0

    def _split_line_label_windows(self, label_rule: FlattenedRule) -> List[FlattenedRule]:
        """A repeated curved line label as one rule per zoom whose labels are
        laid out at export time, as QGIS lays them out (core/label_lines.py,
        RulesExporter._label_windows). MapLibre's own line placement tries
        a few fixed anchors and dropped the labels of wiggly rivers at low
        zooms. Labels these windows cannot reproduce (data-defined size,
        font or repeat, generated or pinned positions, merged lines, ...)
        keep MapLibre's placement.

        From the zoom where the repeat distance is VISIBLE_REPEAT_PX, and
        always above the tile zooms (the windows and MapLibre's anchors are
        fixed on the whole line), the web viewer places the labels on the
        visible part of the line instead (_visible_repeat_rules)."""
        if label_rule.get_attr("t") != 1:
            return [label_rule]
        if curved_label_mode(label_rule.rule.settings()) == CURVED_AT_VERTICES:
            # One character at each vertex, no repeat (RulesExporter.
            # _label_chars_at_vertices).
            return [label_rule]
        visible_from = self._visible_repeat_zoom(label_rule)
        if not self._lays_out_windows(label_rule):
            return self._split_visible_repeat(label_rule, visible_from)
        low, high = label_rule.get_attr("o"), label_rule.get_attr("i")
        last = high if visible_from is None else min(high, visible_from - 1)
        rules = []
        for zoom in range(low, last + 1):
            recipe = self._label_window_recipe(label_rule, zoom)
            if recipe is None:
                return self._split_visible_repeat(label_rule, visible_from)
            rule = label_rule.derive()
            rule.set_attr("o", zoom)
            rule.set_attr("i", zoom)
            if label_rule.visibility is not None:
                # The last zoom keeps its overzoom unless the viewer takes it.
                end = None if zoom == high and visible_from is None else float(zoom + 1)
                rule.visibility = label_rule.visibility.intersect(ZoomInterval(float(zoom), end))
                if rule.visibility.is_empty:
                    continue
            rule.recipe = recipe
            rules.append(rule)
        if visible_from is not None:
            rules.extend(self._visible_repeat_rules(label_rule, visible_from))
        return rules or [label_rule]

    def _visible_repeat_zoom(self, label_rule: FlattenedRule) -> Optional[int]:
        """The first zoom from which the web viewer places a repeated line
        label (one past the tile zooms: only while overzooming; map-unit
        text: from tile zoom 17, where its windows no longer hold it), or None
        when it cannot (a data-defined repeat, generated or pinned
        positions...). QGIS's Horizontal placement on lines: at every zoom
        (MapLibre puts a point label on a line at its first vertex)."""
        from .maplibre_converter import (PropertyExtractor, QgisMapLibreStyleExporter,  # pylint: disable=import-outside-toplevel
                                         TextPropertyExtractor)
        settings = label_rule.rule.settings()
        if settings is None or label_rule.get_attr("g") != 1 or label_rule.get_attr("c") != 1 \
                or label_rule.recipe is not None or label_rule.pre_generator \
                or settings.geometryGeneratorEnabled:
            return None
        placement = TextPropertyExtractor.placement_name(settings)
        if placement not in ("Line", "Curved", "Horizontal") or float(settings.repeatDistance or 0) <= 0:
            return None
        P = QgsPalLayerSettings.Property
        props = settings.dataDefinedProperties()
        x_prop, y_prop = props.property(P.PositionX), props.property(P.PositionY)
        if x_prop and y_prop and x_prop.isActive() and y_prop.isActive():
            return None
        for key in (P.RepeatDistance, P.RepeatDistanceUnit):
            prop = props.property(key)
            if prop is not None and prop.isActive():
                return None
        low, high = label_rule.get_attr("o"), label_rule.get_attr("i")
        if placement == "Horizontal":
            return low
        try:
            repeat = self.lengths.static(settings.repeatDistance, settings.repeatDistanceUnit,
                                         PropertyExtractor.map_unit_scale(
                                             settings.repeatDistanceMapUnitScale))
            first = high + 1
            for zoom in range(low, high + 1):
                px = repeat if ex.is_number(repeat) else ex.evaluate_zoom_curve(repeat, zoom)
                if float(px) >= self.VISIBLE_REPEAT_PX:
                    first = zoom
                    break
            # Map-unit text: MapLibre's line check measures the label at
            # LINE_LABEL_FIT_ZOOM, beyond a window cut at tile zoom 17 or more.
            text_format = settings.format()
            size = self.lengths.static(text_format.size(), text_format.sizeUnit(),
                                       PropertyExtractor.map_unit_scale(text_format.sizeMapUnitScale()))
            if not ex.is_number(size):
                first = min(first, max(low, QgisMapLibreStyleExporter.LINE_LABEL_FIT_ZOOM - 1))
        except (ValueError, ex.ExpressionError):  # a unit without pixels (percentage)
            return None
        return first

    def _split_visible_repeat(self, label_rule: FlattenedRule,
                              visible_from: Optional[int]) -> List[FlattenedRule]:
        """The label as it is (MapLibre's placement) below ``visible_from``,
        placed by the web viewer from there on."""
        if visible_from is None:
            return [label_rule]
        low, high = label_rule.get_attr("o"), label_rule.get_attr("i")
        rules = []
        if visible_from > low:
            rule = label_rule.derive()
            rule.set_attr("i", min(high, visible_from - 1))
            visibility = label_rule.visibility or ZoomInterval(float(low), None)
            rule.visibility = visibility.intersect(ZoomInterval(float(low), float(visible_from)))
            if not rule.visibility.is_empty:
                rules.append(rule)
        rules.extend(self._visible_repeat_rules(label_rule, visible_from))
        return rules or [label_rule]

    @staticmethod
    def _visible_repeat_rules(label_rule: FlattenedRule, visible_from: int) -> List[FlattenedRule]:
        """The label from ``visible_from`` on, placed by the web viewer on the
        visible part of its lines (RulesExporter._single_line_label_as_point:
        exported at the line's middle, a point: target geometry 0). Above the
        tile zooms the deepest tiles hold the lines."""
        high = label_rule.get_attr("i")
        rule = label_rule.derive()
        rule.set_attr("o", min(visible_from, high))
        rule.set_attr("c", 0)
        rule.visible_repeat = True
        visibility = label_rule.visibility or ZoomInterval(float(label_rule.get_attr("o")), None)
        rule.visibility = visibility.intersect(ZoomInterval(float(visible_from), None))
        return [] if rule.visibility.is_empty else [rule]

    def _lays_out_windows(self, label_rule: FlattenedRule) -> bool:
        from .maplibre_converter import TextPropertyExtractor  # pylint: disable=import-outside-toplevel
        settings = label_rule.rule.settings()
        if settings is None or label_rule.get_attr("g") != 1 or label_rule.get_attr("c") != 1 \
                or label_rule.recipe is not None or label_rule.pre_generator:
            return False
        if TextPropertyExtractor.placement_name(settings) != "Curved" or \
                float(settings.repeatDistance or 0) <= 0 or settings.geometryGeneratorEnabled:
            return False
        line_settings = settings.lineSettings()
        if line_settings.mergeLines() or int(getattr(line_settings.anchorType(), "value",
                                                     line_settings.anchorType())) != 0:
            return False  # merged lines, a strict anchor
        if settings.wrapChar or settings.format().allowHtmlFormatting():
            return False
        # QGIS 4: lines split over the parts (one text per part), text
        # stretched to fill the line.
        if label_multipart_mode(settings) == MULTIPART_SPLIT or \
                curved_label_mode(settings) != CURVED_DEFAULT:
            return False
        P = QgsPalLayerSettings.Property
        props = settings.dataDefinedProperties()
        x_prop, y_prop = props.property(P.PositionX), props.property(P.PositionY)
        if x_prop and y_prop and x_prop.isActive() and y_prop.isActive():
            return False
        for name in self._WINDOW_DDP:
            key = getattr(P, name, None)
            prop = props.property(key) if key is not None else None
            if prop is not None and prop.isActive():
                return False
        # The windows replace the line: anything read from the geometry
        # (the text, a colour by length) would be read from a window.
        expressions = [prop.asExpression() for prop in
                       (props.property(key) for key in props.propertyKeys())
                       if prop is not None and prop.isActive()]
        if settings.isExpression:
            expressions.append(settings.fieldName)
        return not any(QgsExpression(text).needsGeometry() for text in expressions if text)

    def _label_window_recipe(self, label_rule: FlattenedRule, zoom: int):
        """Recipe("label_windows") of one zoom: CSS px of that tile zoom.

        ``size``: the text size MapLibre draws at the tile zoom; ``fit``: the
        size its line check measures the label with (map-unit text: the
        zoom-18 size, QgisMapLibreStyleExporter._line_label_zoom_split), over
        ``size``. QGIS cuts the line at the repeat distance at every scale;
        one cut serves a whole zoom, so it is made as at zoom + 0.5 (on screen
        the parts are then within 1/sqrt(2) to sqrt(2) of QGIS's): ``repeat``
        is that zoom's repeat distance in the tile zoom's px and ``chop`` the
        label width the cut is made with, over the drawn width."""
        from .fidelity.materialize import Recipe  # pylint: disable=import-outside-toplevel
        from .maplibre_converter import (PropertyExtractor, QgisMapLibreStyleExporter,  # pylint: disable=import-outside-toplevel
                                         TextPropertyExtractor)
        settings = label_rule.rule.settings()
        text_format = settings.format()

        def pixels(value, unit, scale, at):
            result = self.lengths.static(value, unit, PropertyExtractor.map_unit_scale(scale))
            return float(result if ex.is_number(result) else ex.evaluate_zoom_curve(result, at))
        try:
            size = pixels(text_format.size(), text_format.sizeUnit(),
                          text_format.sizeMapUnitScale(), zoom)
            fit_zoom = QgisMapLibreStyleExporter.LINE_LABEL_FIT_ZOOM
            fit = pixels(text_format.size(), text_format.sizeUnit(), text_format.sizeMapUnitScale(),
                         fit_zoom if zoom + 1 >= fit_zoom else zoom)
            middle = pixels(text_format.size(), text_format.sizeUnit(),
                            text_format.sizeMapUnitScale(), zoom + 0.5)
            repeat = pixels(settings.repeatDistance, settings.repeatDistanceUnit,
                            settings.repeatDistanceMapUnitScale, zoom + 0.5) / math.sqrt(2.0)
        except (ValueError, ex.ExpressionError):  # a unit without pixels (percentage)
            return None
        if size <= 0 or repeat <= 0:
            return None
        named = QgsTextFormat(text_format)
        if text_format.namedStyle():
            font = QFont(text_format.font())
            QgsFontUtils.updateFontViaStyle(font, text_format.namedStyle())
            named.setFont(font)
        font = TextPropertyExtractor.drawn_font(named)  # the face the glyphs are made from
        font.setLetterSpacing(QFont.SpacingType.PercentageSpacing, 100.0)
        font.setWordSpacing(0.0)
        font.setCapitalization(QFont.Capitalization.MixedCase)
        engine = QgsProject.instance().labelingEngineSettings()
        return Recipe("label_windows", params=(
            ("zoom", int(zoom)), ("size", size), ("fit", max(1.0, fit / size)),
            ("repeat", repeat), ("chop", middle / size / math.sqrt(2.0)),
            ("font", font.toString()),
            ("spacing", float(TextPropertyExtractor.get_text_letter_spacing(text_format))),
            ("transform", TextPropertyExtractor.get_text_transform(settings)),
            ("max_in", float(settings.maxCurvedCharAngleIn)),
            ("max_out", -abs(float(settings.maxCurvedCharAngleOut))),
            ("max_angle", float(TextPropertyExtractor.get_text_max_angle(settings))),
            ("anchor", float(settings.lineSettings().lineAnchorPercent())),
            ("per_part", label_multipart_mode(settings) != MULTIPART_LARGEST),
            ("candidates_per_cm", float(engine.maximumLineCandidatesPerCm())),
        ))

    def _split_by_matching_renderers(self, label_rule: FlattenedRule) -> List[FlattenedRule]:
        """Split a label rule into stretches of zooms with the same renderer
        rules: each labels the features any of them draws (QGIS labels only
        drawn features, each once). One copy per renderer rule labelled a
        feature drawn by two rules twice: a category and a filterless
        catch-all rule (fill and outline) gave every zone code two labels."""
        label_min, label_max = label_rule.get_attr("o"), label_rule.get_attr("i")
        all_runs = self._renderer_runs(label_rule.layer)
        runs = [(index, rule, span, visibility) for index, (rule, span, visibility)
                in enumerate(all_runs)
                if self._ranges_overlap(label_min, label_max, span[0], span[1])]
        cuts = {label_min, label_max + 1}
        for _, _, (low, high), _ in runs:
            cuts.update(z for z in (low, high + 1) if label_min < z <= label_max)
        cuts = sorted(cuts)
        stretches = []  # [first zoom, last zoom, active runs]
        for start, stop in zip(cuts, cuts[1:]):
            active = tuple(run for run in runs if run[2][0] <= start <= run[2][1])
            if not active:
                continue
            if stretches and stretches[-1][2] == active and stretches[-1][1] + 1 == start:
                stretches[-1][1] = stop - 1
            else:
                stretches.append([start, stop - 1, active])
        split_rules = []
        for low, high, active in stretches:
            split_rules.extend(self._stretch_label_rules(label_rule, active, low, high,
                                                         len(all_runs)))
        if split_rules or all_runs or label_rule.layer.id() in self._drawn_layers:
            # QGIS labels only the features its renderer draws: none where
            # no renderer rule is shown (they floated without symbols).
            return split_rules
        return [label_rule]  # no renderer rules (e.g. the "No symbols" renderer)

    def _stretch_label_rules(self, label_rule: FlattenedRule, active, low: int, high: int,
                             spare: int) -> List[FlattenedRule]:
        """The label rules of zooms ``low``..``high``, where the renderer rule
        runs ``active`` draw. Runs shown in other browser intervals (scale
        limits within a zoom) label where they are drawn: the browser range
        is cut at their intervals, and each piece labels the features of the
        runs shown there, once. A label rule per run interval labelled a
        feature twice where two intervals overlapped ([0, open) and
        [17.17, open): two symbol layers, one enabled by @map_scale).
        ``spare``: the first index no run has (a distinct "f" per piece)."""
        visibilities = [run[3] for run in active]
        if len(set(visibilities)) == 1:
            matched = self._match_label_to_renderers(label_rule, active, low, high)
            return [matched] if matched else []
        # A run without an interval is drawn over its tile zooms.
        stretch = ZoomInterval(float(low), None if high >= self.max_zoom else float(high + 1))
        shown = [stretch if visibility is None else visibility for visibility in visibilities]
        edges = sorted({edge for visibility in shown
                        for edge in (visibility.min_zoom, visibility.max_zoom) if edge is not None})
        pieces = []  # [interval, runs, label filter]
        for start, end in zip(edges, edges[1:] + [None]):
            piece = ZoomInterval(start, end)
            if piece.is_empty or piece.intersect(stretch).is_empty:
                continue
            runs = tuple(run for run, visibility in zip(active, shown)
                         if visibility.min_zoom <= start + 1e-9 and (
                             visibility.max_zoom is None
                             or (end is not None and visibility.max_zoom >= end - 1e-9)))
            if not runs:
                continue
            label_filter = self._renderers_label_filter(runs)
            previous = pieces[-1] if pieces else None
            if previous is not None and previous[2] == label_filter and \
                    previous[0].max_zoom is not None and abs(previous[0].max_zoom - start) < 1e-9:
                previous[0] = ZoomInterval(previous[0].min_zoom, end)
                continue
            pieces.append([piece, runs, label_filter])
        rules, used = [], set()
        for piece, runs, _ in pieces:
            # A distinct dataset per piece (two pieces may share a first run).
            index = next((run[0] for run in runs if run[0] not in used), None)
            if index is None:
                index, spare = spare, spare + 1
            used.add(index)
            matched = self._match_label_to_renderers(label_rule, runs, low, high, piece, index)
            if matched:
                rules.append(matched)
        return rules

    @staticmethod
    def _renderers_label_filter(active) -> str:
        """The features renderer rule runs ``active`` draw: their filters
        OR-ed (none if one of them has no filter)."""
        filters: Optional[List[str]] = []
        for _, renderer_rule, _, _ in active:
            # The features the rule renders: its filter before a symbol
            # layer's data-defined "enabled" was folded in, @map_scale unbound.
            expression = renderer_rule.label_filter if renderer_rule.label_filter is not None \
                else renderer_rule.renderer_filter()
            if not expression:
                filters = None
                break
            if expression not in filters:
                filters.append(expression)
        if filters is None:
            return ""
        if len(filters) == 1:
            return filters[0]
        return " OR ".join(enclosed(expression) for expression in filters)

    def _match_label_to_renderers(self, label_rule: FlattenedRule, active, low: int,
                                  high: int, visibility=None,
                                  index: Optional[int] = None) -> Optional[FlattenedRule]:
        """The label rule for zooms ``low``..``high``, where the renderer rule
        runs ``active`` draw: its filter is theirs OR-ed (none if one of them
        has no filter); shown over ``visibility`` (default: their intervals'
        hull)."""
        renderer_filter = self._renderers_label_filter(active)
        visibilities = [run[3] for run in active]
        if visibility is None and all(v is not None for v in visibilities):
            visibility = visibilities[0]
            for other in visibilities[1:]:
                visibility = self._visibility_hull(visibility, other)
        return self._match_label_to_renderer(label_rule, renderer_filter,
                                             active[0][0] if index is None else index,
                                             (low, high), visibility)

    def _renderer_runs(self, layer):
        """[(renderer rule, (first zoom, last zoom), visibility)] of a layer's
        renderer rules, in drawing order. A rule materialized per zoom (marker
        positions, effects, @map_scale splits) is many one-zoom slices of the
        same rule (the same rule index and depth): its contiguous zooms count
        as one renderer rule. Matching a label to the first slice alone showed
        the labels at that slice's zoom only (a river's labels with flow arrows
        only at the last zoom). Slices of a rule drawing other features (ELSE
        pieces, symbol layers with an enabled condition) are runs of their
        own; @map_scale slices compare their unbound filter (the first
        slice's bound filter labelled the features of the first zoom at
        every zoom)."""
        groups: Dict[tuple, list] = {}
        for renderer_rule in self.flattened_rules + self._invisible_rules:
            if renderer_rule.layer.id() != layer.id() or renderer_rule.get_attr("t") == 1:
                continue
            if renderer_rule.recipe is not None and renderer_rule.recipe.kind == "callout":
                continue
            if renderer_rule.diagram is not None:
                continue  # diagrams are drawn for features QGIS may not draw a symbol for
            filter_id = (renderer_rule.get_attr("r"), renderer_rule.get_attr("d"),
                         renderer_rule.renderer_filter())
            groups.setdefault(filter_id, []).append(renderer_rule)
        runs = []
        for rules in groups.values():
            current = None
            for rule in sorted(rules, key=lambda r: (r.get_attr("o"), r.get_attr("i"))):
                low, high, visibility = rule.get_attr("o"), rule.get_attr("i"), rule.visibility
                if current is not None and low <= current[1][1] + 1:
                    first, (start, end), seen = current
                    current = (first, (start, max(end, high)), self._visibility_hull(seen, visibility))
                    continue
                if current is not None:
                    runs.append(current)
                current = (rule, (low, high), visibility)
            if current is not None:
                runs.append(current)
        return runs

    @staticmethod
    def _visibility_hull(first, second):
        """The browser interval covering two touching intervals (None: unknown)."""
        if first is None or second is None:
            return None
        high = None if first.max_zoom is None or second.max_zoom is None \
            else max(first.max_zoom, second.max_zoom)
        return ZoomInterval(min(first.min_zoom, second.min_zoom), high)

    def _match_label_to_renderer(
        self,
        label_rule: FlattenedRule,
        renderer_filter: str,
        renderer_idx: int,
        span,
        renderer_visibility=None,
    ) -> Optional[FlattenedRule]:
        """Return a combined label/renderer rule if their zoom ranges overlap
        (``span``, ``renderer_visibility``: the renderer rules' zooms and
        browser interval; ``renderer_filter``: the features they draw)."""
        label_min, label_max = label_rule.get_attr("o"), label_rule.get_attr("i")
        renderer_min, renderer_max = span

        if not self._ranges_overlap(label_min, label_max, renderer_min, renderer_max):
            return None

        rule_clone = label_rule.derive()
        label_filter = rule_clone.rule.filterExpression()

        if label_filter and renderer_filter:
            combined = f"{enclosed(renderer_filter)} AND {enclosed(label_filter)}"
        else:
            combined = renderer_filter or label_filter or ""
        rule_clone.rule.setFilterExpression(combined)

        if label_min < renderer_min:
            rule_clone.set_attr("o", renderer_min)
        if label_max > renderer_max:
            rule_clone.set_attr("i", renderer_max)
        if label_rule.visibility is not None and renderer_visibility is not None:
            rule_clone.visibility = label_rule.visibility.intersect(renderer_visibility)
            if rule_clone.visibility.is_empty:
                return None

        rule_clone.set_attr("f", renderer_idx)
        return rule_clone

    @staticmethod
    def _ranges_overlap(r1_start: int, r1_end: int, r2_start: int, r2_end: int) -> bool:
        a_min, a_max = sorted((r1_start, r1_end))
        b_min, b_max = sorted((r2_start, r2_end))
        return a_min <= b_max and b_min <= a_max

    def _split_by_scale_expressions(self, flat_rule: FlattenedRule) -> List[FlattenedRule]:
        """Split a rule whose expressions read the map scale (@map_scale,
        @zoom_level, @vector_tile_zoom) into pieces with the scale bound.

        Expressions that only compare the scale with numbers change value at
        those scales: the rule is cut exactly there (a zoom's slice valued at
        its start switched up to a zoom late). Others change at every scale:
        one piece per zoom, valued at its start. Both go on beyond the
        archive's last zoom, up to ``overzoom_top`` (then open), drawn from
        its tiles: the last zoom's value was kept, so "@map_scale < 2000"
        never showed in a 0-16 export, even at zoom 22.
        """
        text = self._scale_dependency_text(flat_rule)
        if text is None:
            return [flat_rule]
        interval = self._split_interval(flat_rule)
        if interval.is_empty:
            return []
        thresholds = scale_thresholds(text)
        if thresholds is None:
            cuts = [float(zoom) for zoom in range(int(math.floor(interval.min_zoom + 1e-9)) + 1,
                                                  self.overzoom_top + 1)]
        else:
            cuts = [fidelity_zoom.scale_to_zoom(scale) for scale in thresholds]
        edges = [interval.min_zoom] + sorted(
            {zoom for zoom in cuts if zoom > interval.min_zoom + 1e-9 and interval.contains(zoom)}
        ) + [interval.max_zoom]
        # Neighbouring zooms whose expressions all have the same value are
        # one piece (no copy of the last zoom's data per overzoom zoom).
        expressions = self._scale_expressions(flat_rule, text) if thresholds is None else None
        pieces = []  # [interval, zoom valued at, values]
        for low, high in zip(edges[:-1], edges[1:]):
            piece = ZoomInterval(low, high)
            if piece.is_empty:
                continue
            if thresholds is None:
                at = math.floor(low + 1e-9)  # the zoom's start, as within a tile zoom
            else:
                at = low + 0.5 if high is None else (low + high) / 2.0  # same value throughout
            values = self._scale_values(expressions, at, flat_rule.layer)
            if pieces and values is not None and values == pieces[-1][2]:
                pieces[-1][0] = ZoomInterval(pieces[-1][0].min_zoom, high)
                continue
            pieces.append([piece, at, values])
        split_rules = []
        for piece, at, _ in pieces:
            clone = self._create_zoom_specific_rule(flat_rule, piece, at)
            if clone is not None and (flat_rule.get_attr("t") == 1 or
                                      self._symbol_layer_visible_at_zoom(clone, at)):
                split_rules.append(clone)
        self.materializer.distinguish(split_rules)
        return split_rules

    def _scale_expressions(self, flat_rule: FlattenedRule, text: str) -> Optional[List[str]]:
        """The rule's expressions that read the map scale, if none reads a
        feature and they are all of the scale reads in ``text`` (its
        serialized XML); else None (their values cannot be compared)."""
        found = [flat_rule.rule.filterExpression()]

        def collect(properties):
            for key in properties.propertyKeys():
                prop = properties.property(key)
                if prop.isActive():
                    found.append(prop.asExpression())

        def walk(symbol):
            if symbol is None:
                return
            collect(symbol.dataDefinedProperties())
            for index in range(symbol.symbolLayerCount()):
                collect(symbol.symbolLayer(index).dataDefinedProperties())
                walk(symbol.symbolLayer(index).subSymbol())

        if flat_rule.get_attr("t") == 1:
            settings = flat_rule.rule.settings()
            if settings is not None:
                found.append(settings.getLabelExpression().expression())
                collect(settings.dataDefinedProperties())
                # Keep the copied text format alive while its properties are read.
                text_format = settings.format()
                collect(text_format.dataDefinedProperties())
        else:
            walk(flat_rule.rule.symbol())
        if flat_rule.pre_generator:
            found.append(flat_rule.pre_generator)
        found = [expression for expression in found if uses_map_scale(expression)]
        if sum(map_scale_reads(expression) for expression in found) != map_scale_reads(text) or \
                any(self._is_feature_dependent(expression) for expression in found):
            return None
        # A variable set only while rendering (@symbol_color, @map_rotation)
        # is NULL here: every zoom would look alike and merge into one piece.
        from qgis.core import QgsExpressionContext, QgsExpressionContextUtils  # pylint: disable=import-outside-toplevel
        known = set(SCALE_VARIABLES) | set(map_view.VIEW_VARIABLES) | set(QgsExpressionContext(
            QgsExpressionContextUtils.globalProjectLayerScopes(flat_rule.layer)).variableNames())
        if any(set(QgsExpression(expression).referencedVariables()) - known
               for expression in found):
            return None
        return found

    @staticmethod
    def _scale_values(expressions: Optional[List[str]], zoom: float, layer) -> Optional[tuple]:
        """The values of feature-independent ``expressions`` at a zoom's
        scale; None if unknown."""
        if expressions is None:
            return None
        from qgis.core import QgsExpressionContext, QgsExpressionContextUtils  # pylint: disable=import-outside-toplevel
        context = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer)
                                       + [map_view.scope()])
        values = []
        for text in expressions:
            expression = QgsExpression(with_map_scale(text, fidelity_zoom.zoom_to_scale(zoom)))
            value = expression.evaluate(context)
            if expression.hasEvalError():
                return None
            values.append(repr(value))
        return tuple(values)

    def _split_interval(self, flat_rule: FlattenedRule) -> ZoomInterval:
        """The browser interval a rule is drawn in: its visibility within its
        tile zooms, and beyond the last tile zoom while overzooming."""
        low, high = flat_rule.get_attr("o"), flat_rule.get_attr("i")
        top = None if self.overzoom == OverzoomPolicy.PERSIST else float(self.max_zoom + 1)
        window = ZoomInterval(float(low), float(high + 1) if high < self.max_zoom else top)
        return (flat_rule.visibility or window).intersect(window)

    def _symbol_layer_visible_at_zoom(self, flat_rule: FlattenedRule, zoom: float) -> bool:
        """Return False if the symbol layer's visibility DDP evaluates to falsy at the zoom."""
        symbol = flat_rule.rule.symbol()
        if not symbol:
            return True
        symbol_layer = symbol.symbolLayers()[0]
        vis_prop = symbol_layer.dataDefinedProperties().property(
            QgsSymbolLayer.Property.PropertyLayerEnabled
        )
        if vis_prop and vis_prop.isActive():
            scale = fidelity_zoom.zoom_to_scale(zoom)
            if self._is_feature_dependent(vis_prop.expressionString()):
                return True  # feature dependent: folded into the rule filter
            expression = QgsExpression(with_map_scale(vis_prop.expressionString(), scale))
            evaluation = expression.evaluate(map_view.context())
            if not expression.hasEvalError() and evaluation is not None and not evaluation:
                return False
        return True

    def _scale_dependency_text(self, flat_rule: FlattenedRule) -> Optional[str]:
        """The rule's serialized XML (its expressions, and the expression of
        the geometry generator it is drawn on) if it reads the map scale
        (@map_scale, @zoom_level, @vector_tile_zoom), else None."""
        doc = QDomDocument("style")
        context = QgsReadWriteContext()
        rule_clone = flat_rule.rule.clone()

        if flat_rule.get_attr("t") == 1:
            root = QgsRuleBasedLabeling.Rule(None)
            root.appendChild(rule_clone)
            elem = QgsRuleBasedLabeling(root).save(doc, context)
        else:
            root = QgsRuleBasedRenderer.Rule(None)
            root.appendChild(rule_clone)
            elem = QgsRuleBasedRenderer(root).save(doc, context)

        doc.appendChild(elem)
        _drop_inactive_properties(elem)
        text = html.unescape(doc.toString())
        if flat_rule.pre_generator:
            text = f"{text}\n{flat_rule.pre_generator}"
        return text if uses_map_scale(text) else None

    def _create_zoom_specific_rule(self, flat_rule: FlattenedRule, piece: ZoomInterval,
                                   zoom: float) -> Optional[FlattenedRule]:
        """Clone a rule for the browser interval ``piece`` with the map scale
        bound to that of ``zoom``; None if its filter is then always false.

        Its data comes from the tile zooms of ``piece``; beyond the last
        tile zoom, from that zoom's tiles."""
        rule_clone = flat_rule.derive()
        scale = fidelity_zoom.zoom_to_scale(zoom)

        filter_exp = flat_rule.rule.filterExpression()
        if uses_map_scale(filter_exp):
            bound = with_map_scale(filter_exp, scale)
            if self._always_false(bound, filter_exp, flat_rule.layer):
                return None
            rule_clone.rule.setFilterExpression(bound)
            rule_clone.unbound_filter = flat_rule.renderer_filter()
        # label_filter stays unbound like unbound_filter: labels are matched
        # to it, then bound at their own zoom.
        if flat_rule.pre_generator and uses_map_scale(flat_rule.pre_generator):
            rule_clone.pre_generator = with_map_scale(flat_rule.pre_generator, scale)

        if flat_rule.get_attr("t") == 1 and flat_rule.rule.settings():
            settings = flat_rule.rule.settings()
            label_exp = settings.getLabelExpression().expression()
            if label_exp and uses_map_scale(label_exp):
                clone_settings = rule_clone.rule.settings()
                clone_settings.fieldName = with_map_scale(label_exp, scale)
                clone_settings.isExpression = True

        first, last = flat_rule.get_attr("o"), min(flat_rule.get_attr("i"), self.max_zoom)
        low = min(max(first, int(math.floor(piece.min_zoom + 1e-9))), last)
        high = last if piece.max_zoom is None else \
            max(low, min(last, int(math.ceil(piece.max_zoom - 1e-9)) - 1))
        rule_clone.set_attr("o", low)
        rule_clone.set_attr("i", high)
        rule_clone.visibility = piece
        rule_clone.scale_zoom = float(zoom)
        return rule_clone

    def _always_false(self, bound: str, original: str, layer) -> bool:
        """True if a filter that reads no feature is false (at its bound
        scale): the piece draws nothing."""
        if self._is_feature_dependent(original):
            return False
        from qgis.core import QgsExpressionContext, QgsExpressionContextUtils  # pylint: disable=import-outside-toplevel
        expression = QgsExpression(bound)
        value = expression.evaluate(QgsExpressionContext(
            QgsExpressionContextUtils.globalProjectLayerScopes(layer) + [map_view.scope()]))
        return not expression.hasEvalError() and isinstance(value, (bool, int, float)) and not value
