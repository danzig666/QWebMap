"""
S3-compatible object storage provider (boto3/botocore).

* SDK: the QGIS Python's own boto3 when installed and new enough for
  conditional writes, else the pinned vendored copy (src/publishing/vendor/s3:
  boto3/botocore/s3transfer from there as a whole; its other packages are
  appended at the *end* of sys.path so other plugins' packages keep
  precedence). Explicit credentials only: the SDK
  never falls back to ambient credentials (environment, ~/.aws, instance
  roles). TLS certificates are always verified.
* Immutable release objects are created with ``If-None-Match: *`` where the
  service supports conditional writes; ``current.json`` is replaced with
  ``If-Match: <etag>`` (or created with ``If-None-Match: *``).
* Large files use multipart uploads; a private journal (never published)
  records upload ids and part ETags so an interrupted upload resumes.
* Transient failures (timeouts, 429, 5xx, connection errors) are retried
  with exponential backoff and jitter within a bounded budget; permission
  and credential errors are not retried.
"""

import gzip
import importlib.machinery
import json
import os
import re
import random
import sys
import threading
import time
from typing import Callable, List, Optional, Tuple

from ..errors import Cancelled, PublishingError
from .base import Credentials, Provider, ProviderError

# Label fonts (glyph ranges, each 30-100 KB of protobuf that compresses to a
# fifth) are stored gzip-compressed with Content-Encoding: gzip: storage
# services and CDNs do not reliably compress application/x-protobuf, and a
# map's first view loads a dozen of them. Never the archives (PMTiles are
# read by byte ranges, which an outer encoding breaks).
_COMPRESSED = re.compile(r"(?:^|/)glyphs/[^/]+/[^/]+\.pbf$")


def stored_compressed(relative: str) -> bool:
    """Whether ``relative`` is uploaded gzip-compressed (Content-Encoding)."""
    return bool(_COMPRESSED.search(relative))


def _gzip(data: bytes) -> bytes:
    return gzip.compress(data, compresslevel=9, mtime=0)  # (the same bytes every time)

VENDOR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vendor", "s3")
MIN_PART = 5 * 1024 * 1024
DEFAULT_PART = 16 * 1024 * 1024
MAX_PARTS = 10000
_SDK_LOCK = threading.Lock()


_SDK = None
_SDK_PACKAGES = ("boto3", "botocore", "s3transfer")


def _from_vendor(module) -> bool:
    path = getattr(module, "__file__", None) or ""
    return os.path.realpath(path).startswith(os.path.realpath(VENDOR) + os.sep)


def _has_conditional_writes() -> bool:
    """Whether the importable botocore knows If-Match/If-None-Match on
    PutObject and CompleteMultipartUpload (late 2024, botocore 1.35.x): an
    older one rejects them client-side, and every release write fails."""
    try:
        from botocore.loaders import create_loader  # pylint: disable=import-outside-toplevel
        shapes = create_loader().load_service_model("s3", "service-2")["shapes"]
        return {"IfMatch", "IfNoneMatch"} <= set(shapes["PutObjectRequest"]["members"]) \
            and "IfNoneMatch" in shapes["CompleteMultipartUploadRequest"]["members"]
    except Exception:  # noqa: BLE001 - any doubt: the vendored copy
        return False


class _VendorFinder:
    """Finds boto3/botocore/s3transfer in the vendored copy only (their
    submodules follow the package); every other package (urllib3, dateutil,
    ...) still comes from the system first."""
    q2vt_vendor = VENDOR

    @staticmethod
    def find_spec(name, path=None, target=None):
        if path is None and name in _SDK_PACKAGES:
            return importlib.machinery.PathFinder.find_spec(name, [VENDOR])
        return None


def _load_sdk():
    try:
        import boto3  # pylint: disable=import-outside-toplevel
        import botocore  # noqa: F401  pylint: disable=import-outside-toplevel,unused-import
        # Both: a VENDOR left on sys.path (an in-session upgrade) can give
        # the vendored boto3 over a system botocore.
        if (_from_vendor(boto3) and _from_vendor(botocore)) or _has_conditional_writes():
            return boto3
    except Exception:  # noqa: BLE001 - a mixed pair can fail with any error (AttributeError)
        pass
    # Missing, partial (a system botocore without boto3) or too old: the
    # vendored SDK as a whole, never its boto3 over another botocore. This
    # swaps the SDK for the whole QGIS process: a plugin that already holds
    # the old modules keeps them, but its later imports (and the ClientError
    # they raise) are the vendored ones. No private copy is possible: boto3
    # imports itself and botocore by absolute name.
    for name in [n for n in sys.modules if n.split(".")[0] in _SDK_PACKAGES]:
        if not _from_vendor(sys.modules[name]):
            del sys.modules[name]
    if not any(getattr(f, "q2vt_vendor", None) == VENDOR for f in sys.meta_path):
        sys.meta_path.insert(0, _VendorFinder())
    if VENDOR not in sys.path:
        sys.path.append(VENDOR)  # its dependencies, when the system has none
    try:
        import boto3  # pylint: disable=import-outside-toplevel,redefined-outer-name
    except ImportError as error:
        raise PublishingError("Q2VT_PUB_DEPENDENCY",
                              f"The S3 library could not be loaded: {error}") from error
    return boto3


def sdk():
    """(boto3, botocore.config.Config, botocore.exceptions): the system SDK
    when it can do conditional writes, else the vendored one."""
    global _SDK  # pylint: disable=global-statement
    with _SDK_LOCK:
        if _SDK is None:
            boto3 = _load_sdk()
            from botocore.config import Config  # pylint: disable=import-outside-toplevel
            from botocore import exceptions  # pylint: disable=import-outside-toplevel
            _SDK = boto3, Config, exceptions
        return _SDK


def sdk_versions() -> dict:
    boto3, _, _ = sdk()
    import botocore  # pylint: disable=import-outside-toplevel
    return {"boto3": boto3.__version__, "botocore": botocore.__version__,
            "vendored": _from_vendor(boto3)}


RETRYABLE_CODES = {"RequestTimeout", "SlowDown", "Throttling", "OperationAborted",
                   "ThrottlingException", "InternalError", "ServiceUnavailable",
                   "TooManyRequests", "503", "500", "502", "504", "429"}
CREDENTIAL_CODES = {"AccessDenied", "InvalidAccessKeyId", "SignatureDoesNotMatch",
                    "ExpiredToken", "InvalidToken", "Unauthorized", "403", "401"}
# Not a bare 409: OperationAborted (409) is a transient clash, not a publisher.
CONFLICT_CODES = {"PreconditionFailed", "412", "ConditionalRequestConflict"}


class S3Provider(Provider):
    kind = "s3"

    def __init__(self, destination, credentials: Optional[Credentials], prefix: str, client=None,
                 part_size: int = DEFAULT_PART, max_retries: int = 5,
                 sleep: Callable[[float], None] = time.sleep, conditional_writes: Optional[bool] = None):
        super().__init__(prefix)
        if not destination.bucket:
            raise PublishingError("Q2VT_PUB_DESTINATION", "No bucket configured.")
        self.destination = destination
        self.bucket = destination.bucket
        self.credentials = credentials
        self.endpoint = self._endpoint(destination)
        self.region = destination.region or "auto"
        self.part_size = max(MIN_PART, part_size)
        self.max_retries = max_retries
        self.sleep = sleep
        self.conditional_writes = destination.conditional_writes if conditional_writes is None \
            else conditional_writes
        self._client = client

    @staticmethod
    def _endpoint(destination) -> str:
        return destination.endpoint

    # -- client ------------------------------------------------------------------------
    def client_config(self, Config):  # noqa: N803 - botocore class
        base = dict(signature_version="s3v4", retries={"max_attempts": 1, "mode": "standard"},
                    connect_timeout=20, read_timeout=120, s3={"addressing_style": "path"})
        # botocore 1.36+ sends a CRC32 (aws-chunked) on every upload by
        # default; many S3-compatible services (R2, older MinIO/Ceph, B2,
        # Wasabi, ...) reject it. Only where an operation requires one.
        try:
            return Config(**base, request_checksum_calculation="when_required",
                          response_checksum_validation="when_required")
        except TypeError:  # older botocore without these options (and without the default)
            return Config(**base)

    @property
    def client(self):
        if self._client is None:
            if self.credentials is None:
                raise PublishingError("Q2VT_PUB_CREDENTIALS", "No credentials for this destination.")
            boto3, Config, _ = sdk()
            session = boto3.session.Session(
                aws_access_key_id=self.credentials.access_key_id,
                aws_secret_access_key=self.credentials.secret_access_key,
                aws_session_token=self.credentials.session_token or None,
                region_name=self.region)
            # A fresh Session with explicit keys: no environment/profile/instance
            # credentials are consulted. verify=True: certificates are checked.
            self._client = session.client("s3", endpoint_url=self.endpoint or None, verify=True,
                                          config=self.client_config(Config))
        return self._client

    # -- error handling ----------------------------------------------------------------
    @staticmethod
    def _code(error) -> Tuple[str, int]:
        response = getattr(error, "response", None) or {}
        code = str((response.get("Error") or {}).get("Code", ""))
        status = int((response.get("ResponseMetadata") or {}).get("HTTPStatusCode", 0) or 0)
        return code, status

    def _classify(self, error) -> ProviderError:
        code, status = self._code(error)
        name = type(error).__name__
        text = self._redact(f"{name}: {code or ''} {status or ''} {error}")
        # The error code first: a status is ambiguous (RequestTimeTooSkewed
        # comes as 403, OperationAborted as 409).
        if code == "RequestTimeTooSkewed":
            return ProviderError("Q2VT_PUB_UPLOAD", "The storage refused the request because this "
                                 "computer's clock is wrong; set the date and time (automatically) "
                                 "and try again.", detail=text)
        if code in CONFLICT_CODES or (not code and status == 412):
            return ProviderError("Q2VT_PUB_ACTIVATION_CONFLICT", "The object changed meanwhile.", detail=text)
        if code in CREDENTIAL_CODES or (code not in RETRYABLE_CODES and status in (401, 403)):
            return ProviderError("Q2VT_PUB_CREDENTIALS", "The storage refused the credentials or "
                                 "the key has no permission for this bucket/prefix.", detail=text)
        if code in ("NoSuchBucket",):
            return ProviderError("Q2VT_PUB_DESTINATION", f"Bucket '{self.bucket}' does not exist.", detail=text)
        retryable = code in RETRYABLE_CODES or str(status) in RETRYABLE_CODES or status >= 500 or \
            name in ("EndpointConnectionError", "ConnectTimeoutError", "ReadTimeoutError",
                     "ConnectionClosedError", "ConnectionError", "ProxyConnectionError",
                     "ResponseStreamingError", "IncompleteReadError")
        return ProviderError("Q2VT_PUB_UPLOAD", "Object storage request failed.", retryable, text)

    def _redact(self, text: str) -> str:
        for secret in (self.credentials.secrets() if self.credentials else []):
            text = text.replace(secret, "***")
        return text

    def _call(self, name: str, progress=None, **params):
        """Call a client method with bounded retries for transient failures."""
        return self._retried(lambda: getattr(self.client, name)(**params), progress)

    def _retried(self, operation, progress=None):
        """``operation()`` with bounded retries for transient failures."""
        attempt = 0
        while True:
            if progress is not None and progress.canceled():
                raise Cancelled()
            try:
                return operation()
            except Exception as error:  # noqa: BLE001 - classified below
                if isinstance(error, (PublishingError, Cancelled)):
                    raise
                failure = self._classify(error)
                attempt += 1
                if not failure.retryable or attempt > self.max_retries:
                    raise failure from error
                delay = min(30.0, 0.5 * 2 ** attempt) * (0.5 + random.random())
                self.sleep(delay)

    def _not_found(self, error) -> bool:
        code, status = self._code(error)
        return code in ("404", "NoSuchKey", "NotFound") or status == 404

    # -- operations --------------------------------------------------------------------
    def inspect(self) -> List[Tuple[str, bool, str]]:
        checks = []
        try:
            self._call("head_bucket", Bucket=self.bucket)
            checks.append(("bucket", True, f"Bucket '{self.bucket}' reachable."))
        except PublishingError as error:
            checks.append(("bucket", False, error.message))
            return checks
        try:
            self._call("list_objects_v2", Bucket=self.bucket, Prefix=self.prefix + "/", MaxKeys=1)
            checks.append(("list", True, f"Prefix '{self.prefix}/' can be listed."))
        except PublishingError as error:
            checks.append(("list", False, error.message))
        return checks

    def head(self, relative: str) -> Optional[dict]:
        try:
            response = self._call("head_object", Bucket=self.bucket, Key=self.key(relative))
        except PublishingError as error:
            if self._not_found(error.__cause__):
                return None
            raise
        return {"size": response.get("ContentLength"), "etag": response.get("ETag"),
                "metadata": response.get("Metadata") or {}, "contentType": response.get("ContentType"),
                "contentEncoding": response.get("ContentEncoding") or ""}

    def put_bytes(self, relative: str, data: bytes, content_type: str, cache_control: str,
                  if_match: Optional[str] = None, if_none_match: bool = False, sha256: str = "",
                  content_encoding: str = "") -> str:
        params = {"Bucket": self.bucket, "Key": self.key(relative), "Body": data,
                  "ContentType": content_type, "CacheControl": cache_control}
        if content_encoding:
            params["ContentEncoding"] = content_encoding
        if sha256:
            params["Metadata"] = {"sha256": sha256}
        if if_match and self.conditional_writes:
            params["IfMatch"] = if_match
        if if_none_match and self.conditional_writes:
            params["IfNoneMatch"] = "*"
        try:
            response = self._call("put_object", **params)
        except PublishingError as error:
            same = self._already_there(error, relative, sha256, len(data)) if if_none_match else None
            if same is None:
                raise
            return same
        return response.get("ETag", "")

    def _already_there(self, error, relative: str, sha256: str, size: int,
                       gone: bool = False) -> Optional[str]:
        """After a precondition failure on a create (or ``gone``: a completed
        multipart upload no longer found): the object's ETag when it is this
        very content (a retry of a write whose answer was lost: the first
        attempt stored it), else None."""
        if (error.code != "Q2VT_PUB_ACTIVATION_CONFLICT" and not gone) or not sha256:
            return None
        existing = self.head(relative)
        if existing and (existing.get("metadata") or {}).get("sha256") == sha256 \
                and existing.get("size") == size:
            return existing.get("etag") or ""
        return None

    def put_entry_aliases(self, index_html: bytes, cache_control: str) -> bool:
        """Object storage has no directory index: ``/maps/arlo/`` and
        ``/maps/arlo`` are objects of their own. ``<prefix>/`` gets the stable
        entry itself (its relative links resolve inside the publication);
        ``<prefix>`` a redirect to it (relative links there would resolve one
        level up)."""
        folder = self.prefix.rsplit("/", 1)[-1]
        redirect = (
            '<!doctype html><html><head><meta charset="utf-8">'
            f'<meta http-equiv="refresh" content="0; url={folder}/">'
            '<meta name="referrer" content="no-referrer"><title>…</title></head>'
            f'<body><a href="{folder}/">{folder}/</a></body></html>').encode("utf-8")
        # Optional: a host that cannot store a key ending in "/" or a key
        # that is also a prefix (some S3-compatible servers) keeps index.html.
        for key, body in ((f"{self.prefix}/", index_html), (self.prefix, redirect)):
            try:
                self._call("put_object", Bucket=self.bucket, Key=key, Body=body,
                           ContentType="text/html; charset=utf-8", CacheControl=cache_control)
            except PublishingError:
                return key == self.prefix  # the redirect alone is optional
        return True

    def get_bytes(self, relative: str) -> Optional[Tuple[bytes, str]]:
        def fetch():  # the body is read inside the retries too (a reset mid-read)
            response = self.client.get_object(Bucket=self.bucket, Key=self.key(relative))
            return response["Body"].read(), response.get("ETag", "")
        try:
            return self._retried(fetch)
        except PublishingError as error:
            if self._not_found(error.__cause__):
                return None
            raise

    def put_file(self, relative: str, path: str, content_type: str, cache_control: str,
                 sha256: str, progress=None, journal=None) -> str:
        compressed = None
        if stored_compressed(relative):  # (sha256: of the file itself, as in release.json)
            with open(path, "rb") as handle:
                compressed = _gzip(handle.read())
        size = len(compressed) if compressed is not None else os.path.getsize(path)
        existing = self.head(relative)
        if existing and existing["metadata"].get("sha256") == sha256 and existing["size"] == size:
            return existing["etag"]  # already uploaded (retry/resume)
        if existing:
            raise ProviderError("Q2VT_PUB_UPLOAD", f"{relative} already exists with other content; "
                                "release objects are immutable.")
        if compressed is not None:
            return self.put_bytes(relative, compressed, content_type, cache_control,
                                  if_none_match=True, sha256=sha256, content_encoding="gzip")
        if size <= self.part_size:
            with open(path, "rb") as handle:
                data = handle.read()
            return self.put_bytes(relative, data, content_type, cache_control,
                                  if_none_match=True, sha256=sha256)
        return self._multipart(relative, path, size, content_type, cache_control, sha256,
                               progress, journal)

    def copy_object(self, source_relative: str, relative: str, content_type: str,
                    cache_control: str, sha256: str) -> Optional[str]:
        existing = self.head(relative)
        if existing and existing["metadata"].get("sha256") == sha256:
            return existing["etag"]  # already there (retry/resume)
        if existing:
            raise ProviderError("Q2VT_PUB_UPLOAD", f"{relative} already exists with other content; "
                                "release objects are immutable.")
        extra = {}
        if stored_compressed(relative):
            # Copied only from a compressed copy (releases before 4.59 stored
            # the fonts as they are): else None, and it is uploaded.
            source = self.head(source_relative)
            if not source or source.get("contentEncoding") != "gzip":
                return None
            extra["ContentEncoding"] = "gzip"
        response = self._call(
            "copy_object", Bucket=self.bucket, Key=self.key(relative),
            CopySource={"Bucket": self.bucket, "Key": self.key(source_relative)},
            MetadataDirective="REPLACE", ContentType=content_type, CacheControl=cache_control,
            Metadata={"sha256": sha256}, **extra)
        return (response.get("CopyObjectResult") or {}).get("ETag", "")

    def _multipart(self, relative, path, size, content_type, cache_control, sha256, progress, journal):
        part_size = max(self.part_size, -(-size // MAX_PARTS))
        key = self.key(relative)
        state = journal.get(relative) if journal is not None else None
        upload_id = state.get("uploadId") if state and state.get("sha256") == sha256 else None
        parts = {}
        if upload_id:
            try:  # reconcile with what the service has
                listed = self._call("list_parts", Bucket=self.bucket, Key=key, UploadId=upload_id)
                parts = {p["PartNumber"]: p["ETag"] for p in listed.get("Parts", [])}
            except PublishingError:
                upload_id = None
        if not upload_id:
            created = self._call("create_multipart_upload", Bucket=self.bucket, Key=key,
                                 ContentType=content_type, CacheControl=cache_control,
                                 Metadata={"sha256": sha256})
            upload_id = created["UploadId"]
            parts = {}
        if journal is not None:
            journal.update(relative, {"uploadId": upload_id, "sha256": sha256, "size": size,
                                      "partSize": part_size, "parts": parts})
        count = -(-size // part_size)
        with open(path, "rb") as handle:
            for number in range(1, count + 1):
                if number in parts:
                    continue
                if progress is not None:
                    progress.check()
                handle.seek((number - 1) * part_size)
                body = handle.read(part_size)
                response = self._call("upload_part", progress, Bucket=self.bucket, Key=key,
                                      UploadId=upload_id, PartNumber=number, Body=body)
                parts[number] = response["ETag"]
                if journal is not None:
                    journal.update(relative, {"parts": parts})
                if progress is not None:
                    progress.update(number / count, f"{relative}: part {number}/{count}")
        params = {"Bucket": self.bucket, "Key": key, "UploadId": upload_id,
                  "MultipartUpload": {"Parts": [{"PartNumber": n, "ETag": parts[n]} for n in sorted(parts)]}}
        if self.conditional_writes:
            params["IfNoneMatch"] = "*"
        try:
            response = self._call("complete_multipart_upload", **params)
        except PublishingError as error:
            # A retried completion whose first answer was lost: 412 (the
            # object exists) or NoSuchUpload (the upload id is used up).
            gone = self._code(error.__cause__)[0] == "NoSuchUpload"
            same = self._already_there(error, relative, sha256, size, gone)
            if same is None:
                raise
            response = {"ETag": same}
        if journal is not None:
            journal.update(relative, {"completed": True})
        return response.get("ETag", "")

    def incomplete_uploads(self) -> List[dict]:
        response = self._call("list_multipart_uploads", Bucket=self.bucket, Prefix=self.prefix + "/")
        return [{"key": u["Key"], "uploadId": u["UploadId"], "initiated": str(u.get("Initiated", ""))}
                for u in response.get("Uploads", [])]

    def abort_upload(self, relative: str, upload_id: str) -> None:
        self._call("abort_multipart_upload", Bucket=self.bucket, Key=self.key(relative), UploadId=upload_id)

    def list_releases(self) -> List[str]:
        from ..web_builder import RELEASE_ID  # pylint: disable=import-outside-toplevel
        releases, token = set(), None
        while True:
            params = {"Bucket": self.bucket, "Prefix": f"{self.prefix}/releases/", "Delimiter": "/"}
            if token:
                params["ContinuationToken"] = token
            response = self._call("list_objects_v2", **params)
            for item in response.get("CommonPrefixes", []):
                name = item["Prefix"].rstrip("/").rsplit("/", 1)[-1]
                if RELEASE_ID.match(name):
                    releases.add(name)
            if not response.get("IsTruncated"):
                return sorted(releases)
            token = response.get("NextContinuationToken")

    def delete_release(self, release_id: str) -> int:
        from ..web_builder import RELEASE_ID  # pylint: disable=import-outside-toplevel
        if not RELEASE_ID.match(release_id):
            raise PublishingError("Q2VT_PUB_PATH_UNSAFE", release_id)
        prefix = f"{self.prefix}/releases/{release_id}/"
        deleted, token = 0, None
        while True:
            params = {"Bucket": self.bucket, "Prefix": prefix}
            if token:
                params["ContinuationToken"] = token
            response = self._call("list_objects_v2", **params)
            keys = [{"Key": o["Key"]} for o in response.get("Contents", []) if o["Key"].startswith(prefix)]
            for start in range(0, len(keys), 1000):
                batch = keys[start:start + 1000]
                result = self._call("delete_objects", Bucket=self.bucket,
                                    Delete={"Objects": batch, "Quiet": True}) or {}
                # A 200 answer can still list keys it could not delete.
                errors = result.get("Errors") or []
                deleted += len(batch) - len(errors)
                if errors:
                    first = errors[0]
                    raise ProviderError(
                        "Q2VT_PUB_UPLOAD", f"{len(errors)} object(s) of release {release_id} could not "
                        f"be deleted ({first.get('Code', '')}: {first.get('Key', '')}).",
                        detail="\n".join(f"{e.get('Key')}: {e.get('Code')} {e.get('Message', '')}"
                                         for e in errors[:50]))
            if not response.get("IsTruncated"):
                return deleted
            token = response.get("NextContinuationToken")

    # -- pointer ------------------------------------------------------------------------
    def read_pointer(self) -> Tuple[Optional[dict], Optional[str]]:
        found = self.get_bytes("current.json")
        if found is None:
            return None, None
        data, etag = found
        try:
            return json.loads(data.decode("utf-8")), etag
        except ValueError as error:
            raise PublishingError("Q2VT_PUB_ACTIVATION", "The remote current.json is not JSON.") from error


class Journal:
    """Private resumable-upload journal (JSON next to the local bundle,
    never in the publication). Holds no credentials."""

    def __init__(self, path: str, target: dict):
        self.path = path
        self.target = target
        self.data = {"target": target, "files": {}}
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as handle:
                    old = json.load(handle)
                if old.get("target") == target:
                    self.data = old
            except (OSError, ValueError):
                pass
        self._lock = threading.Lock()

    def get(self, relative: str) -> dict:
        return dict(self.data["files"].get(relative, {}))

    def update(self, relative: str, values: dict) -> None:
        with self._lock:
            entry = self.data["files"].setdefault(relative, {})
            entry.update({k: (dict(v) if isinstance(v, dict) else v) for k, v in values.items()})
            if "parts" in entry:
                entry["parts"] = {int(k): v for k, v in entry["parts"].items()}
            tmp = f"{self.path}.tmp"
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as handle:
                # json.dumps without indent: the C encoder (rewritten twice per uploaded file)
                handle.write(json.dumps(self.data, separators=(",", ":"), default=str))
            os.replace(tmp, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass

    def done(self, relative: str, etag: str) -> None:
        self.update(relative, {"done": True, "etag": etag})
