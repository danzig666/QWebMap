// Mounts the interactive controls of a published map (called by app.mjs
// once the map and the visible-polygon label helper are ready): the panel
// (layers, legend, filters, tools, share), theme presets, the basemap
// switcher, attribution and the light/dark switch.
import { BackEntry, isOwnTraversal } from "./backstack.mjs";
import { t } from "./i18n.mjs";
import { ViewerState, defaults as defaultState, presetMatches, presets, sanitizeFilters } from "./state.mjs";
import { StyleControl } from "./style_control.mjs";
import { Animator } from "./animation.mjs";
import { LayerControls } from "./layer_controls.mjs";
import { Legend } from "./legend.mjs";
import { Printer } from "./print.mjs";
import { Filters } from "./filters.mjs";
import { Identify, setDocuments } from "./identify.mjs";
import { FeatureLookup } from "./features.mjs";
import { Search, goTo } from "./search.mjs";
import { Permalink, decodeState } from "./permalink.mjs";
import { Tools } from "./tools.mjs";
import { Basemap } from "./basemap.mjs";
import { ParcelReport } from "./parcel_report.mjs";
import { StreetView } from "./streetview.mjs";
import { OverviewControl } from "./overview.mjs";
import { Draw } from "./draw.mjs";
import { ThreeD } from "./threed.mjs";
import { warn } from "./diagnostics.mjs";
import { button, el, icon } from "./icons.mjs";

const MOBILE = "(max-width: 760px)";
const THEME_KEY = "q2vt:ui-theme";
const PANES = { layers: "layers", parcel: "pin", legend: "legend", filters: "filter", tools: "tools", share: "share" };

function panes(manifest) {
  // The Layers tab can be switched off in the plugin: the legend only.
  const list = manifest.interaction?.layersPanel === false ? [] : [["layers", "app.layers"]];
  if (manifest.parcelInfo) list.push(["parcel", "app.parcel"]);
  list.push(["legend", "app.legend"]);
  if (manifest.interaction?.filters !== false && manifest.layers.some((l) => (l.filterFields || []).length)) list.push(["filters", "app.filters"]);
  const tools = manifest.tools || {};
  if (tools.coordinates || tools.measure || tools.print || tools.draw) list.push(["tools", "app.tools"]);
  if (manifest.interaction?.permalinks !== false) list.push(["share", "app.share"]);
  return list;
}

function isMobile() {
  return window.matchMedia ? window.matchMedia(MOBILE).matches : window.innerWidth <= 760;
}

function buildPanel(manifest) {
  const tabs = document.getElementById("q2vt-tabs");
  const container = document.getElementById("q2vt-panes");
  const result = {};
  const buttons = [];
  for (const [id, label] of panes(manifest)) {
    const tab = button("", null, PANES[id], { text: t(label) });
    tab.id = `q2vt-tab-${id}`;
    tab.title = t(label);
    tab.setAttribute("aria-label", t(label));
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-controls", `q2vt-pane-${id}`);
    const pane = el("div", "q2vt-pane");
    pane.id = `q2vt-pane-${id}`;
    pane.dataset.pane = id;
    pane.setAttribute("role", "tabpanel");
    pane.setAttribute("aria-labelledby", tab.id);
    tab.addEventListener("click", () => select(id));
    tabs.append(tab);
    container.append(pane);
    buttons.push([id, tab, pane]);
    result[id] = pane;
  }
  function select(id) {
    for (const [paneId, tab, pane] of buttons) {
      tab.setAttribute("aria-selected", String(paneId === id));
      tab.tabIndex = paneId === id ? 0 : -1;
      pane.hidden = paneId !== id;
    }
    container.scrollTop = 0;
  }
  tabs.addEventListener("keydown", (event) => {
    if (!["ArrowLeft", "ArrowRight"].includes(event.key)) return;
    const index = buttons.findIndex(([, tab]) => tab.getAttribute("aria-selected") === "true");
    const next = buttons[(index + (event.key === "ArrowRight" ? 1 : buttons.length - 1)) % buttons.length];
    select(next[0]);
    next[1].focus();
  });
  select(result.layers ? "layers" : (result.legend ? "legend" : panes(manifest)[0][0]));
  const panel = document.getElementById("q2vt-panel");
  const menu = document.getElementById("q2vt-menu");
  menu.replaceChildren(icon("menu", 22));
  // On phones the panel sheet covers the map: Back closes it.
  const back = new BackEntry(() => setOpen(false));
  const setOpen = (open) => {
    if (open && isMobile()) back.open();
    else if (!open) back.closed();
    panel.hidden = !open;
    menu.setAttribute("aria-expanded", String(open));
    menu.replaceChildren(icon(open && isMobile() ? "close" : "menu", 22));
    document.body.classList.toggle("q2vt-panel-open", open);
    if (!open) panel.classList.remove("q2vt-expanded");
  };
  menu.setAttribute("aria-label", t("app.menu"));
  menu.title = t("app.menu");
  menu.addEventListener("click", () => { setOpen(panel.hidden); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !panel.hidden && isMobile()) { setOpen(false); menu.focus(); }
  });
  // Bottom sheet on phones: tap the handle to grow/shrink, drag down to close.
  const handle = document.getElementById("q2vt-sheet-handle");
  if (handle) {
    handle.setAttribute("aria-label", t("app.resize"));
    handle.addEventListener("click", () => panel.classList.toggle("q2vt-expanded"));
    let startY = null;
    handle.addEventListener("touchstart", (e) => { startY = e.touches[0].clientY; }, { passive: true });
    handle.addEventListener("touchmove", (e) => {
      if (startY === null) return;
      const dy = e.touches[0].clientY - startY;
      if (dy > 70) { startY = null; if (panel.classList.contains("q2vt-expanded")) panel.classList.remove("q2vt-expanded"); else setOpen(false); }
      else if (dy < -50) { startY = null; panel.classList.add("q2vt-expanded"); }
    }, { passive: true });
    handle.addEventListener("touchend", () => { startY = null; });
  }
  // Open at start on wide screens, unless the publisher chose a closed
  // panel (more of the map on screen) or the map is embedded.
  setOpen(!isMobile() && !document.body.classList.contains("q2vt-embed")
          && manifest.interaction?.panelClosed !== true);
  return { panes: result, select, setOpen };
}

function shareBlock(container, permalink) {
  const block = el("div", "q2vt-share");
  const status = el("p", "q2vt-muted");
  status.setAttribute("aria-live", "polite");
  for (const [which, label] of [["stable", "app.linkCurrent"], ["versioned", "app.linkRelease"]]) {
    const node = button("q2vt-chip", null, "link", { text: t(label) });
    node.addEventListener("click", async () => {
      const copied = await permalink.copy({}, which);
      status.textContent = `${t(label)}: ${t(copied ? "app.copied" : "app.copyFailed")}`;
      clearTimeout(status.q2vtTimer);
      status.q2vtTimer = setTimeout(() => { status.textContent = ""; }, 6000);
    });
    block.append(node);
  }
  container.append(block, status);
}

// Light / dark switch (follows the system until chosen; per browser).
function themeToggle(container) {
  const root = document.documentElement;
  const saved = (() => { try { return localStorage.getItem(THEME_KEY); } catch { return null; } })();
  if (saved === "light" || saved === "dark") root.dataset.theme = saved;
  const dark = () => root.dataset.theme === "dark"
    || (!root.dataset.theme && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  const node = button("q2vt-icon-btn", t("app.darkMode"), dark() ? "sun" : "moon");
  node.addEventListener("click", () => {
    const next = dark() ? "light" : "dark";
    root.dataset.theme = next;
    try { localStorage.setItem(THEME_KEY, next); } catch { /* storage unavailable */ }
    node.replaceChildren(icon(next === "dark" ? "sun" : "moon"));
  });
  container.append(node);
}

// Flavor preview: earth, park, water and two roads in the flavor's colours.
function preview(colors) {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 80 80");
  svg.setAttribute("preserveAspectRatio", "xMidYMid slice");
  const color = (value, fallback) => (/^#[0-9a-f]{3,8}$/i.test(value || "") ? value : fallback);
  const add = (tag, attrs) => {
    const node = document.createElementNS(ns, tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    svg.append(node);
  };
  add("rect", { width: 80, height: 80, fill: color(colors.earth, "#e2dfda") });
  add("path", { d: "M0 54 C 18 44, 30 62, 52 56 S 80 60, 80 60 V80 H0z", fill: color(colors.water, "#80deea") });
  add("path", { d: "M50 6 h22 v20 h-22z", fill: color(colors.park, "#cfddd5"), rx: 3 });
  add("rect", { x: 10, y: 14, width: 9, height: 7, fill: color(colors.buildings, "#cccccc") });
  add("rect", { x: 24, y: 26, width: 8, height: 9, fill: color(colors.buildings, "#cccccc") });
  add("path", { d: "M-2 38 L 82 30", stroke: color(colors.highway, "#ffffff"), "stroke-width": 5, fill: "none" });
  add("path", { d: "M38 -2 L 42 82", stroke: color(colors.road, "#ffffff"), "stroke-width": 3, fill: "none" });
  return svg;
}

class BasemapControl {
  constructor(basemap, state) {
    this.basemap = basemap;
    this.state = state;
  }

  onAdd() {
    const root = el("div", "maplibregl-ctrl q2vt-basemap");
    const menu = el("div", "q2vt-basemap-menu q2vt-floating");
    menu.hidden = true;
    menu.setAttribute("role", "menu");
    menu.append(el("h4", "", t("basemap.title")));
    const toggleButton = el("button", "q2vt-basemap-btn");
    toggleButton.type = "button";
    toggleButton.setAttribute("aria-haspopup", "true");
    toggleButton.setAttribute("aria-expanded", "false");
    const options = [{ id: "none", title: t("basemap.none") }, ...this.basemap.options()];
    this.optionButtons = new Map();
    for (const option of options) {
      const node = el("button", "q2vt-basemap-option");
      node.type = "button";
      node.setAttribute("role", "menuitemradio");
      const thumb = el("span", "q2vt-basemap-thumb");
      if (option.id === "none") {
        thumb.append(this.noneThumb(18));
      } else if (option.tiles) {  // a web basemap: a tile of it once the menu opens (refresh)
        thumb.append(this.webThumb(option.id, false));
      } else {
        thumb.append(preview(option.colors || {}));
      }
      node.append(thumb, el("span", "", option.title));
      node.addEventListener("click", () => {
        this.state.set({ basemap: option.id }, "basemap");
        menu.hidden = true;
        toggleButton.setAttribute("aria-expanded", "false");
      });
      this.optionButtons.set(option.id, node);
      menu.append(node);
    }
    toggleButton.addEventListener("click", () => {
      if (menu.hidden) this.refresh();  // thumbnails of the place now shown
      menu.hidden = !menu.hidden;
      toggleButton.setAttribute("aria-expanded", String(!menu.hidden));
    });
    document.addEventListener("click", (event) => {
      if (!root.contains(event.target)) { menu.hidden = true; toggleButton.setAttribute("aria-expanded", "false"); }
    });
    this.toggleButton = toggleButton;
    root.append(menu, toggleButton);
    this.sync(this.state.value.basemap);
    // A web basemap's button shows the place on the map now.
    this.onMoveEnd = () => { if (this.basemap.option(this.state.value.basemap)?.tiles) this.sync(this.state.value.basemap); };
    this.basemap.map.on("moveend", this.onMoveEnd);
    return root;
  }

  // "No basemap": the project's own background colour.
  noneThumb(size) {
    const blank = el("span", "q2vt-basemap-none q2vt-basemap-plain");
    const color = this.basemap.projectBackground();
    if (color) blank.style.background = color;
    blank.append(icon("close", size));
    return blank;
  }

  // A web basemap: one of its tiles (an icon until it loads, or if it fails).
  // Its server is contacted only when the visitor opens the menu or uses
  // that basemap, never just because the page opened.
  webThumb(id, load = true) {
    const box = el("span", "q2vt-basemap-none q2vt-basemap-web");
    box.dataset.basemap = id;
    box.append(icon("image", 20));
    const url = load ? this.basemap.thumbnail(id) : null;
    if (url) {
      const img = new Image();
      img.alt = "";
      img.decoding = "async";
      img.referrerPolicy = "strict-origin-when-cross-origin";
      img.addEventListener("load", () => box.replaceChildren(img));
      img.src = url;
    }
    return box;
  }

  refresh() {
    for (const [id, node] of this.optionButtons) {
      const thumb = node.querySelector(".q2vt-basemap-thumb");
      if (id === "none") thumb.replaceChildren(this.noneThumb(18));
      else if (this.basemap.option(id)?.tiles) thumb.replaceChildren(this.webThumb(id));
    }
  }

  sync(active) {
    const flavor = this.basemap.option(active);
    this.toggleButton.replaceChildren(flavor && !flavor.tiles ? preview(flavor.colors || {})
      : flavor ? this.webThumb(active) : this.noneThumb(22), el("span", "q2vt-basemap-caption", t("basemap.title")));
    this.toggleButton.setAttribute("aria-label", `${t("basemap.title")}: ${flavor ? flavor.title : t("basemap.none")}`);
    this.toggleButton.title = this.toggleButton.getAttribute("aria-label");
    for (const [id, node] of this.optionButtons) node.setAttribute("aria-pressed", String(id === active));
  }

  onRemove() { if (this.onMoveEnd) this.basemap.map.off("moveend", this.onMoveEnd); }
}

// Attribution as plain text (never HTML from the manifest).
class AttributionControl {
  constructor(parts) { this.parts = parts; }

  onAdd() {
    this.node = el("div", "maplibregl-ctrl q2vt-attribution");
    this.render();
    return this.node;
  }

  render() {
    const text = this.parts.filter(Boolean).join(" · ");
    this.node.textContent = text;
    this.node.hidden = !text;
  }

  onRemove() {}
}

function themeBar(manifest, state) {
  const bar = document.getElementById("q2vt-themes");
  const list = presets(manifest);
  // One view only: nothing to choose, no bar (its layers are the start view).
  if (!bar || list.length < 2) return null;
  // No visible "Views" heading: the buttons speak for themselves and the
  // row has room for one more (screen readers get the bar's name).
  bar.setAttribute("aria-label", t("app.themes"));
  const chips = list.map((preset) => {
    const chip = button("q2vt-chip", null, null, { text: preset.title });
    chip.addEventListener("click", () => state.applyTheme(preset.id));
    bar.append(chip);
    return [preset, chip];
  });
  // Too many views for one row: a drop-down instead of buttons running off
  // the screen (the bar does not scroll visibly).
  const select = el("select", "q2vt-theme-select");
  select.setAttribute("aria-label", t("app.themes"));
  const none = el("option", "", "—");
  none.value = "";
  none.disabled = true;
  select.append(none, ...list.map((preset) => {
    const option = el("option", "", preset.title);
    option.value = preset.id;
    return option;
  }));
  select.addEventListener("change", () => { if (select.value) state.applyTheme(select.value); });
  select.hidden = true;
  bar.append(select);
  const sync = () => {
    let current = "";
    for (const [preset, chip] of chips) {
      const on = presetMatches(manifest, state.value, preset);
      chip.setAttribute("aria-pressed", String(on));
      if (on && !current) current = preset.id;
    }
    select.value = current;  // "" (—) when the layers match no view
  };
  const fit = () => {
    for (const [, chip] of chips) chip.hidden = false;
    select.hidden = true;
    if (bar.scrollWidth > bar.clientWidth + 1) {
      for (const [, chip] of chips) chip.hidden = true;
      select.hidden = false;
    }
  };
  state.onChange(sync);
  sync();
  bar.hidden = false;
  fit();
  if (typeof ResizeObserver !== "undefined") new ResizeObserver(fit).observe(bar);
  else window.addEventListener("resize", fit);
  return bar;
}

// Keep CSS informed of the floating header's height (phone layout).
function trackHeader() {
  const header = document.getElementById("q2vt-header");
  const themes = document.getElementById("q2vt-themes");
  if (!header || typeof ResizeObserver === "undefined") return;
  const update = () => {
    document.documentElement.style.setProperty("--q2vt-header-h", `${Math.round(header.getBoundingClientRect().height)}px`);
    const height = themes && !themes.hidden ? themes.getBoundingClientRect().height + 8 : 0;
    document.documentElement.style.setProperty("--q2vt-themes-h", `${Math.round(height)}px`);
  };
  new ResizeObserver(update).observe(header);
  update();
}

export async function mount({ map, manifest, manifestUrl, pageUrl, assetsUrl, maplibregl, viewer }) {
  const releaseBase = pageUrl;
  setDocuments(manifest.info, pageUrl);
  const state = new ViewerState(manifest);
  const initial = defaultState(manifest);
  // A link names what its sender changed from the published map, so it is
  // applied to the published map, not to this visitor's remembered choices.
  const fromUrl = decodeState(manifest, location.hash);
  if (!fromUrl) state.load();
  // A link pasted into this tab changes only the hash (the viewer itself
  // rewrites it with replaceState, which fires nothing): open it afresh.
  // (A Back that only closed a popup lands on an older hash: not a link.)
  window.addEventListener("hashchange", () => { if (!isOwnTraversal()) location.reload(); });
  if (fromUrl) {
    state.merge({ ...fromUrl, filters: fromUrl.filters ? sanitizeFilters(manifest, fromUrl.filters) : undefined });
    if (fromUrl.camera) map.jumpTo({ center: [fromUrl.camera.lng, fromUrl.camera.lat], zoom: fromUrl.camera.zoom });
  }
  // Basemap first: it goes under every project layer.
  const basemap = new Basemap({ map, manifest, manifestUrl, maplibregl });
  viewer.basemap = basemap;
  if (basemap.available) {
    try {
      await basemap.init();
      await basemap.set(state.value.basemap);
    } catch (error) {
      warn("error.basemap", String(error && error.message || error));
    }
  }
  const control = new StyleControl(map, manifest);
  const animator = new Animator(map, control);
  viewer.animator = animator;
  const apply = () => {
    control.apply(state.value);
    animator.refresh();
    if (viewer.labels && viewer.labels.setEligibility) viewer.labels.setEligibility(control.eligibility(state.value));
  };
  state.onChange(apply);
  apply();
  // 3D view (buildings with heights, terrain relief) and the hillshade.
  if (manifest.terrainError) warn("error.terrain", manifest.terrainError);
  try {
    const threeD = new ThreeD({ map, manifest, manifestUrl, basemap, maplibregl });
    viewer.threeD = threeD;
    if (threeD.available) map.addControl(threeD, "top-right");
  } catch (error) {
    warn("error.terrain", String(error && error.message || error));
  }

  const panel = buildPanel(manifest);
  const permalink = new Permalink({ map, manifest, state, defaults: initial,
    enabled: manifest.interaction?.permalinks !== false });
  viewer.permalink = permalink;
  const lookup = new FeatureLookup(manifest, manifestUrl);
  // Popups off: no identify, unless the parcel report needs the clicks.
  const popupsOff = manifest.interaction?.popups === false;
  const identify = popupsOff && !panel.panes.parcel ? null
    : new Identify({ map, manifest, maplibregl, control, state, lookup, viewer, reportOnly: popupsOff });
  const parts = { state, control, permalink, lookup, identify, panel, basemap };
  if (panel.panes.layers) {
    parts.layers = new LayerControls({ map, manifest, state, control, container: panel.panes.layers, releaseBase });
  } else if (state.value.labels === false) {
    state.set({ labels: true });  // no Layers tab, no labels switch to undo a remembered or linked "off"
  }
  if (panel.panes.parcel) {
    const report = new ParcelReport({ map, manifest, manifestUrl, releaseBase, maplibregl,
      container: panel.panes.parcel, panel, permalink });
    parts.parcel = report;
    viewer.parcel = report;
    if (identify) {
      // A click opens the parcel (no chooser), and its report in the panel
      // instead of a popup.
      identify.prefer = report.layerId;
      identify.intercept = (layerId, key) => {
        if (layerId !== report.layerId) return false;
        report.show(key).catch((error) => warn("feature.notFound", String(error)));
        return true;
      };
      identify.onEmpty = () => report.clearMarkers();
    }
  }
  parts.legend = new Legend({ map, manifest, state, control, container: panel.panes.legend, releaseBase });
  // Print: the map with the legend of what it draws, or the parcel report.
  parts.printer = new Printer({ map, manifest, threeD: viewer.threeD, animator, content: (mode) =>
    (mode === "parcel" && parts.parcel ? parts.parcel.printCard() : null) || parts.legend.printList() });
  viewer.printer = parts.printer;
  if (parts.parcel) {
    parts.parcel.onPrint = async () => {
      await parts.parcel.loadTexts();  // the zone regulations, also the closed ones
      return parts.printer.print("parcel", parts.parcel.bounds());
    };
  }
  if (panel.panes.filters) parts.filters = new Filters({ manifest, state, container: panel.panes.filters });
  if (panel.panes.tools) {
    parts.tools = new Tools({ map, manifest, container: panel.panes.tools, viewer });
    viewer.tools = parts.tools;
    if (manifest.tools?.draw) {
      parts.draw = new Draw({ map, maplibregl, manifest, container: panel.panes.tools, viewer, permalink,
        initial: fromUrl && fromUrl.drawing });
      viewer.draw = parts.draw;
      permalink.drawing = () => parts.draw.encode();
    }
  }
  if (panel.panes.share) shareBlock(panel.panes.share, permalink);
  // Without popups, a found feature is zoomed to and marked, without its popup.
  if (manifest.search && manifest.interaction?.search !== false) {
    parts.search = new Search({ map, manifest, manifestUrl, assetsUrl, container: document.getElementById("q2vt-searchbox"), identify });
  }
  parts.themes = themeBar(manifest, state);
  // Google Street View (optional): a map button under the zoom buttons.
  if (manifest.interaction?.streetView && manifest.interaction?.googleApiKey) {
    const streetView = new StreetView({ map, maplibregl, manifest, viewer });
    map.addControl(streetView, "top-right");
    parts.streetView = streetView;
    viewer.streetViewControl = streetView;
  }
  // Bottom right: basemap switcher above the scale and the attribution.
  const attribution = new AttributionControl([manifest.attribution,
    basemap.available && state.value.basemap !== "none" ? basemap.attribution(state.value.basemap) : null]);
  map.addControl(attribution, "bottom-right");
  map.addControl(new maplibregl.ScaleControl({ unit: "metric" }), "bottom-right");
  if (basemap.available) {
    const switcher = new BasemapControl(basemap, state);
    map.addControl(switcher, "bottom-right");
    // What the map draws: a basemap that failed to load leaves the previous
    // one, and choosing it again tries again.
    let shown = basemap.active;
    if (shown !== state.value.basemap) switcher.sync(shown);
    state.onChange((value) => {
      if (value.basemap === shown) return;
      const id = (shown = value.basemap);
      basemap.set(id).then(() => {
        switcher.sync(shown);
        attribution.parts = [manifest.attribution, shown !== "none" ? basemap.attribution(shown) : null];
        attribution.render();
      }).catch((error) => {
        warn("error.basemap", String(error));
        if (shown !== id) return;  // another one was chosen meanwhile
        shown = basemap.active;
        switcher.sync(shown);
      });
    });
  }
  if (manifest.interaction?.overviewMap) {
    parts.overview = new OverviewControl({ map, manifest, maplibregl });
    map.addControl(parts.overview, "bottom-right");
  }
  const about = document.getElementById("q2vt-about-actions");
  if (about) themeToggle(about);
  trackHeader();
  // A link to a feature: exact lookup (works with search disabled, offscreen, cold).
  const selected = fromUrl && fromUrl.selected;
  if (selected && identify) {
    lookup.get(selected.layerId, selected.key).then(async (record) => {
      if (!record) { warn("feature.notFound", `${selected.layerId}/${selected.key}`); return; }
      if (!(fromUrl && fromUrl.camera)) await goTo(map, record);
      identify.open(selected.layerId, selected.key, record.p);
    }).catch((error) => warn("feature.notFound", String(error)));
  }
  viewer.state = state;
  // Add-ons of a variant edition (manifest.addons, from the release's own
  // assets/addons/): each module's install(parts) adds to the viewer.
  for (const href of Array.isArray(manifest.addons) ? manifest.addons : []) {
    if (typeof href !== "string" || !/^assets\/addons\/[a-z0-9_-]+\.mjs$/.test(href)) continue;
    try {
      const addon = await import(new URL(href, pageUrl).href);
      if (typeof addon.install === "function") await addon.install({ ...parts, map, manifest, manifestUrl, maplibregl, viewer });
    } catch (error) {
      warn("error.addon", `${href}: ${String(error && error.message || error)}`);
    }
  }
  return parts;
}
