// Parcel report (telekinformáció): clicking a parcel shows what the export
// computed in QGIS for it — area, parts cut by the zoning and the regulation
// lines (numbered on the map), zones with their legend graphic, zone values,
// restrictions with their legend graphic, overlap and explanation, and the
// notice. Data: parcels/catalog.json + one shard per lookup; no geometry.
// Everything goes into the DOM as text.
import { locale, t, formatNumber } from "./i18n.mjs";
import { featureShardKey } from "./search_core.mjs";
import { fetchShard, shardId } from "./shards.mjs";
import { button, el, icon } from "./icons.mjs";
import { formatValue } from "./identify.mjs";
import { richText } from "./rich_text.mjs";
import { openReader } from "./reader.mjs";
import { notice } from "./diagnostics.mjs";

export function formatArea(m2) {
  if (m2 >= 10000) return `${formatNumber(m2 / 10000, 4)} ha`;
  return `${formatNumber(m2, m2 < 100 ? 1 : 0)} m²`;
}

// A zone code as the regulation table is keyed (parcel_report.py zone_key).
export function zoneKey(code) {
  return code === null || code === undefined ? "" : String(code).trim();
}

function value(raw) {
  if (raw === null || raw === undefined || raw === "") return "—";
  return typeof raw === "number" ? formatNumber(raw) : String(raw);
}

function swatchImage(path, base) {
  const img = document.createElement("img");
  img.className = "q2vt-pr-swatch";
  img.alt = "";
  if (typeof path === "string" && /^legend\/[A-Za-z0-9._-]+\.png$/.test(path)) img.src = new URL(path, base).href;
  return img;
}

function shareBar(share) {
  const bar = el("span", "q2vt-pr-bar");
  const fill = el("span");
  fill.style.width = `${Math.max(2, Math.min(100, share))}%`;
  bar.append(fill);
  return bar;
}

export class ParcelReport {
  constructor({ map, manifest, manifestUrl, releaseBase, maplibregl, container, panel, permalink }) {
    Object.assign(this, { map, manifest, releaseBase, maplibregl, container, panel, permalink });
    this.info = manifest.parcelInfo || null;
    this.base = this.info ? new URL(this.info.manifest, manifestUrl) : null;
    this.catalogUrl = this.info ? new URL(this.info.catalog, manifestUrl) : null;
    this.shards = new Map();
    this.markers = [];
    if (this.container) this.empty();
  }

  get available() { return !!this.info; }

  get layerId() { return this.info && this.info.layerId; }

  // [west, south, east, north] of the shown parcel (the print zooms on it).
  bounds() { return (this.record && this.record.bb) || null; }

  // Before a print: every zone's full regulations of the shown report
  // loaded, also those not opened in the panel.
  async loadTexts() {
    const card = this.container && this.container.querySelector("article.q2vt-pr");
    if (!card) return;
    await Promise.all([...card.querySelectorAll("details.q2vt-rich-block")]
      .map((block) => (block.q2vtLoad ? block.q2vtLoad() : null)));
  }

  // The shown report for the print sheet (without its buttons): the parcel,
  // its parts and restrictions beside the map. The full regulations (opened
  // or not, see loadTexts) are marked to flow after the first page across
  // the whole width (see Printer.fill), and a section shared by several
  // zones (between <hr>s: the general rules) is printed once, with a line
  // pointing to it at the others.
  printCard() {
    const card = this.container && this.container.querySelector("article.q2vt-pr");
    if (!card) return null;
    const copy = card.cloneNode(true);
    for (const node of copy.querySelectorAll(".q2vt-chips, button")) node.remove();
    const texts = copy.querySelector(".q2vt-pr-texts");
    if (!texts) return copy;
    const printed = new Map();  // section text -> the zone it was printed at
    for (const block of texts.querySelectorAll("details.q2vt-rich-block")) {
      const rich = block.querySelector(".q2vt-rich");
      if (!rich) {
        block.remove();
        continue;
      }
      block.open = true;
      block.dataset.printFlow = "";
      const sections = [[]];
      for (const node of [...rich.childNodes]) {
        if (node.nodeName === "HR") sections.push([node]);
        else sections[sections.length - 1].push(node);
      }
      for (const nodes of sections) {
        const content = nodes.filter((node) => node.nodeName !== "HR");
        const key = content.map((node) => node.textContent).join(" ").replace(/\s+/g, " ").trim();
        if (!key) continue;
        if (!printed.has(key)) {
          printed.set(key, block.dataset.zone || "");
          continue;
        }
        const first = content.find((node) => (node.textContent || "").trim());
        const title = first.textContent.replace(/\s+/g, " ").trim().slice(0, 90);
        const note = el("p", "q2vt-print-same", t("parcel.sameText", { title, code: printed.get(key) }));
        nodes[0].before(note);
        if (nodes[0].nodeName === "HR") note.before(nodes[0].cloneNode());
        for (const node of nodes) node.remove();
      }
    }
    return copy;
  }

  async load() {
    if (!this.ready) {
      this.ready = Promise.all([fetch(this.base), fetch(this.catalogUrl)]).then(async ([a, b]) => {
        if (!a.ok || !b.ok) throw new Error("parcel report: HTTP error");
        this.index = await a.json();
        this.catalog = await b.json();
        this.restrictions = new Map((this.catalog.restrictions || []).map((r) => [r.i, r]));
      });
      this.ready.catch(() => { this.ready = null; });  // tried again at the next click
    }
    return this.ready;
  }

  // The full regulation text (safe simple HTML) of a zone code, or null.
  async regulationText(code) {
    await this.load();
    const name = ((this.catalog && this.catalog.texts) || {})[zoneKey(code)];
    if (typeof name !== "string" || !/^text-\d+\.json$/.test(name)) return null;
    this.texts ??= new Map();
    if (!this.texts.has(name)) {
      const loading = fetch(new URL(name, this.base)).then((r) => {
        if (!r.ok) throw new Error(`${name}: HTTP ${r.status}`);
        return r.json();
      }).then((data) => (data && typeof data.html === "string" ? data.html : null));
      this.texts.set(name, loading);
      loading.catch(() => this.texts.delete(name));  // tried again next time
    }
    return this.texts.get(name);
  }

  // A closed <details> with a zone's full regulations, loaded when opened;
  // null when the zone has none. (Also used by variant add-ons in popups.)
  regulationBlock(code) {
    if (!((this.catalog && this.catalog.texts) || {})[zoneKey(code)]) return null;
    const block = el("details", "q2vt-rich-block");
    block.dataset.zone = zoneKey(code);
    block.append(el("summary", "", t("parcel.fullText", { code: zoneKey(code) })));
    let loading = null;
    let failed = null;  // the last failure's note, gone on the next try
    // Loads the text into the block once (on opening it, and before a print).
    const load = () => {
      loading ??= fill().catch(() => { loading = null; });
      return loading;
    };
    const fill = async () => {
      if (failed) failed.remove();
      failed = null;
      const wait = el("p", "q2vt-muted", t("parcel.textLoading"));
      block.append(wait);
      try {
        const html = await this.regulationText(code);
        if (!html) {
          wait.replaceWith(el("p", "q2vt-muted", t("parcel.textMissing")));
          return;
        }
        const text = richText(html);
        // Long texts read better in a large window (reader.mjs), printed or
        // saved from there on their own.
        const bigger = button("q2vt-chip q2vt-chip-ghost q2vt-rich-open", null, "expand",
          { text: t("reader.open") });
        bigger.addEventListener("click", () => openReader({
          title: t("parcel.fullText", { code: zoneKey(code) }),
          subtitle: (this.manifest && this.manifest.title) || "",
          content: text,
          lang: locale,
        }));
        wait.replaceWith(bigger, text);
      } catch (error) {
        failed = el("p", "q2vt-muted", t("parcel.textMissing"));
        wait.replaceWith(failed);
        throw error;  // tried again on the next opening
      }
    };
    block.q2vtLoad = load;
    block.addEventListener("toggle", () => { if (block.open) load(); });
    return block;
  }

  async get(key) {
    await this.load();
    const shardKey = featureShardKey(this.index.layerId, String(key), this.index.prefixLength);
    const shard = this.index.shards.find((s) => s.key === shardKey);
    if (!shard) return null;
    const id = shardId(shard);
    if (!this.shards.has(id)) {
      const loading = fetchShard(this.base, shard);
      this.shards.set(id, loading);
      loading.catch(() => this.shards.delete(id));  // tried again next time
    }
    return (await this.shards.get(id)).find((r) => r.k === String(key)) || null;
  }

  empty() {
    this.record = null;
    this.clearMarkers();
    const box = el("div", "q2vt-empty");
    box.append(icon("pin", 28), el("p", "", t("parcel.hint")));
    this.container.replaceChildren(box);
  }

  clearMarkers() {
    for (const marker of this.markers) marker.remove();
    this.markers = [];
  }

  async show(key) {
    const ticket = (this.ticket = (this.ticket || 0) + 1);
    let record = null;
    try { record = await this.get(key); } catch { record = null; }
    if (ticket !== this.ticket) return null;  // another parcel was clicked meanwhile
    this.clearMarkers();
    this.container.replaceChildren();
    if (this.panel) { this.panel.select("parcel"); this.panel.setOpen(true); }
    this.record = null;
    if (!record) {
      this.container.append(el("p", "q2vt-empty", t("parcel.notFound")));
      return null;
    }
    this.record = record;
    this.render(record);
    return record;
  }

  render(record) {
    const c = this.catalog;
    const card = el("article", "q2vt-pr");
    const head = el("header", "q2vt-pr-head");
    head.append(el("div", "q2vt-pr-kicker", c.title || t("parcel.title")),
      el("h2", "", `${t("parcel.hrsz")} ${record.k}`));
    const total = el("div", "q2vt-pr-total");
    total.append(el("span", "q2vt-pr-total-value", formatArea(record.a)),
      el("span", "q2vt-muted", record.a >= 10000 ? `${formatNumber(Math.round(record.a))} m²` : t("parcel.totalArea")));
    head.append(total);
    card.append(head);
    const facts = (c.fields || []).filter((f) => record.f && record.f[f.field] !== null && record.f[f.field] !== undefined && record.f[f.field] !== "");
    if (facts.length) {
      const list = el("dl", "q2vt-pr-facts");
      for (const f of facts) list.append(el("dt", "", f.title || f.field), el("dd", "", value(record.f[f.field])));
      card.append(list);
    }
    // Parts (cut by the zoning and the regulation / zone boundary lines).
    const parts = record.p || [];
    const section = el("section", "q2vt-pr-section");
    section.append(el("h3", "", parts.length > 1 ? t("parcel.parts", { n: parts.length }) : t("parcel.zone")));
    for (const part of parts) {
      const row = el("div", "q2vt-pr-part");
      const top = el("div", "q2vt-pr-row");
      if (parts.length > 1) top.append(el("span", "q2vt-pr-num", String(part.n)));
      top.append(swatchImage(part.sw, this.releaseBase));
      const name = el("div", "q2vt-pr-name");
      name.append(el("strong", "", value(part.c)));
      if (part.zl && part.zl !== part.c) name.append(el("span", "q2vt-muted", part.zl));
      top.append(name);
      const size = el("div", "q2vt-pr-size");
      size.append(el("span", "", formatArea(part.a)), el("span", "q2vt-muted", `${formatNumber(part.s, 1)}%`));
      top.append(size);
      row.append(top);
      if (parts.length > 1) row.append(shareBar(part.s));
      if ((part.b || []).length) {
        const chips = el("div", "q2vt-pr-chips");
        for (const title of part.b) {
          const chip = el("span", "q2vt-pr-chip");
          chip.append(icon("ruler", 14), el("span", "", t("parcel.cutBy", { line: title })));
          chips.append(chip);
        }
        row.append(chips);
      }
      const rows = [];
      for (const f of c.zoneFields || []) {
        const v = part.z ? part.z[f.field] : undefined;
        // Not the zone code again (it is the part's title).
        if (v !== null && v !== undefined && v !== "" && String(v) !== String(part.c)) rows.push([f.title || f.field, v]);
      }
      const regulation = (c.regulations || {})[zoneKey(part.c)];
      if (regulation) {
        for (const f of c.regulationFields || []) {
          const v = regulation[f.field];
          if (v !== null && v !== undefined && v !== "") rows.push([f.title || f.field, v, f.type]);
        }
      }
      if (rows.length) {
        const list = el("dl", "q2vt-pr-facts q2vt-pr-zone");
        for (const [k, v, type] of rows) {
          // Links: a URL field, or a value naming a published document (the decree).
          const shown = typeof v === "string" ? formatValue(v, type) : null;
          const cell = el("dd");
          if (shown && shown.url) {
            const link = el("a", "", shown.text);
            link.href = shown.url;
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            cell.append(link);
          } else cell.textContent = value(v);
          list.append(el("dt", "", k), cell);
        }
        row.append(list);
      }
      section.append(row);
    }
    card.append(section);
    // The full regulations of each zone of the parcel (opened on request).
    const blocks = [...new Set(parts.map((part) => zoneKey(part.c)).filter(Boolean))]
      .map((code) => this.regulationBlock(code)).filter(Boolean);
    if (blocks.length) {
      const texts = el("section", "q2vt-pr-section q2vt-pr-texts");
      texts.append(...blocks);
      card.append(texts);
    }
    // Restrictions.
    const hits = record.r || [];
    const restrictions = el("section", "q2vt-pr-section");
    restrictions.append(el("h3", "", t("parcel.restrictions", { n: hits.length })));
    if (!hits.length) restrictions.append(el("p", "q2vt-muted", t("parcel.noRestrictions")));
    for (const hit of hits) {
      const meta = this.restrictions.get(hit.i) || {};
      const item = el("div", "q2vt-pr-restriction");
      const top = el("div", "q2vt-pr-row");
      const swatches = el("span", "q2vt-pr-swatches");
      for (const [, path] of (hit.k || []).slice(0, 4)) swatches.append(swatchImage(path, this.releaseBase));
      top.append(swatches);
      const name = el("div", "q2vt-pr-name");
      name.append(el("strong", "", meta.title || ""));
      const labels = [...new Set((hit.k || []).map(([label]) => label).filter((l) => l && l !== meta.title))];
      if (labels.length) name.append(el("span", "q2vt-muted", labels.join(", ")));
      if ((hit.n || []).length) name.append(el("span", "q2vt-pr-names", hit.n.join(", ")));
      top.append(name);
      const size = el("div", "q2vt-pr-size");
      if (typeof hit.a === "number") size.append(el("span", "", formatArea(hit.a)), el("span", "q2vt-muted", `${formatNumber(hit.s, 1)}%`));
      else size.append(el("span", "q2vt-muted", t("parcel.touches")));
      top.append(size);
      item.append(top);
      if (typeof hit.s === "number") item.append(shareBar(hit.s));
      if (meta.distance) item.append(el("p", "q2vt-pr-note", t("parcel.distance", { m: formatNumber(meta.distance) })));
      if (meta.note) item.append(el("p", "q2vt-pr-note", meta.note));
      if (meta.reference) item.append(el("p", "q2vt-pr-ref", meta.reference));
      restrictions.append(item);
    }
    card.append(restrictions);
    const actions = el("div", "q2vt-chips");
    const parcels = this.manifest.layers.find((l) => l.id === this.layerId);
    if (this.permalink && parcels && parcels.deepLinks) { // (only those are in the feature lookup)
      const link = button("q2vt-chip", null, "link", { text: t("popup.link") });
      link.addEventListener("click", () => this.permalink.copy({ selected: { layerId: this.layerId, key: record.k } })
        .then((copied) => notice(copied ? "app.copied" : "app.copyFailed")));
      actions.append(link);
    }
    const print = button("q2vt-chip q2vt-chip-ghost", null, "print", { text: t("parcel.print") });
    print.addEventListener("click", () => (this.onPrint ? this.onPrint() : window.print()));
    actions.append(print);
    card.append(actions);
    card.append(el("p", "q2vt-pr-disclaimer", c.disclaimer || t("parcel.disclaimer")));
    this.container.append(card);
    this.container.scrollTop = 0;
    // Numbered markers of the parts on the map.
    if (parts.length > 1) {
      for (const part of parts) {
        if (!Array.isArray(part.x)) continue;
        const badge = el("div", "q2vt-pr-marker", String(part.n));
        badge.title = `${part.n}. ${value(part.c)} — ${formatArea(part.a)}`;
        this.markers.push(new this.maplibregl.Marker({ element: badge }).setLngLat(part.x).addTo(this.map));
      }
    }
  }
}
