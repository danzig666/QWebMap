// Identify, popups and highlighting of original features.
//
// Clicks query only manifest-declared component style layers, then
// deduplicate hits by (logical layer, q2vt_feature_key) so a fill, outline,
// hatch and label of one parcel give one record; of overlapping features one
// opens: the parcel when there is a parcel report (its report lists the zone
// and everything else at that place), else the topmost. Popup values are DOM text (textContent);
// URLs only with http(s)/mailto and noopener. Highlights are overlay layers
// filtered by the feature key (all tile-clipped copies), never a change of
// the base symbols.
import { BackEntry } from "./backstack.mjs";
import { t, formatNumber } from "./i18n.mjs";
import { hiddenAt, matchesFilters } from "./style_control.mjs";
import { WmsInfo } from "./wms_info.mjs";
import { notice } from "./diagnostics.mjs";

const KEY = "q2vt_feature_key";
const SAFE_URL = /^(https?:|mailto:)/i;
const HL = "q2vt_hl_";

// Documents published with the map (manifest.info.documents): a popup value
// naming one (its file name, with or without a folder, or its title) links to it.
const DOCUMENTS = new Map();
export function setDocuments(info, pageUrl) {
  DOCUMENTS.clear();
  for (const doc of (info && Array.isArray(info.documents)) ? info.documents : []) {
    if (!doc || typeof doc.href !== "string" || !/^docs\/[a-z0-9-]+\.[a-z]+$/.test(doc.href)) continue;
    const url = new URL(doc.href, pageUrl).href;
    for (const name of [doc.file, doc.title]) if (typeof name === "string" && name.trim()) DOCUMENTS.set(name.trim().toLowerCase(), url);
  }
}

function documentUrl(value) {
  if (typeof value !== "string" || !DOCUMENTS.size) return null;
  const text = value.trim().toLowerCase();
  return DOCUMENTS.get(text) || DOCUMENTS.get(text.split(/[\\/]/).pop()) || null;
}

export function formatValue(value, type) {
  if (value === null || value === undefined) return { text: t("popup.null"), muted: true };
  const doc = documentUrl(value);
  if (doc) return { text: String(value).trim().split(/[\\/]/).pop(), url: doc };
  if (value === "") return { text: t("popup.empty"), muted: true };
  if (type === "boolean" || typeof value === "boolean") return { text: value ? t("popup.true") : t("popup.false") };
  if ((type === "number" || type === "integer") && typeof value === "number") return { text: formatNumber(value) };
  if (type === "url" && typeof value === "string" && SAFE_URL.test(value.trim())) return { text: value, url: value.trim() };
  return { text: String(value) };
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

export class Identify {
  constructor(ctx) {
    Object.assign(this, ctx); // map, manifest, maplibregl, control, state, lookup, viewer
    this.wms = new WmsInfo({ map: this.map, manifest: this.manifest, control: this.control, state: this.state });
    this.layers = new Map(this.manifest.layers.map((l) => [l.id, l]));
    this.popup = new this.maplibregl.Popup({ maxWidth: "380px", focusAfterOpen: true, closeOnClick: false });
    // Back closes the popup (backstack.mjs).
    this.back = new BackEntry(() => this.popup.remove());
    this.popup.on("close", () => { this.back.closed(); this.select(null); });
    this.overlays = new Set();
    // No hover highlight (owner's choice): only a click selects and marks.
    this.onClick = (event) => this.click(event);
    this.map.on("click", this.onClick);
    // Escape closes the popup; the keyboard goes back to the map.
    this.onKey = (event) => {
      if (event.key !== "Escape" || !this.popup.isOpen()) return;
      const inside = this.popup.getElement()?.contains(document.activeElement);
      // (Escape in the search box or another field is theirs.)
      if (!inside && /^(INPUT|TEXTAREA|SELECT)$/.test(event.target?.tagName || "")) return;
      this.popup.remove();
      if (inside) this.map.getCanvas().focus();
    };
    document.addEventListener("keydown", this.onKey);
  }

  interactiveLayerIds() {
    const ids = [];
    for (const [styleId, component] of this.control.owner) {
      if (!component.interactive && component.role !== "label") continue;
      if (this.map.getLayer(styleId) && this.map.getLayoutProperty(styleId, "visibility") !== "none"
          && !hiddenAt(this.map, styleId)) ids.push(styleId);
    }
    return ids;
  }

  hits(point, tolerance = 4) {
    const layers = this.interactiveLayerIds();
    if (!layers.length) return [];
    const box = [[point.x - tolerance, point.y - tolerance], [point.x + tolerance, point.y + tolerance]];
    const seen = new Map();
    for (const feature of this.map.queryRenderedFeatures(box, { layers })) {
      const component = this.control.owner.get(feature.layer.id);
      if (!component) continue;
      const key = feature.properties ? feature.properties[KEY] : undefined;
      if (key === undefined || key === null) continue;
      const id = `${component.layerId}\u0000${key}`;
      if (!seen.has(id)) seen.set(id, { layerId: component.layerId, key: String(key), feature });
    }
    return [...seen.values()]; // topmost first (queryRenderedFeatures order)
  }

  async click(event) {
    if (this.viewer.measuring || this.viewer.streetView || this.viewer.drawing) return;
    this.ticket = (this.ticket || 0) + 1;  // an earlier click still loading is dropped
    // Popups off, the parcel report on (reportOnly): a click opens parcels only.
    const hits = this.hits(event.point).filter((h) => !this.reportOnly || h.layerId === this.prefer);
    if (!hits.length) {
      this.popup.remove();
      // Live WMS layers: what their servers know about this place.
      const ticket = this.ticket;
      const info = this.wms && this.wms.available && !this.reportOnly ? await this.wms.query(event.lngLat).catch(() => null) : null;
      if (info && ticket === this.ticket) {
        this.popup.setLngLat(event.lngLat).setDOMContent(info).addTo(this.map);
        this.back.open();
        return;
      }
      if (this.onEmpty) this.onEmpty();
      return;
    }
    const hit = (this.prefer && hits.find((h) => h.layerId === this.prefer)) || hits[0];
    await this.open(hit.layerId, hit.key, event.lngLat, hit.feature);
  }

  async open(layerId, key, lngLat, feature = null) {
    const ticket = (this.ticket = (this.ticket || 0) + 1);
    const stale = () => ticket !== this.ticket;  // a newer click came meanwhile
    if (this.intercept && this.intercept(layerId, key, lngLat)) {
      this.popup.remove();
      this.select({ layerId, key });
      return;
    }
    if (this.reportOnly) return;  // (no popups)
    const layer = this.layers.get(layerId);
    let record = null;
    try { record = await this.lookup.get(layerId, key); } catch { record = null; }
    if (stale()) return;
    const box = element("div", "q2vt-popup");
    box.append(element("h3", "", (record && record.t) || (layer ? layer.title : key)));
    if (layer) box.append(element("div", "q2vt-popup-layer", layer.title));
    const fields = layer ? layer.popupFields || [] : [];
    if (record && fields.length) {
      const table = element("table");
      for (const field of fields) {
        const row = element("tr");
        row.append(element("th", "", field.title || field.field));
        const cell = element("td");
        const value = formatValue(record.a ? record.a[field.field] : undefined, field.type);
        if (value.url) {
          const link = element("a", "", value.text);
          link.href = value.url;
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          cell.append(link);
        } else {
          cell.textContent = value.text;
          if (value.muted) cell.className = "q2vt-muted";
        }
        row.append(cell);
        table.append(row);
      }
      box.append(table);
    } else if (!record && fields.length) {
      box.append(element("p", "q2vt-note", t("popup.none")));
    }
    const state = this.state.value;
    if (layer && !this.control.layerEnabled(layerId, state)) {
      box.append(element("p", "q2vt-note", t("popup.layerHidden")));
      const show = element("button", "q2vt-chip", t("popup.showLayer"));
      show.type = "button";
      show.addEventListener("click", () => {
        this.state.setIn("layers", layerId, true);
        if ((state.opacity[layerId] ?? 1) === 0) this.state.setIn("opacity", layerId, 1);
        if (layer.groupId) {
          let id = layer.groupId;
          while (id) { this.state.setIn("groups", id, true); id = this.control.groups.get(id)?.parentId || null; }
        }
      });
      box.append(show);
    } else if (layer && feature && !matchesFilters(layer, state.filters[layerId], feature.properties)) {
      box.append(element("p", "q2vt-note", t("popup.hiddenByFilter")));
    } else if (layer && record && !feature && !matchesFilters(layer, state.filters[layerId], record.a)) {
      box.append(element("p", "q2vt-note", t("popup.hiddenByFilter")));
    }
    if (layer && layer.deepLinks && this.viewer.permalink) {
      const link = element("button", "q2vt-chip q2vt-chip-ghost", t("popup.link"));
      link.type = "button";
      link.addEventListener("click", () => this.viewer.permalink.copy({ selected: { layerId, key } })
        .then((copied) => notice(copied ? "app.copied" : "app.copyFailed")));
      box.append(link);
    }
    // Edition add-ons append their own sections (e.g. zone rules).
    if (this.extend) {
      try { await this.extend(box, { layerId, key, record }); } catch { /* the popup without them */ }
      if (stale()) return;
    }
    const where = lngLat || (record && record.p) || this.map.getCenter();
    this.popup.setLngLat(where).setDOMContent(box).addTo(this.map);
    this.back.open();
    this.select({ layerId, key });
  }

  accent() {
    const value = getComputedStyle(document.documentElement).getPropertyValue("--q2vt-accent").trim();
    return /^#[0-9a-f]{6}$/i.test(value) ? value : "#2563eb";
  }

  ensureOverlay(sourceLayer, sourceId, kind) {
    const id = `${HL}${kind}_${sourceLayer}`;
    if (this.map.getLayer(id)) return id;
    const base = { id, source: sourceId, "source-layer": sourceLayer, filter: ["==", ["get", KEY], "\u0000"] };
    if (kind.endsWith("point")) {
      this.map.addLayer({ ...base, type: "circle", paint: { "circle-radius": 9, "circle-color": "rgba(0,0,0,0)",
        "circle-stroke-color": this.accent(), "circle-stroke-width": 3 } });
    } else {
      this.map.addLayer({ ...base, type: "line", paint: { "line-color": this.accent(),
        "line-width": 3.5, "line-opacity": 0.95 } });
    }
    this.overlays.add(id);
    return id;
  }

  // Overlay source layers of a logical layer: its original geometry dataset
  // (geometry components; the visible-polygon helper for label-only layers),
  // never individual hatch/marker elements.
  overlayTargets(layerId) {
    const components = this.manifest.components.filter((c) => c.layerId === layerId && c.sourceLayer);
    const geometry = components.filter((c) => c.role === "geometry");
    const chosen = geometry.length ? geometry : components.filter((c) => c.role === "decoration");
    const targets = new Map();
    for (const c of chosen) targets.set(c.sourceLayer, c.sourceId);
    if (!targets.size) {
      for (const c of components) for (const helper of c.dependsOnSourceLayers || []) targets.set(helper, c.sourceId);
    }
    return [...targets.entries()];
  }

  setOverlay(prefix, selection) {
    for (const id of this.overlays) {
      if (id.startsWith(HL + prefix)) this.map.setFilter(id, ["==", ["get", KEY], "\u0000"]);
    }
    if (!selection) return;
    const layer = this.layers.get(selection.layerId);
    const point = layer && layer.geometry === "point";
    for (const [sourceLayer, sourceId] of this.overlayTargets(selection.layerId)) {
      const id = this.ensureOverlay(sourceLayer, sourceId, `${prefix}_${point ? "point" : "line"}`);
      this.map.setFilter(id, ["==", ["to-string", ["get", KEY]], String(selection.key)]);
    }
  }

  select(selection) {
    this.selected = selection;
    this.setOverlay("sel", selection);
    // Not persisted; the permalink reads it. Only layers with deep links are
    // in the published feature lookup, so only their features go in links.
    const layer = selection && this.layers.get(selection.layerId);
    this.state.value.selected = layer && layer.deepLinks ? selection : null;
    if (this.viewer.permalink) this.viewer.permalink.schedule();
  }

  destroy() {
    this.map.off("click", this.onClick);
    document.removeEventListener("keydown", this.onKey);
    this.popup.remove();
    for (const id of this.overlays) if (this.map.getLayer(id)) this.map.removeLayer(id);
    this.overlays.clear();
  }
}
