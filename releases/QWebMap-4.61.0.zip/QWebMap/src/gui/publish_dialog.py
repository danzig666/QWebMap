"""
"Publish Web Map" window.

Tabs: Map, Interaction, Output, Destination, Review. Every (non-secret)
setting is saved in the QGIS project (publication_profiles.py); keys are
kept in the QGIS authentication database or only for this session.

* Export locally — runs the exporter on QGIS's main thread (its
  NoThreading guarantees), builds a validated immutable release and keeps
  the project unchanged (layer tree, visibility, styles).
* Preview — serves the local publication on 127.0.0.1 with byte ranges and
  opens it in the web browser (no Node, no tile server).
* Publish — uploads the validated release in a background task (files and
  network only), verifies it through the public URL and only then
  activates it. An SSH / SFTP server gets the site straight into one
  folder instead (not versioned, folder_publish.py). The first publication
  and every change of what becomes public need an explicit approval on the
  Review tab.
"""

import copy
import datetime as _dt
import os
import traceback
from urllib.parse import urlparse

from qgis.core import (Qgis, QgsApplication, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsCsException, QgsExpression, QgsGeometry, QgsIconUtils, QgsLayerTreeGroup,
                       QgsLayerTreeLayer, QgsMessageLog, QgsProcessingFeedback, QgsProject, QgsRasterLayer,
                       QgsRectangle, QgsSettings, QgsTask, QgsVectorLayer, QgsWkbTypes)
from qgis.PyQt.QtCore import QCoreApplication, Qt, QTimer, QUrl, pyqtSignal
from qgis.PyQt.QtGui import QDesktopServices, QGuiApplication
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog,
                                 QDoubleSpinBox, QFileDialog, QFormLayout, QGroupBox,
                                 QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                                 QMenu, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
                                 QRadioButton, QSpinBox, QSplitter, QStackedWidget, QTableWidget,
                                 QTableWidgetItem, QTabWidget, QTextBrowser, QToolButton, QTreeWidget,
                                 QTreeWidgetItem, QVBoxLayout, QWidget)

from ..publishing.errors import PublishingError
from ..publishing.models import (XyzBasemap, BASEMAP_FLAVORS, FIELD_TYPES, CutLineConfig, FilterField, GroupConfig,
                                 LayerConfig, PopupField, PublicationProfile, ReleaseState,
                                 RestrictionConfig, slugify)
from ..publishing.profile import disclosure_fingerprint, needs_review, publication_prefix, validate
from . import publication_profiles as store
from .column_flow import flow_container
from .layer_search import fold as _fold, searchable

TAG = "QWebMap"
CHECKED = Qt.CheckState.Checked
UNCHECKED = Qt.CheckState.Unchecked
PARTIAL = Qt.CheckState.PartiallyChecked
LAYER_ROLE = Qt.ItemDataRole.UserRole
GROUP_ROLE = Qt.ItemDataRole.UserRole + 1
SCALES_ROLE = Qt.ItemDataRole.UserRole + 2  # [min scale, max scale, labels min scale], web only
COL_PUBLISH, COL_VISIBLE, COL_TOGGLE, COL_LEGEND, COL_SCALES = 1, 2, 3, 4, 5
COL_ZOOMED = 6  # vector layers: drawn merged / as images zoomed out (zoomed_out_dialog)
ZOOMED_ROLE = Qt.ItemDataRole.UserRole + 5  # [mode, below zoom or None]


def publishable(layer) -> bool:
    """Vector layers with geometry (MVT) and raster layers (own image archive)."""
    return (isinstance(layer, QgsVectorLayer) and layer.isSpatial()) or isinstance(layer, QgsRasterLayer)


def embed_code(url: str, title: str, height: int = 600) -> str:
    """HTML of the web map in another page: the stable address in embed mode
    (?embed: compact, panel closed, scroll wheel left to the page)."""
    import html  # pylint: disable=import-outside-toplevel
    base, hash_mark, fragment = url.partition("#")  # a shared view (#…) stays at the end
    src = base + ("&" if "?" in base else "?") + "embed" + hash_mark + fragment
    return (f'<iframe src="{html.escape(src, quote=True)}" title="{html.escape(title, quote=True)}" '
            f'style="width:100%;height:{int(height)}px;border:0" allow="fullscreen; geolocation" '
            'loading="lazy"></iframe>')


def _metres(value: float) -> str:
    return f"{value:.2f} m" if value < 10 else f"{value:.0f} m"


def raster_resolution_text(plan) -> str:
    """The image's own pixel size and the sharpest detail the web map shows."""
    from ..publishing.raster_tiles import sharp_zoom  # pylint: disable=import-outside-toplevel
    published = plan.resolution(plan.max_zoom)
    if not plan.native_m:
        return tr("Sharpest detail on the web map: {} per pixel (the image's own resolution is "
                  "unknown, e.g. an online service).").format(_metres(published))
    text = tr("Image: {} per pixel. Sharpest detail on the web map: {} per pixel").format(
        _metres(plan.native_m), _metres(published))
    best = sharp_zoom(plan.native_m, plan.latitude, plan.hidpi, plan.online)
    if plan.max_zoom == best - 1 and not plan.online:
        return text + tr(" – as fine as the image, but zoomed in further it is softer than in QGIS "
                         "(“Like the image” is one step finer).")
    if plan.max_zoom < best:
        return text + tr(" – {}× coarser than the image (choose “Like the image” to show all "
                         "of it).").format(round(2 ** (best - plan.max_zoom - (0 if plan.online else 1))))
    if plan.max_zoom > best:
        return text + tr(" – finer than needed: a larger export, no sharper.")
    return text + tr(" – as sharp as in QGIS.")


def tr(text: str) -> str:
    return QCoreApplication.translate("PublishDialog", text)


def _note(text: str) -> QLabel:
    label = QLabel(text)
    label.setWordWrap(True)
    return label


# The Interaction tab's layer list gets a find box with more layers than this.
LAYER_FILTER_FROM = 10


def _check(value: bool):
    return CHECKED if value else UNCHECKED


class DialogFeedback(QgsProcessingFeedback):
    """Feedback for main-thread stages: progress bar + log, cancellable."""

    def __init__(self, dialog):
        super().__init__()
        self.dialog = dialog

    def setProgress(self, value):  # noqa: N802
        super().setProgress(value)
        self.dialog.progress.setValue(int(max(0, min(100, value))))
        QCoreApplication.processEvents()

    def pushInfo(self, info):  # noqa: N802
        self.dialog.log(info)

    def pushWarning(self, warning):  # noqa: N802
        self.dialog.log(f"⚠ {warning}")

    def reportError(self, error, fatalError=False):  # noqa: N802,N803
        self.dialog.log(f"✖ {error}")


class UploadTask(QgsTask):
    """Upload, verify and activate a validated local release, or write it
    into an SSH server's folder (no QGIS project access: files and network
    only)."""

    message = pyqtSignal(str)

    def __init__(self, release, profile, provider, work_dir, secrets, activate=True):
        super().__init__(tr("Publishing web map"), QgsTask.Flag.CanCancel)
        self.release, self.profile, self.provider = release, profile, provider
        self.work_dir, self.secrets, self.activate_release = work_dir, list(secrets), activate
        self.result = None
        self.error = ""

    def run(self):
        from ..publishing.deployments import publish  # pylint: disable=import-outside-toplevel
        from ..publishing.progress import Progress  # pylint: disable=import-outside-toplevel

        def feedback(percent, text):
            if percent is not None:
                self.setProgress(percent)
            if text:
                self.message.emit(text)
        try:
            if self.provider.kind == "ssh":  # one folder, not versioned
                from ..publishing.folder_publish import publish_folder  # pylint: disable=import-outside-toplevel
                self.result = publish_folder(self.release, self.profile, self.provider, self.work_dir,
                                             Progress(feedback, cancel=self.isCanceled), secrets=self.secrets)
                return True
            self.result = publish(self.release, self.profile, self.provider, self.work_dir,
                                  Progress(feedback, cancel=self.isCanceled), secrets=self.secrets,
                                  activate_release=self.activate_release)
            return True
        except Exception:  # noqa: BLE001 - reported in finished()
            self.error = traceback.format_exc()
            for secret in self.secrets:
                self.error = self.error.replace(secret, "***")
            return False


class PublishDialog(QDialog):
    # (For the simple view, src/gui/simple_page.py.)
    LAYER_ROLE, COL_PUBLISH, COL_VISIBLE = LAYER_ROLE, COL_PUBLISH, COL_VISIBLE
    # Simple or advanced view, per user (QGIS settings): "simple", "advanced", unset (never chosen).
    VIEW_KEY = "QWebMap/publishDialog/view"

    def __init__(self, iface=None, parent=None):
        super().__init__(parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.project = QgsProject.instance()
        from ..publishing.web_builder import plugin_version  # pylint: disable=import-outside-toplevel
        self.setWindowTitle(tr("Publish Web Map — QWebMap {}").format(plugin_version()))
        self.layer_configs = {}
        self.current_layer_id = None
        self.local_result = None
        self.local_profile_json = None
        self.preview_server = None
        self.session_credentials = None
        self.task = None
        self.feedback = None
        self._extent_tool = None   # drawing the extent on the map canvas
        self._draw_notice = None   # its message bar notice
        self._draw_hint = ""       # its status bar text shown last
        # Brings the window back after the drawing (see _extent_drawn).
        self._back_timer = QTimer(self)
        self._back_timer.setSingleShot(True)
        self._back_timer.timeout.connect(self._back_from_drawing)
        self.profile = self._load_profile()
        self._build()
        self._default_size()
        self._restore_geometry()
        self._populate(self.profile)
        # Preview / Open folder: also for a map exported earlier (another
        # session) into the output folder, under this address name.
        for field in (self.o_dir, self.e_slug, self.e_title):
            field.textChanged.connect(self._update_local_buttons)
        self._update_local_buttons()
        self._review_fp = None        # disclosure fingerprint shown on the Review tab
        self._project_gone = False    # the project was closed (File > Open, New)
        self._saved_json = self._profile_json()
        # Another project opened while the window is open: it must not save
        # this project's settings into the new one.
        self.project.cleared.connect(self._on_project_cleared)
        # Layers added, removed or renamed in QGIS while the window is open:
        # its layer list follows (one refresh after a burst of changes).
        self._tree_timer = QTimer(self)
        self._tree_timer.setSingleShot(True)
        self._tree_timer.setInterval(200)
        self._tree_timer.timeout.connect(self._refresh_layers)
        root = self.project.layerTreeRoot()
        for signal in (root.addedChildren, root.removedChildren, root.nameChanged):
            signal.connect(self._layers_changed)
        self.simple.settings_loaded(self.new_settings)
        self.set_simple_view(QgsSettings().value(self.VIEW_KEY, "") == "simple", remember=False)

    def _layers_changed(self, *_):
        if not self._project_gone:
            self._tree_timer.start()

    def _refresh_layers(self):
        """The layer list rebuilt from the window's current settings (so
        nothing edited is lost): new layers appear unpublished, removed ones
        go, renamed ones show their new name. Not while exporting."""
        if self._project_gone or not self.tabs.isEnabled():
            if not self._project_gone:
                self._tree_timer.start()  # after the export / upload
            return
        try:
            profile = self.collect()
        except Exception:  # noqa: BLE001 - a half-edited row: try again later
            self._tree_timer.start(1000)
            return
        self.profile = profile
        self._fill_tree(profile)
        try:
            self._fill_interaction_layers()
        except Exception:  # noqa: BLE001 - the Interaction tab fills itself when shown
            pass
        if self.is_simple_view():
            self.simple.refresh()

    def _profile_json(self):
        try:
            return store.dumps_profile(self.collect())
        except Exception:  # noqa: BLE001 - only a comparison
            return None

    def _on_project_cleared(self):
        self._project_gone = True
        if self.task is None and self.feedback is None:
            # done(), not close(): a hidden window (drawing the extent) must
            # also emit finished, so the plugin lets go of it.
            self.done(QDialog.DialogCode.Rejected)

    # ------------------------------------------------------------------ profile
    def _default_profile(self) -> PublicationProfile:
        title = self.project.title() or os.path.splitext(os.path.basename(self.project.fileName()))[0] \
            or tr("Web map")
        profile = PublicationProfile(title=title, slug=slugify(title))
        for node in self.project.layerTreeRoot().findLayers():
            layer = node.layer()
            if publishable(layer):
                profile.layers.append(LayerConfig(layer.id(), included=node.isVisible(),
                                                  initially_visible=node.isVisible()))
        profile.output.local_directory = self._default_local_directory()
        return profile

    def _moved_project_folder(self, current: str, saved_from: str, ask=None):
        """The export folder after the project was saved as another file
        (``saved_from``: the file the settings were saved in), or None to
        keep ``current``. Asked only when the project's own ``web_maps``
        folder moved too. ``ask(current, suggested)`` (tests): "keep",
        "new" or a chosen folder."""
        suggested = self._default_local_directory()
        if not current or os.path.normcase(os.path.normpath(current)) == \
                os.path.normcase(os.path.normpath(suggested)):
            return None  # nothing to decide (already next to this project)
        if ask is not None:
            answer = ask(current, suggested)
        else:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Question)
            box.setWindowTitle(tr("Project saved as another file"))
            box.setText(tr("This project was saved as another file. All publication settings are kept; "
                           "where should the web map be exported?"))
            box.setInformativeText(tr("Now: {}\nNext to this project: {}").format(current, suggested))
            keep = box.addButton(tr("Keep the folder"), QMessageBox.ButtonRole.RejectRole)
            new = box.addButton(tr("Next to this project"), QMessageBox.ButtonRole.AcceptRole)
            choose = box.addButton(tr("Choose a folder…"), QMessageBox.ButtonRole.ActionRole)
            box.setDefaultButton(keep)
            box.setEscapeButton(keep)
            box.exec()
            clicked = box.clickedButton()
            answer = "new" if clicked is new else "keep"
            if clicked is choose:
                answer = QFileDialog.getExistingDirectory(
                    self, tr("Export folder"), os.path.dirname(self.project.fileName())) or "keep"
        if answer == "keep" or not answer:
            return None
        return suggested if answer == "new" else answer

    def _default_local_directory(self) -> str:
        """``web_maps`` next to the project file (or in the home folder)."""
        base = os.path.dirname(self.project.fileName()) or os.path.expanduser("~")
        return os.path.join(base, "web_maps")

    def _load_profile(self) -> PublicationProfile:
        found = store.active_profile(self.project)
        # The address follows the title only for new settings (never saved,
        # so never exported or published): later it is the map's address.
        self._slug_follows = not found
        self.new_settings = not found  # (the simple view chooses the detail itself for these)
        if not found:
            return self._default_profile()
        profile, saved_from = found
        here = self.project.fileName()
        if saved_from and here and os.path.normcase(saved_from) != os.path.normcase(here):
            # Saved under a new name or in another folder: every setting stays
            # (the same web map); only the export folder may follow the project.
            folder = self._moved_project_folder(profile.output.local_directory, saved_from)
            if folder is not None:
                profile.output.local_directory = folder
            store.save_profile(self.project, profile)  # remembers this project file: asked once
        if not profile.output.local_directory:
            # Saved without a folder (e.g. a shared project): an empty one
            # would export into QGIS's working folder.
            profile.output.local_directory = self._default_local_directory()
        known = {c.layer_id for c in profile.layers}
        for node in self.project.layerTreeRoot().findLayers():
            layer = node.layer()
            if publishable(layer) and layer.id() not in known:
                profile.layers.append(LayerConfig(layer.id(), included=False, initially_visible=False))
        return profile

    def _canvas_extent_3857(self, rect=None):
        """The map canvas extent (or ``rect``, in the canvas CRS) in EPSG:3857."""
        canvas = self.iface.mapCanvas()
        transform = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                           QgsCoordinateReferenceSystem("EPSG:3857"), self.project)
        box = transform.transformBoundingBox(canvas.extent() if rect is None else rect)
        return [box.xMinimum(), box.yMinimum(), box.xMaximum(), box.yMaximum()]

    # ------------------------------------------------------------------ UI
    def _build(self):
        layout = QVBoxLayout(self)
        # Simple / Advanced: the same settings, shown in full or only the essential ones.
        mode_row = QHBoxLayout()
        self.btn_simple = QToolButton()
        self.btn_simple.setText(tr("Simple"))
        self.btn_advanced = QToolButton()
        self.btn_advanced.setText(tr("Advanced"))
        for button, simple in ((self.btn_simple, True), (self.btn_advanced, False)):
            button.setCheckable(True)
            button.setAutoExclusive(True)
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
            button.setMinimumWidth(96)
            button.clicked.connect(lambda _checked, on=simple: self.set_simple_view(on))
            mode_row.addWidget(button)
        self.mode_hint = QLabel()
        mode_row.addWidget(self.mode_hint)
        mode_row.addStretch(1)
        layout.addLayout(mode_row)
        self.view_stack = QStackedWidget()
        layout.addWidget(self.view_stack, 1)
        self.tabs = QTabWidget()
        self.view_stack.addWidget(self.tabs)
        # The widest tabs scroll: the window fits a 1366 × 768 screen.
        self.tabs.addTab(self._scrolled(self._map_tab()), tr("Map"))
        self.tabs.addTab(self._scrolled(self._interaction_tab()), tr("Interaction"))
        self.tabs.addTab(self._basemap_tab(), tr("Basemap"))
        self.tabs.addTab(self._parcel_tab(), tr("Parcel report"))
        self.tabs.addTab(self._info_tab(), tr("Info"))
        self.tabs.addTab(self._scrolled(self._output_tab()), tr("Output"))
        self.tabs.addTab(self._destination_tab(), tr("Destination"))
        self.tabs.addTab(self._review_tab(), tr("Review"))
        self.tabs.currentChanged.connect(self._tab_changed)
        from .simple_page import SimplePage  # pylint: disable=import-outside-toplevel
        self.simple = SimplePage(self)
        self.view_stack.addWidget(self.simple)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.logbox = QPlainTextEdit()
        self.logbox.setReadOnly(True)
        self.logbox.setMaximumBlockCount(2000)
        self.logbox.setMaximumHeight(110)
        layout.addWidget(self.progress)
        layout.addWidget(self.status)
        layout.addWidget(self.logbox)
        buttons = QHBoxLayout()
        self.btn_save = QPushButton(tr("Save settings"))
        self.btn_export = QPushButton(tr("Export locally"))
        self.btn_preview = QPushButton(tr("Preview"))
        self.btn_publish = QPushButton(tr("Publish"))
        self.btn_open = QPushButton(tr("Open map"))
        self.btn_copy = QPushButton(tr("Copy link"))
        self.btn_embed = QPushButton(tr("Copy embed code"))
        self.btn_embed.setToolTip(tr("HTML that shows this web map inside another web page (e.g. the "
                                     "municipality's site): a compact map, with a link to the full one"))
        self.btn_folder = QPushButton(tr("Open local package"))
        self.btn_cancel = QPushButton(tr("Cancel"))
        self.btn_close = QPushButton(tr("Close"))
        # Settings to / from a file (another project, a colleague, a backup).
        self.btn_settings_file = QToolButton()
        self.btn_settings_file.setText(tr("Settings file…"))
        self.btn_settings_file.setToolTip(tr("Export these settings to a file, or import settings "
                                             "from one (layers are matched by name in another project)."))
        self.btn_settings_file.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        file_menu = QMenu(self)
        file_menu.addAction(tr("Export settings to a file…"), self.export_settings_file)
        file_menu.addAction(tr("Import settings from a file…"), self.import_settings_file)
        self.btn_settings_file.setMenu(file_menu)
        for button in (self.btn_save, self.btn_settings_file, self.btn_export, self.btn_preview,
                       self.btn_publish, self.btn_open, self.btn_copy, self.btn_embed, self.btn_folder):
            buttons.addWidget(button)
        # Presets (domain conventions, e.g. a national zoning plan): only when a
        # variant of the plugin ships some (publishing/presets).
        from ..publishing import presets  # pylint: disable=import-outside-toplevel
        self.presets = presets.available()
        self.btn_preset = QToolButton()
        self.btn_preset.setText(tr("Preset…"))
        self.btn_preset.setToolTip(tr("Fill the settings from a preset; review them before publishing."))
        self.btn_preset.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(self)
        for module in self.presets:
            menu.addAction(module.TITLE, lambda m=module: self.apply_preset(m))
        self.btn_preset.setMenu(menu)
        self.btn_preset.setVisible(bool(self.presets))
        buttons.addWidget(self.btn_preset)
        buttons.addStretch(1)
        buttons.addWidget(self.btn_cancel)
        buttons.addWidget(self.btn_close)
        layout.addLayout(buttons)
        self.btn_save.clicked.connect(self.save_settings)
        self.btn_export.clicked.connect(self.export_locally)
        self.btn_preview.clicked.connect(self.preview)
        self.btn_publish.clicked.connect(self.publish)
        self.btn_open.clicked.connect(self.open_map)
        self.btn_copy.clicked.connect(self.copy_link)
        self.btn_embed.clicked.connect(self.copy_embed_code)
        self.btn_folder.clicked.connect(self.open_folder)
        self.btn_cancel.clicked.connect(self.cancel)
        self.btn_close.clicked.connect(self.close)
        self.btn_cancel.setEnabled(False)
        for button in (self.btn_preview, self.btn_open, self.btn_copy, self.btn_folder):
            button.setEnabled(False)
        self.public_url = ""

    def is_simple_view(self) -> bool:
        return getattr(self, "view_stack", None) is not None and self.view_stack.currentIndex() == 1

    def set_simple_view(self, on: bool, remember: bool = True):
        """The simple view (the essential settings, local export) or all the
        settings: the same settings either way, nothing changes or is lost."""
        self.view_stack.setCurrentIndex(1 if on else 0)
        self.btn_simple.setChecked(on)
        self.btn_advanced.setChecked(not on)
        self.mode_hint.setText(tr("Only the essential settings; the map is made in a folder on this computer.")
                               if on else tr("All the settings, publishing online included."))
        for widget in (self.btn_save, self.btn_settings_file, self.btn_export, self.btn_preview,
                       self.btn_publish, self.btn_open, self.btn_copy, self.btn_embed, self.btn_folder,
                       self.logbox):
            widget.setVisible(not on)
        # (Simple: the progress bar only while a map is made, see _busy.)
        self.progress.setVisible(not on or self.btn_cancel.isEnabled())
        self.btn_preset.setVisible(not on and bool(self.presets))
        if on:
            self.simple.refresh()
        if remember:
            QgsSettings().setValue(self.VIEW_KEY, "simple" if on else "advanced")

    def ask_first_view(self):
        """First use of the window by this user: simple or advanced view?
        (Asked once; users of earlier versions keep the advanced view.)"""
        settings = QgsSettings()
        if settings.value(self.VIEW_KEY, ""):
            return
        if settings.value(self.GEOMETRY_KEY):  # the window was used before: as it was
            settings.setValue(self.VIEW_KEY, "advanced")
            return
        box = QMessageBox(QMessageBox.Icon.Question, tr("Publish Web Map"), tr(
            "How would you like to start?"), QMessageBox.StandardButton.NoButton, self)
        box.setInformativeText(tr(
            "Simple: the few settings a first web map needs, in plain words, and one button that makes "
            "it in a folder on this computer.\n\nAdvanced: all the settings, publishing online "
            "included.\n\nYou can switch at any time at the top of the window."))
        simple = box.addButton(tr("Simple"), QMessageBox.ButtonRole.AcceptRole)
        box.addButton(tr("Advanced"), QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(simple)
        # Over the shown window, without waiting for the answer here (closed
        # unanswered: advanced, the earlier versions' window).
        box.finished.connect(lambda _result: self.set_simple_view(box.clickedButton() is simple))
        box.open()
        self._first_view_box = box

    def _title_edited(self, text):
        # Only while the address is still the one made from the title (not typed in).
        if getattr(self, "_slug_follows", False) and \
                self.e_slug.text() == slugify(getattr(self, "_slug_title", self.profile.title)):
            self.e_slug.setText(slugify(text))
        self._slug_title = text

    def _map_tab(self):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        form_box = QGroupBox(tr("Web map"))
        form = QFormLayout(form_box)
        self.e_title = QLineEdit()
        self.e_slug = QLineEdit()
        self.e_title.textEdited.connect(self._title_edited)
        self.e_description = QPlainTextEdit()
        self.e_description.setMaximumHeight(70)
        self.e_locale = QComboBox()
        self.e_locale.addItem("English", "en")
        self.e_locale.addItem("Magyar", "hu")
        self.e_attribution = QLineEdit()
        logo_row = QHBoxLayout()
        self.e_logo = QLineEdit()
        logo_button = QPushButton("…")
        logo_button.clicked.connect(self._choose_logo)
        logo_row.addWidget(self.e_logo)
        logo_row.addWidget(logo_button)
        form.addRow(tr("Title"), self.e_title)
        form.addRow(tr("Address name (slug)"), self.e_slug)
        form.addRow(tr("Description"), self.e_description)
        form.addRow(tr("Language of the viewer"), self.e_locale)
        form.addRow(tr("Attribution"), self.e_attribution)
        form.addRow(tr("Logo (PNG/JPEG/WebP)"), logo_row)
        self.e_min_zoom = QSpinBox()
        self.e_min_zoom.setRange(0, 22)
        self.e_max_zoom = QSpinBox()
        self.e_max_zoom.setRange(0, 22)
        self.e_max_view = QSpinBox()
        self.e_max_view.setRange(0, 24)
        form.addRow(tr("Minimum tile zoom"), self.e_min_zoom)
        form.addRow(tr("Maximum tile zoom"), self.e_max_zoom)
        form.addRow(tr("Maximum browser zoom (overzoom)"), self.e_max_view)
        scales = QPushButton(tr("Use web zoom scales in QGIS…"))
        scales.setToolTip(tr(
            "Sets this project's scale list (the scale box, and the scale limits of rules and labels) "
            "to the scales of the web map's zoom levels: a scale limit picked from it starts or ends "
            "exactly at a zoom level."))
        scales.clicked.connect(self.use_web_zoom_scales)
        self.e_zoom_scales = scales
        form.addRow("", scales)
        self.e_limit_extent = QCheckBox(tr("Keep the web map on the extent (no panning or zooming away)"))
        # Extent: the map view at each export (asked before it), a layer's
        # extent (follows the layer) or a fixed area (drawn, or the view
        # frozen); summarized in words, not raw coordinates.
        extent_box = QVBoxLayout()
        mode_row = QHBoxLayout()
        self.e_extent_mode = QComboBox()
        for mode, text in (("canvas", tr("Current map view (at each export)")),
                           ("layer", tr("Extent of a layer")),
                           ("fixed", tr("Fixed area (drawn or frozen)"))):
            self.e_extent_mode.addItem(text, mode)
        self.e_extent_mode.setToolTip(tr(
            "The published area. Current map view: what the QGIS map shows when you export "
            "(you are asked each time). Extent of a layer: follows the layer when its data "
            "changes. Fixed area: drawn on the map, or the map view frozen with “Freeze view”."))
        self.e_extent_mode.currentIndexChanged.connect(self._extent_mode_changed)
        self.e_extent_mode.activated.connect(self._extent_mode_chosen)
        show_button = QPushButton(tr("Show on map"))
        show_button.setToolTip(tr("Outline the area that will be published on the QGIS map."))
        show_button.clicked.connect(self._flash_extent)
        show_button.setEnabled(self.iface is not None)
        mode_row.addWidget(self.e_extent_mode, 1)
        mode_row.addWidget(show_button)
        extent_box.addLayout(mode_row)
        extent_row = QHBoxLayout()
        self.e_extent_layer = self._layer_combo(any_layer=True, allow_empty=True,
                                                empty_text=tr("(choose a layer)"))
        self.e_extent_layer.setToolTip(tr("The published area is this layer's extent; it follows "
                                          "the layer when its data changes."))
        self.e_extent_layer.layerChanged.connect(self._extent_layer_changed)
        extent_button = QPushButton(tr("Freeze view"))
        extent_button.setToolTip(tr("Fix the published area to what the QGIS map shows now."))
        extent_button.clicked.connect(lambda: self._use_canvas_extent())
        extent_button.setEnabled(self.iface is not None)
        draw_button = QPushButton(tr("Draw…"))
        draw_button.setToolTip(tr("Draw the published area on the QGIS map: click one corner, "
                                  "then the opposite corner (right click or Esc cancels)."))
        draw_button.clicked.connect(self._draw_extent)
        draw_button.setEnabled(self.iface is not None)
        self.e_extent_layer.setMinimumContentsLength(12)
        extent_row.addWidget(self.e_extent_layer, 1)
        extent_row.addWidget(extent_button)
        extent_row.addWidget(draw_button)
        extent_box.addLayout(extent_row)
        # Short lines, not wrapped: the form reserves their full height.
        self.extent_label = QLabel()
        self.extent_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        extent_box.addWidget(self.extent_label)
        form.addRow(tr("Extent"), extent_box)
        form.addRow("", self.e_limit_extent)
        try:
            from qgis.gui import QgsColorButton  # pylint: disable=import-outside-toplevel
            self.e_accent = QgsColorButton()
            self.e_accent.setAllowOpacity(False)
        except ImportError:
            self.e_accent = QLineEdit()
        form.addRow(tr("Accent colour of the viewer"), self.e_accent)
        layout.addWidget(form_box, 2)
        layers_box = QGroupBox(tr("Layers (publishing does not change the project's layer visibility)"))
        layers_layout = QVBoxLayout(layers_box)
        theme_row = QHBoxLayout()
        self.theme_pick = QComboBox()
        self.theme_pick.setToolTip(tr("A QGIS map theme (View → Map Themes)"))
        publish_theme = QPushButton(tr("Publish its layers"))
        publish_theme.setToolTip(tr("Also publish the layers visible in this map theme and offer it "
                                    "as a view of the web map (layers already published stay "
                                    "published, so several themes add up)"))
        publish_theme.clicked.connect(lambda: self._apply_theme(publish=True))
        start_theme = QPushButton(tr("Use as start view"))
        start_theme.setToolTip(tr("Visible at start: the layers visible in this map theme"))
        start_theme.clicked.connect(lambda: self._apply_theme(publish=False))
        theme_row.addWidget(QLabel(tr("Map theme:")))
        theme_row.addWidget(self.theme_pick, 1)
        theme_row.addWidget(publish_theme)
        theme_row.addWidget(start_theme)
        layers_layout.addLayout(theme_row)
        bulk_row = QHBoxLayout()
        self.bulk = QToolButton()
        self.bulk.setText(tr("Selected layers"))
        self.bulk.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.bulk.setMenu(self._bulk_menu())
        bulk_row.addWidget(QLabel(tr("Select several rows (Ctrl/Shift + click) to change them together:")), 1)
        bulk_row.addWidget(self.bulk)
        publish_visible = QPushButton(tr("Publish the visible layers"))
        publish_visible.setToolTip(tr("Publish exactly the layers visible in the QGIS Layers panel now "
                                      "(also visible at start); the hidden ones are no longer published"))
        publish_visible.clicked.connect(self.publish_visible_layers)
        bulk_row.addWidget(publish_visible)
        zoom_load_button = QPushButton(tr("Zoomed-out load…"))
        zoom_load_button.setToolTip(tr(
            "Which layers make the web map slow when zoomed out, and from which zoom their features, "
            "or only their labels, are worth drawing; the suggestions can be applied with one click"))
        zoom_load_button.clicked.connect(lambda: self.analyse_zoom_load())
        bulk_row.addWidget(zoom_load_button)
        layers_layout.addLayout(bulk_row)
        filter_row = QHBoxLayout()
        self.tree_filter = QLineEdit()
        self.tree_filter.setClearButtonEnabled(True)
        self.tree_filter.setPlaceholderText(tr("Filter layers by name…"))
        self.tree_filter.setToolTip(tr("Shows the layers whose name contains this text (upper or lower "
                                       "case, accents not needed) and the groups that hold them; a "
                                       "group's name shows its whole group"))
        self.tree_filter.textChanged.connect(self._filter_tree)
        self.tree_published_only = QCheckBox(tr("Only published layers"))
        self.tree_published_only.setToolTip(tr("Hide the layers that are not published"))
        self.tree_published_only.toggled.connect(self._filter_tree)
        filter_row.addWidget(self.tree_filter, 1)
        filter_row.addWidget(self.tree_published_only)
        layers_layout.addLayout(filter_row)
        self.tree = QTreeWidget()
        # Short headers (the layer names need the room); the meaning in tooltips.
        self.tree.setHeaderLabels([tr("Layer"), tr("Publish"), tr("At start"), tr("Switchable"),
                                   tr("Legend"), tr("Scales"), tr("Zoomed out")])
        self.tree.headerItem().setToolTip(COL_ZOOMED, tr(
            "Vector layers: drawn lighter when zoomed out beyond a zoom - the features of one style "
            "merged per tile, or images rendered by QGIS - instead of every feature. Double-click a "
            "cell, or select rows → Selected layers → Zoomed out…"))
        self.tree.headerItem().setToolTip(COL_LEGEND, tr("Shown in the web map's legend"))
        self.tree.headerItem().setToolTip(COL_PUBLISH, tr("Published in the web map"))
        self.tree.headerItem().setToolTip(COL_VISIBLE, tr("Visible when the web map opens"))
        self.tree.headerItem().setToolTip(COL_TOGGLE, tr("Visitors can switch it off"))
        self.tree.headerItem().setToolTip(COL_SCALES, tr(
            "Web map only: hide layers when zoomed out (or in) beyond a scale - faster when zoomed "
            "out, smaller export. Double-click a cell, or select rows → Selected layers → Visible "
            "scales…"))
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for column in (COL_PUBLISH, COL_VISIBLE, COL_TOGGLE, COL_LEGEND, COL_SCALES, COL_ZOOMED):
            self.tree.header().setSectionResizeMode(column, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.itemDoubleClicked.connect(self._tree_double_clicked)
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(
            lambda pos: self._bulk_menu().exec(self.tree.viewport().mapToGlobal(pos)))
        self.tree.itemChanged.connect(self._tree_changed)
        layers_layout.addWidget(self.tree, 1)
        themes_row = QHBoxLayout()
        self.themes_list = QListWidget()
        self.themes_list.setMaximumHeight(84)
        self.themes_list.itemChanged.connect(self._theme_item_changed)
        self.theme_initial = QComboBox()
        themes_box = QVBoxLayout()
        themes_box.addWidget(QLabel(tr("Map themes offered as views in the web map:")))
        themes_box.addWidget(self.themes_list)
        initial_box = QVBoxLayout()
        initial_box.addWidget(QLabel(tr("Start with:")))
        initial_box.addWidget(self.theme_initial)
        initial_box.addStretch(1)
        themes_row.addLayout(themes_box, 2)
        themes_row.addLayout(initial_box, 1)
        layers_layout.addLayout(themes_row)
        layout.addWidget(layers_box, 3)
        return widget

    # ------------------------------------------------------------------ layer tree
    def _bulk_menu(self):
        menu = QMenu(self)
        for text, column, value in (
                (tr("Publish"), COL_PUBLISH, True), (tr("Do not publish"), COL_PUBLISH, False),
                (tr("Visible at start"), COL_VISIBLE, True), (tr("Hidden at start"), COL_VISIBLE, False),
                (tr("Can be switched off by visitors"), COL_TOGGLE, True),
                (tr("Always shown (cannot be switched off)"), COL_TOGGLE, False),
                (tr("Show in the legend"), COL_LEGEND, True), (tr("Hide from the legend"), COL_LEGEND, False)):
            menu.addAction(text, lambda c=column, v=value: self.apply_to_selection(c, v))
        menu.addSeparator()
        menu.addAction(tr("Visible scales…"), self.edit_scales)
        menu.addAction(tr("Zoomed out…"), self.edit_zoomed_out)
        return menu

    def _selected_layer_items(self):
        """Selected layer rows; a selected group stands for every layer in it."""
        items, seen = [], set()
        for item in self.tree.selectedItems():
            for target in [item] + (list(self._shown_descendants(item)) if item.data(0, GROUP_ROLE) else []):
                if target.data(0, LAYER_ROLE) and id(target) not in seen:
                    seen.add(id(target))
                    items.append(target)
        return items

    def _tree_double_clicked(self, item, column):
        if column == COL_ZOOMED and (item.data(0, LAYER_ROLE) or item.data(0, GROUP_ROLE)):
            if not item.isSelected():
                self.tree.clearSelection()
                item.setSelected(True)
            self.edit_zoomed_out()
            return
        if column == COL_SCALES and (item.data(0, LAYER_ROLE) or item.data(0, GROUP_ROLE)):
            if not item.isSelected():
                self.tree.clearSelection()
                item.setSelected(True)
            self.edit_scales()

    def edit_scales(self, values=None) -> bool:
        """Set the web-only visible scale range of the selected layers
        (``values``: (min scale, max scale[, labels min scale]) instead of
        asking; without the third value the labels limit stays)."""
        from .scale_range import ScaleRangeDialog, range_text  # pylint: disable=import-outside-toplevel
        items = self._selected_layer_items()
        if not items:
            self.status.setText(tr("Select layers (or groups) in the list first."))
            return False
        if values is None:
            # Several rows: each limit shown only when all of them share it;
            # a limit left as shown keeps each row's own.
            rows = [self._item_scales(item) for item in items]
            shown = [rows[0][k] if all(row[k] == rows[0][k] for row in rows) else 0.0 for k in range(3)]
            layer = self.project.mapLayer(items[0].data(0, LAYER_ROLE))
            own = range_text(layer.minimumScale(), layer.maximumScale()) \
                if layer is not None and layer.hasScaleBasedVisibility() else ""
            dialog = ScaleRangeDialog(self, shown[0], shown[1], len(items), own if len(items) == 1 else "",
                                      self.iface.mapCanvas() if self.iface is not None else None,
                                      shown[2])
            if not dialog.exec():
                return False
            chosen = [float(v or 0) for v in dialog.values()]
            merged = [[row[k] if chosen[k] == shown[k] else chosen[k] for k in range(3)] for row in rows]
        else:
            merged = [list(values) for _item in items]
        # A new limit with a row's own other limit can leave no scale at all
        # (the dialog checks only the limits it shows): such rows stay.
        conflicts = []
        for item, row in zip(items, merged):
            if row[0] and row[1] and row[1] >= row[0]:
                conflicts.append(item.text(0))
            else:
                self._set_item_scales(item, *row)
        if conflicts:
            QMessageBox.warning(self, tr("Visible scales"), tr(
                "Not changed: with this limit, these layers would be shown at no scale (the zoomed-out "
                "limit must be a smaller scale than the zoomed-in limit):\n{}").format("\n".join(conflicts[:12])))
        return len(conflicts) < len(items)

    def edit_zoomed_out(self, values=None) -> bool:
        """How the selected vector layers are drawn zoomed out (``values``:
        (mode, below zoom) instead of asking). Raster layers keep theirs."""
        from .zoomed_out_dialog import ZoomedOutDialog  # pylint: disable=import-outside-toplevel
        items = [item for item in self._selected_layer_items()
                 if not isinstance(self.project.mapLayer(item.data(0, LAYER_ROLE)), QgsRasterLayer)]
        if not items:
            self.status.setText(tr("Select vector layers (or groups) in the list first."))
            return False
        if values is None:
            mode, below = self._item_zoomed(items[0])
            dialog = ZoomedOutDialog(self, mode, below, len(items), self.e_max_zoom.value())
            if not dialog.exec():
                return False
            values = dialog.values()
        for item in items:
            self._set_item_zoomed(item, *values)
        return True

    @staticmethod
    def _item_zoomed(item):
        """(mode, below zoom or None) of a layer row."""
        mode, below = (list(item.data(COL_ZOOMED, ZOOMED_ROLE) or ()) + ["full", None])[:2]
        return (mode, int(below)) if mode in ("merged", "image") and below else ("full", None)

    def _set_item_zoomed(self, item, mode, below):
        from .zoomed_out_dialog import zoomed_out_text  # pylint: disable=import-outside-toplevel
        if mode not in ("merged", "image") or not below:
            mode, below = "full", None
        item.setData(COL_ZOOMED, ZOOMED_ROLE, [mode, below])
        item.setText(COL_ZOOMED, zoomed_out_text(mode, below))
        item.setToolTip(COL_ZOOMED, tr("Every feature at every zoom") if mode == "full" else (
            tr("Below zoom {}: the features of one style merged per tile").format(below) if mode == "merged"
            else tr("Below zoom {}: images rendered by QGIS").format(below)))

    @staticmethod
    def _item_scales(item):
        """(min scale, max scale, labels min scale) of a layer row; 0 = none."""
        values = list(item.data(COL_SCALES, SCALES_ROLE) or ()) + [0.0, 0.0, 0.0]
        return float(values[0] or 0), float(values[1] or 0), float(values[2] or 0)

    def analyse_zoom_load(self, accept=None, estimate=None) -> bool:
        """Estimate the zoomed-out load of the published vector layers and
        offer per-layer limits (``accept``: a callable given the dialog,
        returning whether it was accepted; for tests). ``estimate``: an
        estimate already made ((profile, loads, factor))."""
        from .zoom_load_dialog import ZoomLoadDialog  # pylint: disable=import-outside-toplevel
        if estimate is None:
            estimate = self._estimate_zoom_load()
        if estimate is None:
            return False
        profile, loads, factor = estimate
        if not loads:
            self.status.setText(tr("No published vector layer has features in the extent."))
            return False
        self.status.setText("")
        dialog = ZoomLoadDialog(self, loads, factor, (profile.view.min_zoom, profile.view.max_zoom))
        accepted = accept(dialog) if accept is not None else dialog.exec()
        if accepted:
            limits = self.apply_zoom_limits(dialog.chosen())
            modes = self.apply_zoomed_out(dialog.chosen_modes())
            if limits and modes:
                self.status.setText(tr("Zoomed-out limits set for {} layer(s) (Scales column), drawing "
                                       "for {} (Zoomed out column).").format(limits, modes))
        # Seen (and its limits applied or not): the export does not check
        # this state again (_check_zoom_load_before_export).
        self._zoom_load_handled = self._zoom_load_fingerprint()
        return bool(accepted)

    # Before an export: a web map that will be slow zoomed out is pointed out
    # (with the Zoomed-out load suggestions), unless switched off.
    ZOOM_LOAD_CHECK_KEY = "QWebMap/checkZoomLoadBeforeExport"

    def _check_zoom_load_before_export(self) -> bool:
        """False: the export is cancelled."""
        if str(QgsSettings().value(self.ZOOM_LOAD_CHECK_KEY, "true")).lower() in ("false", "0"):
            return True
        current = self._zoom_load_fingerprint()
        if current is not None and current == self._zoom_load_handled:
            return True  # estimated and answered, nothing it reads changed since
        estimate = self._estimate_zoom_load()
        if estimate is None:
            return True  # cancelled or no extent: the export goes on (and says what is wrong)
        profile, loads, factor = estimate
        from ..publishing import zoom_load  # pylint: disable=import-outside-toplevel
        from .zoom_load_dialog import SPEED_KEY  # pylint: disable=import-outside-toplevel
        try:
            speed = int(QgsSettings().value(SPEED_KEY, zoom_load.BALANCED))
        except (TypeError, ValueError):
            speed = zoom_load.BALANCED
        if speed != zoom_load.BALANCED:
            zoom_load.resuggest(loads, int(profile.view.max_zoom), speed)
        slow = [load for load in loads if load.suggested_from is not None
                or load.suggested_labels_from is not None or load.mode_suggested()]
        if not slow:
            self._zoom_load_handled = current
            return True
        answer, remind = self._ask_zoom_load(slow)
        if not remind:
            QgsSettings().setValue(self.ZOOM_LOAD_CHECK_KEY, False)
        if answer == "faster":
            # Its window cancelled: the export too (asked about once: the next
            # export goes on as it is).
            return bool(self.analyse_zoom_load(estimate=estimate))
        if answer == "as-is":
            self._zoom_load_handled = current
        return answer == "as-is"

    # The last estimate ((fingerprint, estimate)) and the fingerprint of the
    # state whose estimate was answered (zoom_load.fingerprint).
    _zoom_load_cache = None
    _zoom_load_handled = None

    def _zoom_load_fingerprint(self):
        """zoom_load.fingerprint of the window's settings now; None when it
        cannot be made (no extent, a layer with unsaved edits)."""
        from ..publishing import zoom_load  # pylint: disable=import-outside-toplevel
        try:
            return zoom_load.fingerprint(self.project, self.collect(), self._extent())
        except Exception:  # noqa: BLE001 - then the estimate simply runs
            return None

    def _large_rasters(self):
        """[(layer name, advice)] of the rendered raster layers with more
        than LARGE_TILES_PER_LAYER tiles in the extent."""
        from ..publishing import live_raster, qgis_model  # pylint: disable=import-outside-toplevel
        from ..publishing.raster_tiles import (LARGE_TILES_PER_LAYER, large_raster_advice,  # pylint: disable=import-outside-toplevel
                                               plan_layer)
        try:
            extent = self._extent()
        except PublishingError:
            return []  # the export says what is wrong
        profile = self.collect()
        out = []
        for config in qgis_model.split_profile(profile, self.project)[1]:
            layer = self.project.mapLayer(config.layer_id)
            if layer is None or (config.raster_live and live_raster.live_source(layer)[0]):
                continue  # loaded live: nothing rendered
            try:
                plan = plan_layer(self.project, layer, config, profile, extent)
            except Exception:  # noqa: BLE001 - a broken layer: the export reports it
                continue
            if plan.tiles > LARGE_TILES_PER_LAYER:
                out.append((layer.name(), large_raster_advice(plan, layer.name(), config,
                                                              profile.view.max_zoom)))
        return out

    def _check_large_rasters(self, ask=None) -> bool:
        """Before an export: a raster layer of very many tiles (hours of
        rendering) is pointed out, with what sets its size and how to make
        it smaller. False: the export is cancelled. ``ask(text)`` (tests):
        True to export anyway."""
        large = self._large_rasters()
        if not large:
            return True
        text = tr("This export will take a very long time (hours) and make a very large web map: "
                  "{} raster layer(s) have far more tiles than usual.").format(len(large))
        details = "\n\n".join(advice for _, advice in large)
        if ask is not None:
            return bool(ask(text + "\n\n" + details))
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle(tr("Very large raster layer"))
        box.setText(text)
        box.setInformativeText(details)
        anyway = box.addButton(tr("Export anyway"), QMessageBox.ButtonRole.DestructiveRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(QMessageBox.StandardButton.Cancel)
        box.exec()
        return box.clickedButton() is anyway

    def _ask_zoom_load(self, slow):
        """("faster" | "as-is" | "cancel", remind again)."""
        from .zoom_load_dialog import short_name  # pylint: disable=import-outside-toplevel
        lines = []
        for load in slow[:5]:
            parts = []
            if load.suggested_from is not None:
                parts.append(tr("features from zoom {} (now {})").format(load.suggested_from, load.shown_from))
            if load.mode_suggested():
                parts.append((tr("merged below zoom {}") if load.suggested_mode == "merged"
                              else tr("as images below zoom {}")).format(load.suggested_mode_below))
            if load.suggested_labels_from is not None:
                parts.append(tr("labels from zoom {} (now {})").format(load.suggested_labels_from,
                                                                       load.labels_from))
            lines.append("• {}: {}".format(short_name(load.name, 40), ", ".join(parts)))
        if len(slow) > 5:
            lines.append(tr("… and {} more").format(len(slow) - 5))
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Question)
        box.setWindowTitle(tr("Zoomed-out load"))
        box.setText(tr("The web map will be slow when zoomed out: {} layer(s) put more into a tile "
                       "than is worth loading and drawing there. Hiding them when zoomed out beyond "
                       "these zooms, or drawing them merged or as images there, makes the map faster:").format(len(slow)) + "\n\n" + "\n".join(lines))
        faster = box.addButton(tr("Make it faster…"), QMessageBox.ButtonRole.AcceptRole)
        as_is = box.addButton(tr("Export as it is"), QMessageBox.ButtonRole.DestructiveRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(faster)
        check = QCheckBox(tr("Don't check this before exports (the Map tab's Zoomed-out load… button "
                             "still does)"))
        box.setCheckBox(check)
        box.exec()
        clicked = box.clickedButton()
        answer = "faster" if clicked is faster else "as-is" if clicked is as_is else "cancel"
        return answer, not check.isChecked()

    def _estimate_zoom_load(self):
        """(profile, loads, factor) of the published vector layers, or None
        (no extent, or cancelled)."""
        from ..publishing import zoom_load  # pylint: disable=import-outside-toplevel
        try:
            extent = self._extent()
        except PublishingError as error:
            self.status.setText(str(error))
            return None
        profile = self.collect()
        current = self._zoom_load_fingerprint()
        cached = self._zoom_load_cache
        if current is not None and cached is not None and cached[0] == current:
            return cached[1]  # nothing it reads changed: the same estimate
        self.status.setText(tr("Estimating the zoomed-out load…"))
        from qgis.PyQt.QtWidgets import QProgressDialog  # pylint: disable=import-outside-toplevel
        waiting = QProgressDialog(tr("Estimating the zoomed-out load…"), tr("Cancel"), 0, 1, self)
        waiting.setWindowTitle(tr("Zoomed-out load"))
        waiting.setWindowModality(Qt.WindowModality.WindowModal)
        waiting.setMinimumDuration(400)  # shown only when it takes a while
        waiting.setFixedWidth(460)  # a long layer name does not widen (and shift) it
        from .zoom_load_dialog import short_name  # pylint: disable=import-outside-toplevel

        def progress(done, total, name):
            waiting.setMaximum(max(1, total))
            waiting.setValue(done)
            waiting.setLabelText(tr("Estimating the zoomed-out load…\nLayer {} of {}: {}").format(
                done + 1, total, short_name(name, 48)))
            QApplication.processEvents()
            return not waiting.wasCanceled()
        try:
            result = zoom_load.analyse(self.project, profile, extent, progress)
        finally:
            waiting.close()
        if result is None:
            self.status.setText(tr("Zoomed-out load: cancelled."))
            return None
        self.status.setText("")
        estimate = (profile,) + tuple(result)
        self._zoom_load_cache = (current, estimate) if current is not None else None
        return estimate

    def apply_zoom_limits(self, chosen) -> int:
        """Set {layer id: (min scale or None, labels min scale or None)} in
        the Scales column (None: that limit stays, 0: no limit); returns the
        rows changed."""
        changed = 0
        for item in self._tree_items():
            limits = chosen.get(item.data(0, LAYER_ROLE))
            if not limits:
                continue
            low, high, labels_low = self._item_scales(item)
            new_low, new_labels = limits  # None: stays; 0: no limit
            if new_low is not None and not (new_low and high and high >= new_low):
                low = new_low
            if new_labels is not None:
                labels_low = new_labels
            self._set_item_scales(item, low, high, labels_low)
            changed += 1
        if changed:
            self.status.setText(tr("Zoomed-out limits set for {} layer(s) (Scales column).").format(changed))
        return changed

    def apply_zoomed_out(self, chosen) -> int:
        """Set {layer id: (mode, below zoom or None)} in the Zoomed out
        column; returns the rows changed."""
        changed = 0
        for item in self._tree_items():
            values = chosen.get(item.data(0, LAYER_ROLE))
            if values:
                self._set_item_zoomed(item, *values)
                changed += 1
        if changed:
            self.status.setText(tr("Zoomed-out drawing set for {} layer(s) (Zoomed out column).").format(changed))
        return changed

    def _set_item_scales(self, item, low, high, labels_low=None):
        """``labels_low`` None: the row's labels limit stays."""
        from .scale_range import labels_text, range_text  # pylint: disable=import-outside-toplevel
        if labels_low is None:
            labels_low = self._item_scales(item)[2]
        item.setData(COL_SCALES, SCALES_ROLE, [float(low or 0), float(high or 0), float(labels_low or 0)])
        layer = self.project.mapLayer(item.data(0, LAYER_ROLE))
        own = range_text(layer.minimumScale(), layer.maximumScale()) \
            if layer is not None and layer.hasScaleBasedVisibility() else ""
        text = " · ".join(part for part in (range_text(low, high), labels_text(labels_low)) if part)
        item.setText(COL_SCALES, text or (tr("(QGIS {})").format(own) if own else ""))
        item.setForeground(COL_SCALES, self.palette().text() if text else self.palette().placeholderText())
        item.setToolTip(COL_SCALES, (tr("Web map: {}").format(text) if text else tr("No web limit"))
                        + (tr("\nQGIS layer: {}").format(own) if own else ""))

    def _descendants(self, item):
        for i in range(item.childCount()):
            child = item.child(i)
            yield child
            yield from self._descendants(child)

    def _shown_descendants(self, item):
        """The descendants the layer filter shows (bulk changes act on what is seen)."""
        for i in range(item.childCount()):
            child = item.child(i)
            if child.isHidden():
                continue
            yield child
            yield from self._shown_descendants(child)

    def apply_to_selection(self, column: int, value: bool):
        """Set a column for the selected rows; a selected group also applies
        to every layer (and group) inside it."""
        targets = []
        for item in self.tree.selectedItems():
            targets.append(item)
            if item.data(0, GROUP_ROLE):
                targets.extend(self._shown_descendants(item))
        seen = set()
        for item in targets:
            if id(item) in seen:
                continue
            seen.add(id(item))
            if item.flags() & Qt.ItemFlag.ItemIsUserCheckable and item.data(column, Qt.ItemDataRole.CheckStateRole) is not None:
                item.setCheckState(column, _check(value))

    def _publish_theme_layers(self, name: str) -> int:
        """The layers map theme ``name`` shows are published (visible at start).
        Additive: none are unpublished (several themes can be combined).
        Returns how many layers were not published before."""
        visible = set(self.project.mapThemeCollection().mapThemeVisibleLayerIds(name))
        added = 0
        for item in self._tree_items():
            if item.data(0, LAYER_ROLE) in visible:
                added += item.checkState(COL_PUBLISH) != CHECKED
                item.setCheckState(COL_PUBLISH, CHECKED)
                item.setCheckState(COL_VISIBLE, CHECKED)
        return added

    def _theme_item_changed(self, item):
        self._refresh_initial_theme()
        # A theme ticked as a view of the web map: its layers are published
        # too (a view showing unpublished layers would show nothing of them).
        if item.checkState() == CHECKED:
            added = self._publish_theme_layers(item.text())
            if added:
                self.status.setText(tr('Map theme "{}" is a view of the web map: its {} unpublished '
                                       'layers were added to the published layers.').format(item.text(), added))

    def _apply_theme(self, publish: bool):
        name = self.theme_pick.currentText()
        if not name:
            return
        if publish:
            self._publish_theme_layers(name)
        else:
            visible = set(self.project.mapThemeCollection().mapThemeVisibleLayerIds(name))
            for item in self._tree_items():
                item.setCheckState(COL_VISIBLE, _check(item.data(0, LAYER_ROLE) in visible))
        if publish:
            # ... and the theme becomes a view of the web map.
            for i in range(self.themes_list.count()):
                item = self.themes_list.item(i)
                if item.text() == name:
                    item.setCheckState(CHECKED)
            self.status.setText(tr('Layers of map theme "{}" added to the published layers, and '
                                   'the theme to the views of the web map.').format(name))
        else:
            self.status.setText(tr('Map theme "{}" applied to the layer list.').format(name))

    def publish_visible_layers(self):
        """Published layers := the layers visible in the QGIS layer tree now
        (a layer in a hidden group is hidden); they are visible at start."""
        root = self.project.layerTreeRoot()
        count = 0
        for item in self._tree_items():
            node = root.findLayer(item.data(0, LAYER_ROLE))
            shown = node is not None and node.isVisible()
            item.setCheckState(COL_PUBLISH, _check(shown))
            if shown:
                item.setCheckState(COL_VISIBLE, CHECKED)
                count += 1
        self.status.setText(tr("Published layers: the {} layers visible in QGIS.").format(count))

    def _refresh_initial_theme(self):
        current = self.theme_initial.currentData()
        self.theme_initial.blockSignals(True)
        self.theme_initial.clear()
        self.theme_initial.addItem(tr("(the layer settings above)"), "")
        for i in range(self.themes_list.count()):
            item = self.themes_list.item(i)
            if item.checkState() == CHECKED:
                self.theme_initial.addItem(item.text(), item.text())
        self.theme_initial.setCurrentIndex(max(0, self.theme_initial.findData(current or "")))
        self.theme_initial.blockSignals(False)

    def _info_tab(self):
        """The map's own data (issuer, decree, legal and data date: shown under
        the title, in the panel and on prints) and documents published with it."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        box = QGroupBox(tr("About the map"))
        form = QFormLayout(box)
        self.i_issuer = QLineEdit()
        self.i_issuer.setPlaceholderText(tr("e.g. the municipality"))
        self.i_decree = QLineEdit()
        self.i_decree.setPlaceholderText(tr("e.g. 12/2025. (X. 1.) önkormányzati rendelet"))
        self.i_legal_date = QLineEdit()
        self.i_legal_date.setPlaceholderText(tr("e.g. 2025. 10. 01."))
        self.i_legal_date.setToolTip(tr("In force from: shown under the title, separate from the export date."))
        self.i_data_date = QLineEdit()
        self.i_data_date.setPlaceholderText(tr("e.g. 2025. 09."))
        self.i_data_date.setToolTip(tr("Date of the data shown (survey, cadastre extract …)."))
        form.addRow(tr("Issued by"), self.i_issuer)
        form.addRow(tr("Decree / plan number"), self.i_decree)
        form.addRow(tr("In force from"), self.i_legal_date)
        form.addRow(tr("Data as of"), self.i_data_date)
        layout.addWidget(box)
        docs = QGroupBox(tr("Documents published with the map"))
        docs_layout = QVBoxLayout(docs)
        self.i_docs = QTableWidget(0, 2)
        self.i_docs.setHorizontalHeaderLabels([tr("Title"), tr("File")])
        self.i_docs.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.i_docs.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.i_docs.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        buttons = QHBoxLayout()
        add = QPushButton(tr("Add document…"))
        add.clicked.connect(self._add_documents)
        remove = QPushButton(tr("Remove"))
        remove.clicked.connect(lambda: [self.i_docs.removeRow(r) for r in
                                        sorted({i.row() for i in self.i_docs.selectedIndexes()}, reverse=True)])
        buttons.addWidget(add)
        buttons.addWidget(remove)
        buttons.addStretch(1)
        hint = QLabel(tr("PDF, Word/ODT, RTF, text or images. They are copied into the web map, listed in "
                         "its panel, and a popup value naming one (its file name or title) links to it. "
                         "Anyone can download them."))
        hint.setWordWrap(True)
        docs_layout.addWidget(self.i_docs)
        docs_layout.addLayout(buttons)
        docs_layout.addWidget(hint)
        layout.addWidget(docs, 1)
        return widget

    def _add_document_row(self, title: str, path: str):
        row = self.i_docs.rowCount()
        self.i_docs.insertRow(row)
        self.i_docs.setItem(row, 0, QTableWidgetItem(title))
        item = QTableWidgetItem(path)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        item.setToolTip(path)
        self.i_docs.setItem(row, 1, item)

    def _add_documents(self):
        from ..publishing.models import DOCUMENT_EXTENSIONS  # pylint: disable=import-outside-toplevel
        pattern = " ".join(f"*{ext}" for ext in DOCUMENT_EXTENSIONS)
        paths, _ = QFileDialog.getOpenFileNames(self, tr("Documents"), "", f"{tr('Documents')} ({pattern})")
        for path in paths:
            self._add_document_row(os.path.splitext(os.path.basename(path))[0], path)

    def _documents(self):
        from ..publishing.models import DocumentConfig  # pylint: disable=import-outside-toplevel
        out = []
        for row in range(self.i_docs.rowCount()):
            title = (self.i_docs.item(row, 0).text() if self.i_docs.item(row, 0) else "").strip()
            path = self.i_docs.item(row, 1).text() if self.i_docs.item(row, 1) else ""
            if path:
                out.append(DocumentConfig(title=title or os.path.splitext(os.path.basename(path))[0], path=path))
        return out

    def _choose_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, tr("Logo"), "", "Images (*.png *.jpg *.jpeg *.webp)")
        if path:
            self.e_logo.setText(path)

    def _use_canvas_extent(self, rect=None):
        try:
            extent = self._canvas_extent_3857(rect)
        except QgsCsException:  # e.g. beyond the poles on a map in degrees
            self.status.setText(tr("This area is outside what a web map can show (web maps end "
                                   "short of the poles); the extent is unchanged."))
            return
        self.profile.view.extent = extent
        self.profile.view.extent_layer = ""
        self.e_extent_layer.blockSignals(True)
        self.e_extent_layer.setLayer(None)
        self.e_extent_layer.blockSignals(False)
        self._set_extent_mode("fixed")

    def _draw_extent(self):
        """The published area drawn on the map: this window steps aside
        while two opposite corners are clicked; the status bar says which
        corner comes next."""
        from qgis.gui import QgsMessageBarItem  # pylint: disable=import-outside-toplevel
        from .extent_tool import ExtentTool  # pylint: disable=import-outside-toplevel
        canvas = self.iface.mapCanvas()
        self._back_timer.stop()  # (it would cancel this drawing)
        self._extent_tool = ExtentTool(canvas, self._extent_drawn, self._extent_hint)
        canvas.setMapTool(self._extent_tool)
        self.hide()
        canvas.setFocus()  # Esc reaches the tool before the map is clicked
        # Removed again when the drawing ends (see _extent_drawn).
        self._draw_notice = QgsMessageBarItem(
            tr("Web map"), tr("Click two opposite corners of the published area on the map. "
                              "Right click or Esc cancels."),
            Qgis.MessageLevel.Info, 8)
        self.iface.messageBar().pushItem(self._draw_notice)

    def _extent_hint(self, text):
        bar = self.iface.statusBarIface()
        if text:
            if bar.currentMessage() != text:  # (again after a QGIS status tip replaced it)
                bar.showMessage(text)
        elif self._draw_hint and bar.currentMessage() == self._draw_hint:  # only our own
            bar.clearMessage()
        self._draw_hint = text

    def _extent_drawn(self, rect):
        if self._extent_tool is None:  # given up by this window (shown again, closed)
            return
        self._extent_tool = None
        self._drop_draw_notice()
        # Not at once: the window comes back over the map, and the rest of a
        # double click on the last corner would click whatever is under the
        # mouse there (Draw… again, Publish, a checkbox).
        self._back_timer.start(QApplication.doubleClickInterval())
        if rect is not None:
            self._use_canvas_extent(rect)

    def _back_from_drawing(self):
        self.show()
        self.raise_()
        self.activateWindow()

    def _drop_draw_notice(self):
        notice, self._draw_notice = self._draw_notice, None
        if notice is not None:
            try:
                self.iface.messageBar().popWidget(notice)
            except RuntimeError:  # gone by itself already
                pass

    def _give_up_drawing(self):
        """The window shown again (Web menu) or closed (also when the plugin
        is unloaded) while the extent is being drawn: the drawing is given
        up and the previous map tool comes back; the window is not brought
        back by the drawing any more."""
        self._back_timer.stop()
        tool, self._extent_tool = self._extent_tool, None
        if tool is None:
            return
        try:
            tool.cancel()
        except RuntimeError:  # the map canvas, and the tool with it, are gone
            pass
        self._drop_draw_notice()

    def _extent_layer_changed(self, layer):
        self.profile.view.extent_layer = layer.id() if layer is not None else ""
        if layer is not None:
            self.profile.view.extent = self._layer_extent_3857(layer)
            self._set_extent_mode("layer")
        elif self.profile.view.extent_mode == "layer":  # no layer: its last extent, fixed
            self._set_extent_mode("fixed" if self.profile.view.extent else "canvas")
        else:
            self._show_extent()

    def _set_extent_mode(self, mode):
        """Shows ``mode`` in the window (without its side effects) and sets it."""
        self.e_extent_mode.blockSignals(True)
        self.e_extent_mode.setCurrentIndex(max(0, self.e_extent_mode.findData(mode)))
        self.e_extent_mode.blockSignals(False)
        self.profile.view.extent_mode = mode
        self.e_extent_layer.setEnabled(mode == "layer")
        self._show_extent()

    def _extent_mode_changed(self, _index=None):
        mode = self.e_extent_mode.currentData() or "canvas"
        if mode == "fixed" and not self.profile.view.extent and self.iface is not None:
            self._use_canvas_extent()  # nothing fixed yet: the view now, frozen
            return
        if mode == "layer" and self.e_extent_layer.currentLayer() is not None:
            self.profile.view.extent_layer = self.e_extent_layer.currentLayer().id()
            self.profile.view.extent = self._layer_extent_3857(self.e_extent_layer.currentLayer())
        self._set_extent_mode(mode)

    def _extent_mode_chosen(self, _index=None):
        """“Current map view” chosen in the list (again, by the user): the
        question before each export is back after a “Don't ask again”."""
        if self.e_extent_mode.currentData() == "canvas":
            self.profile.view.confirm_canvas_extent = True

    def _flash_extent(self):
        """The area that will be published, outlined on the QGIS map."""
        extent = self._current_extent_3857()
        if not extent or self.iface is None:
            return
        canvas = self.iface.mapCanvas()
        geometry = QgsGeometry.fromRect(QgsRectangle(*extent))
        canvas.flashGeometries([geometry], QgsCoordinateReferenceSystem("EPSG:3857"),
                               flashes=4, duration=600)

    def _layer_extent_3857(self, layer):
        """The layer's extent in Web Mercator, cut to the area a web map shows
        (the same as the Processing command's: headless.layer_extent_3857)."""
        from ..publishing.headless import layer_extent_3857  # pylint: disable=import-outside-toplevel
        return layer_extent_3857(self.project, layer) or self.profile.view.extent

    def web_zoom_scales(self) -> list:
        """The QGIS scale denominators of web zooms 0-22 for this project
        (its CRS and the published area's latitude, as the export converts)."""
        from ..core.fidelity.zoom import zoom_scales  # pylint: disable=import-outside-toplevel
        from ..publishing.zoom_load import zoom_scale_factor  # pylint: disable=import-outside-toplevel
        try:
            extent = self._current_extent_3857()
        except Exception:  # noqa: BLE001 - no map view
            extent = None
        box = QgsRectangle(*extent) if extent else QgsRectangle(0, 0, 0, 0)
        return zoom_scales(zoom_scale_factor(self.project, box))

    def use_web_zoom_scales(self, _checked=False, ask: bool = True) -> bool:
        """The project's scale list set to the web zooms' scales (asks before
        replacing a scale list of the project's own)."""
        values = self.web_zoom_scales()
        settings = self.project.viewSettings()
        own = [float(v) for v in settings.mapScales()] if settings.useProjectScales() else []
        if ask and own and sorted(own) != sorted(float(v) for v in values):
            answer = QMessageBox.question(
                self, tr("Web zoom scales"),
                tr("This project has its own scale list ({} scales). Replace it with the scales of the "
                   "web map's zoom levels?").format(len(own)),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return False
        settings.setMapScales([float(v) for v in values])
        settings.setUseProjectScales(True)
        self.project.setDirty(True)
        crs = self.project.crs()
        self.status.setText(tr("The project's scales are now those of web zooms 0–22 (1:{} … 1:{}){}.").format(
            f"{values[0]:,}".replace(",", "\u202f"), f"{values[-1]:,}".replace(",", "\u202f"),
            "" if crs.authid() in ("EPSG:3857", "EPSG:900913") else
            tr(", for the published area's latitude in this project's CRS")))
        return True

    def _extent_layer(self):
        """The layer whose extent is published, if that mode is set and the layer exists."""
        view = self.profile.view
        return self.project.mapLayer(view.extent_layer) \
            if view.extent_mode == "layer" and view.extent_layer else None

    def _extent_is_canvas(self) -> bool:
        """The current map view is published: that mode, or the layer mode
        without its layer (none chosen, or removed from the project)."""
        mode = self.profile.view.extent_mode
        return mode == "canvas" or (mode == "layer" and self._extent_layer() is None)

    def _current_extent_3857(self):
        """The extent setting now: the map canvas (current map view mode),
        the chosen layer's extent (refreshed) or the fixed extent; a mode
        without its layer or area falls back to the map canvas."""
        view = self.profile.view
        layer = self._extent_layer()
        if layer is not None:
            view.extent = self._layer_extent_3857(layer)
        elif self._extent_is_canvas() or not view.extent:
            if self.iface is None:
                return view.extent
            try:
                # Kept as the one last used (an export of another view differs).
                view.extent = self._canvas_extent_3857()
            except QgsCsException:
                return None
        return view.extent

    def _show_extent(self):
        view = self.profile.view
        layer = self.project.mapLayer(view.extent_layer) \
            if view.extent_mode == "layer" and view.extent_layer else None
        extent = self._current_extent_3857()
        if not extent:
            self.extent_label.setText(tr("The map view at the time of export.")
                                      if view.extent_mode == "canvas" else tr("Choose a layer."))
            self.extent_label.setToolTip("")
            return
        width, height, box = self._extent_size_km(extent)
        source = {"canvas": tr("Current map view"), "layer": tr("Layer extent")}.get(
            view.extent_mode if view.extent_mode != "layer" or layer is not None else "canvas",
            tr("Fixed area"))
        self.extent_label.setText(tr("{source}: about {w:.1f} × {h:.1f} km\n"
                                     "E {w0:.4f}° – {e0:.4f}°\nN {s0:.4f}° – {n0:.4f}°").format(
            source=source, w=width, h=height, w0=box.xMinimum(), e0=box.xMaximum(),
            s0=box.yMinimum(), n0=box.yMaximum()))
        tips = {"canvas": tr("What the QGIS map shows when you export; you are asked before each "
                             "export (set a layer or draw the area to publish the same area each time)."),
                "fixed": tr("Drawn on the map, or the map view frozen with “Freeze view”.")}
        self.extent_label.setToolTip(tr("Extent of “{}”").format(layer.name()) if layer is not None
                                     else tips.get(view.extent_mode, tips["canvas"]))

    def _extent_size_km(self, extent):
        """(width km, height km, EPSG:4326 box) of an EPSG:3857 extent."""
        import math  # pylint: disable=import-outside-toplevel
        transform = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:3857"),
                                           QgsCoordinateReferenceSystem("EPSG:4326"), self.project)
        box = transform.transformBoundingBox(QgsRectangle(*extent))
        # Ground size: Web Mercator units shrink by cos(latitude).
        scale = math.cos(math.radians((box.yMinimum() + box.yMaximum()) / 2))
        return (extent[2] - extent[0]) * scale / 1000, (extent[3] - extent[1]) * scale / 1000, box

    def _confirm_extent(self) -> bool:
        """Before an export of the current map view (no layer, no drawn
        area): says so, with the area's size and tile count, and lets the
        export be cancelled; "Don't ask again" is kept with the project."""
        view = self.profile.view
        if self.is_simple_view():  # the simple view shows the area's size and tiles beside it
            return True
        if not self._extent_is_canvas() or not view.confirm_canvas_extent or self.iface is None:
            return True
        extent = self._current_extent_3857()
        if not extent:
            return True
        width, height, _ = self._extent_size_km(extent)
        from ..publishing.raster_tiles import count_tiles  # pylint: disable=import-outside-toplevel
        tiles = count_tiles(extent, view.min_zoom, view.max_zoom)
        box = QMessageBox(QMessageBox.Icon.Warning, tr("Published area"), tr(
            "The published area is the current map view: about {w:.1f} × {h:.1f} km, "
            "{tiles} tiles from zoom {z0} to {z1}.").format(
                w=width, h=height, tiles=f"{tiles:,}".replace(",", "\u202f"), z0=view.min_zoom,
                z1=view.max_zoom),
            QMessageBox.StandardButton.Cancel, self)
        box.setInformativeText(tr(
            "To publish the same area every time, choose “Extent of a layer” or draw the area "
            "(Map tab, Extent). “Show on map” outlines it."))
        export = box.addButton(tr("Export this view"), QMessageBox.ButtonRole.AcceptRole)
        box.setDefaultButton(QMessageBox.StandardButton.Cancel)
        again = QCheckBox(tr("Don't ask again for this project"))
        again.setToolTip(tr("To be asked again, choose “Current map view” again in the Map tab (Extent)."))
        box.setCheckBox(again)
        self._flash_extent()
        box.exec()
        if box.clickedButton() is not export:
            return False
        if again.isChecked():
            view.confirm_canvas_extent = False
        return True

    def _fill_tree(self, profile):
        self.tree.blockSignals(True)
        self.tree.clear()
        configs = {c.layer_id: c for c in profile.layers}

        def add(group, parent, path):
            for child in group.children():
                if isinstance(child, QgsLayerTreeGroup):
                    sub = path + (child.name(),)
                    config = profile.group(sub) or GroupConfig(list(sub))
                    item = QTreeWidgetItem(parent, [child.name()])
                    item.setData(0, GROUP_ROLE, list(sub))
                    item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    item.setCheckState(COL_PUBLISH, UNCHECKED)
                    item.setCheckState(COL_VISIBLE, _check(config.initially_visible))
                    item.setCheckState(COL_TOGGLE, _check(config.toggleable))
                    font = item.font(0)
                    font.setBold(True)
                    item.setFont(0, font)
                    add(child, item, sub)
                    item.setExpanded(True)
                elif isinstance(child, QgsLayerTreeLayer):
                    layer = child.layer()
                    if not publishable(layer):
                        continue
                    config = configs.get(layer.id()) or LayerConfig(layer.id(), included=False,
                                                                     initially_visible=False)
                    raster = isinstance(layer, QgsRasterLayer)
                    item = QTreeWidgetItem(parent, [layer.name() + (tr(" (raster)") if raster else "")])
                    try:
                        item.setIcon(0, QgsIconUtils.iconForLayer(layer))
                    except (AttributeError, TypeError):
                        pass
                    item.setData(0, LAYER_ROLE, layer.id())
                    item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    item.setCheckState(COL_PUBLISH, _check(config.included))
                    item.setCheckState(COL_VISIBLE, _check(config.initially_visible))
                    item.setCheckState(COL_TOGGLE, _check(config.toggleable))
                    item.setCheckState(COL_LEGEND, _check(config.legend))
                    self._set_item_scales(item, config.min_scale, config.max_scale,
                                          config.labels_min_scale)
                    if not raster:
                        self._set_item_zoomed(item, config.zoomed_out, config.zoomed_out_below)
        add(self.project.layerTreeRoot(), self.tree.invisibleRootItem(), ())
        self._sync_group_publish(self.tree.invisibleRootItem())
        self.tree.blockSignals(False)
        self._filter_tree()

    def _filter_tree(self, *_):
        """Show the layers matching the filter text (and, with *Only
        published layers*, published) and the groups that hold them. A
        group whose name matches shows all its (published) layers. The
        rows only hide: settings of hidden rows stay as they are."""
        text = _fold(self.tree_filter.text())
        published_only = self.tree_published_only.isChecked()

        def visit(item, group_matches):
            shown = False
            for i in range(item.childCount()):
                child = item.child(i)
                if child.data(0, GROUP_ROLE):
                    matches = group_matches or (bool(text) and text in _fold(child.text(0)))
                    show = visit(child, matches)
                    if text and show:
                        child.setExpanded(True)
                elif child.data(0, LAYER_ROLE):
                    show = (not text or group_matches or text in _fold(child.text(0))) and \
                        (not published_only or child.checkState(COL_PUBLISH) == CHECKED)
                else:
                    show = True
                child.setHidden(not show)
                if not show and child.isSelected():
                    child.setSelected(False)  # bulk changes act on what is seen
                shown = shown or show
            return shown

        visit(self.tree.invisibleRootItem(), False)

    def _sync_group_publish(self, item):
        """Group "Publish" boxes show their layers: all, some or none."""
        states = []
        for i in range(item.childCount()):
            child = item.child(i)
            if child.data(0, GROUP_ROLE):
                states.append(self._sync_group_publish(child))
            elif child.data(0, LAYER_ROLE):
                states.append(child.checkState(COL_PUBLISH))
        if not item.data(0, GROUP_ROLE):
            return None
        states = [x for x in states if x is not None]
        state = CHECKED if states and all(x == CHECKED for x in states) else \
            UNCHECKED if all(x == UNCHECKED for x in states) else PARTIAL
        item.setCheckState(COL_PUBLISH, state)
        return state

    def _tree_changed(self, item, column):
        self.tree.blockSignals(True)
        try:
            if item.data(0, GROUP_ROLE) and column == COL_PUBLISH and item.checkState(column) != PARTIAL:
                for child in self._shown_descendants(item):
                    if child.data(0, LAYER_ROLE):
                        child.setCheckState(COL_PUBLISH, item.checkState(column))
                        if item.checkState(column) == UNCHECKED:
                            child.setCheckState(COL_VISIBLE, UNCHECKED)
            if item.data(0, LAYER_ROLE):
                if column == COL_VISIBLE and item.checkState(COL_VISIBLE) == CHECKED:
                    item.setCheckState(COL_PUBLISH, CHECKED)
                if column == COL_PUBLISH and item.checkState(COL_PUBLISH) == UNCHECKED:
                    item.setCheckState(COL_VISIBLE, UNCHECKED)
            # Something that cannot be switched off must be visible at start.
            if column == COL_TOGGLE and item.checkState(COL_TOGGLE) == UNCHECKED:
                item.setCheckState(COL_VISIBLE, CHECKED)
                if item.data(0, LAYER_ROLE):
                    item.setCheckState(COL_PUBLISH, CHECKED)
            if column == COL_VISIBLE and item.checkState(COL_VISIBLE) == UNCHECKED:
                item.setCheckState(COL_TOGGLE, CHECKED)
            if column == COL_LEGEND and item.data(0, LAYER_ROLE):
                self._legend_changed(item.data(0, LAYER_ROLE), item.checkState(COL_LEGEND) == CHECKED)
            self._sync_group_publish(self.tree.invisibleRootItem())
        finally:
            self.tree.blockSignals(False)

    def _legend_changed(self, layer_id, shown: bool):
        """The Map tab's Legend column and the Interaction tab's "Show in the
        legend" are one setting."""
        config = self.layer_configs.setdefault(layer_id, LayerConfig(layer_id))
        config.legend = shown
        if layer_id == self.current_layer_id:
            for box in (self.i_legend, self.r_legend):
                box.blockSignals(True)
                box.setChecked(shown)
                box.blockSignals(False)

    def _legend_box_toggled(self, shown: bool):
        for item in self._tree_items():
            if item.data(0, LAYER_ROLE) == self.current_layer_id:
                self.tree.blockSignals(True)
                item.setCheckState(COL_LEGEND, _check(shown))
                self.tree.blockSignals(False)
        if self.current_layer_id:
            self.layer_configs.setdefault(self.current_layer_id, LayerConfig(self.current_layer_id)).legend = shown

    def _tree_items(self):
        stack = [self.tree.invisibleRootItem()]
        while stack:
            item = stack.pop()
            for i in range(item.childCount()):
                child = item.child(i)
                stack.append(child)
                if child.data(0, LAYER_ROLE):
                    yield child

    def _group_items(self):
        stack = [self.tree.invisibleRootItem()]
        while stack:
            item = stack.pop()
            for i in range(item.childCount()):
                child = item.child(i)
                stack.append(child)
                if child.data(0, GROUP_ROLE):
                    yield child

    def _interaction_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        options = QGroupBox(tr("Viewer"))
        viewer = QVBoxLayout(options)
        self.i_flags = {}
        for key, label in ([
                ("map_only", tr("Map only: nothing on screen but the map")),
                ("labels_toggle", tr("Labels switch")), ("opacity_controls", tr("Opacity sliders")),
                ("search", tr("Search")), ("filters", tr("Attribute filters")),
                ("popups", tr("Popups")), ("permalinks", tr("Shareable links")),
                ("coordinates", tr("Coordinates (WGS 84 and the project CRS)")), ("measure", tr("Measurement")),
                ("print", tr("Print")),
                ("legend_visible_only", tr("Legend: only what is visible in the current view")),
                ("layers_panel", tr("Layers tab (off: the legend only)")),
                ("panel_closed", tr("Map panel closed at start")),
                ("geolocation", tr("My location button")),
                ("street_search", tr("Search street names (OpenStreetMap)")),
                ("overview_map", tr("Overview map (inset)")), ("three_d", tr("3D view")),
                ("drawing", tr("Drawing tools")), ("zoom_to_layer", tr("Zoom-to-layer buttons")),
                ("street_view", tr("Street View (Google)"))]):
            self.i_flags[key] = QCheckBox(label)
        self.i_google_key = QLineEdit()
        self.i_google_key.setPlaceholderText(tr("Google Maps API key (needed for Street View)"))
        self.i_google_key.setEnabled(False)
        self.i_flags["street_view"].toggled.connect(self.i_google_key.setEnabled)
        self.i_flags["search"].setToolTip(tr(
            "The found feature is zoomed to and marked, and its popup opened when Popups is on."))
        # As many columns as the window's width allows (the key after the last one).
        self.i_flags_box = flow_container(list(self.i_flags.values()), wide=self.i_google_key)
        viewer.addWidget(self.i_flags_box)
        street_view_help = tr(
            "A Street View button on the map: tap a place to see it, the panorama looks toward the "
            "tapped point. Blue lines on the map show where Street View exists. Needs a Google "
            "Cloud API key with the Maps JavaScript API and the Map Tiles API (the blue lines) "
            "enabled. The key is visible in the published page: restrict it in Google Cloud to "
            "your site's address (HTTP referrers) and to these two APIs.")
        self.i_flags["street_view"].setToolTip(street_view_help)
        self.i_google_key.setToolTip(street_view_help)
        self.i_flags["map_only"].setToolTip(tr(
            "The published page shows only the map: no title, panel, legend, buttons, scale bar, "
            "popups or search; visitors can still pan and zoom. The attribution of the map and its "
            "basemap stays in a corner when there is one (their licences require it). The other "
            "viewer options have no effect then."))
        self.i_flags["map_only"].toggled.connect(self._map_only_toggled)
        self.i_flags["panel_closed"].setToolTip(tr(
            "The web map opens with its panel (layers, legend, tools) closed, so more of the map "
            "is on screen; the menu button opens it."))
        self.i_flags["geolocation"].setToolTip(tr(
            "A button on the map that shows the visitor's location (the browser asks for "
            "permission; needs https). Outside the map's extent it only says so and does not move "
            "the map."))
        self.i_flags["overview_map"].setToolTip(tr("A small overview map in a corner with the current view marked."))
        self.i_flags["zoom_to_layer"].setToolTip(tr(
            "A button in each layer's row of the Layers tab that zooms the map to the layer's extent."))
        self.i_flags["three_d"].setToolTip(tr(
            "A 3D button on the map: tilted view with the terrain relief (Basemap tab) and the polygons "
            "of layers with a 3D height field raised."))
        self.i_flags["drawing"].setToolTip(tr(
            "Drawing tools in the Tools tab: points, lines, areas and text, kept in the shared link "
            "and saved as GeoJSON or KML."))
        self.i_flags["street_search"].setToolTip(tr(
            "The search also finds the named streets of OpenStreetMap inside the extent layer "
            "(Map tab; without one, inside the export extent). They are read from the basemap, or "
            "without a basemap from the Protomaps build (internet needed while exporting). Only the "
            "names, a point and the bounds of each street are published."))
        # House numbers in the search: "Fő utca 12".
        address_row = QHBoxLayout()
        self.i_address_layer = self._layer_combo(None, allow_empty=True, empty_text=tr("(none)"))
        # No field until one is chosen (the first field, often "fid", is no house number).
        self.i_address_number = self._field_combo(self.i_address_layer, allow_empty=True)
        self.i_address_layer.layerChanged.connect(self._guess_address_number)
        self.i_address_street = self._field_combo(self.i_address_layer, allow_empty=True)
        self.i_address_street.setToolTip(tr("Empty: the nearest named OpenStreetMap street (within 150 m)."))
        for label, combo in ((tr("House numbers"), self.i_address_layer), (tr("number"), self.i_address_number),
                             (tr("street (empty: nearest OSM street)"), self.i_address_street)):
            address_row.addWidget(QLabel(label))
            address_row.addWidget(combo, 1)
        self.i_address_layer.setToolTip(tr(
            "A point (or building) layer with house numbers: the search finds \"street number\" "
            "(e.g. Fő utca 12) and zooms there. Only the street, the number and a point are published."))
        viewer.addLayout(address_row)
        layout.addWidget(options)
        split = QSplitter()
        split.setChildrenCollapsible(False)
        self.i_layers = QListWidget()
        # Room for layer names: wrapped, never squeezed by the field table.
        self.i_layers.setMinimumWidth(220)
        self.i_layers.setWordWrap(True)
        self.i_layers.setSpacing(2)
        self.i_layers.currentItemChanged.connect(self._interaction_layer_changed)
        self.i_layers_filter = QLineEdit()
        self.i_layers_filter.setClearButtonEnabled(True)
        self.i_layers_filter.setPlaceholderText(tr("Find a layer…"))
        self.i_layers_filter.setToolTip(tr("Shows the layers whose name contains this text (upper or "
                                           "lower case, accents not needed)"))
        self.i_layers_filter.textChanged.connect(self._filter_interaction_layers)
        layer_list = QWidget()
        layer_list_layout = QVBoxLayout(layer_list)
        layer_list_layout.setContentsMargins(0, 0, 0, 0)
        layer_list_layout.addWidget(self.i_layers_filter)
        layer_list_layout.addWidget(self.i_layers, 1)
        split.addWidget(layer_list)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        form = QFormLayout()
        self.i_title = QLineEdit()
        self.i_display = QLineEdit()
        self.i_display.setPlaceholderText(tr('QGIS expression, e.g. "hrsz" (default: first search field)'))
        self.i_opacity = QDoubleSpinBox()
        self.i_opacity.setRange(0, 1)
        self.i_opacity.setSingleStep(0.1)
        self.i_legend = QCheckBox(tr("Show in the legend"))
        self.i_links = QCheckBox(tr("Feature links (deep links)"))
        self.i_label_always = QCheckBox(tr("Label every feature (smaller where the label does not fit)"))
        self.i_label_always.setToolTip(tr(
            "Web map: every feature of this layer gets its label (e.g. every parcel number). A label "
            "that does not fit its polygon is drawn smaller (down to half size), at worst at the "
            "roomiest point of the polygon; it is never left out."))
        self.i_snap = QCheckBox(tr("Measurements snap to this layer (corners and edges)"))
        self.i_snap.setToolTip(tr(
            "Web map: while measuring, points snap to the nearest corner of this layer's "
            "features, else to their nearest edge or line (as drawn on the map)."))
        form.addRow(tr("Title in the viewer"), self.i_title)
        form.addRow(tr("Feature title (display expression)"), self.i_display)
        form.addRow(tr("Initial opacity"), self.i_opacity)
        form.addRow("", self.i_legend)
        self.i_legend.toggled.connect(self._legend_box_toggled)
        form.addRow("", self.i_links)
        form.addRow("", self.i_label_always)
        form.addRow("", self.i_snap)
        self.i_height = QComboBox()
        self.i_height.setToolTip(tr("Polygon layers (e.g. buildings): a numeric field of heights in metres. "
                                    "With \"3D view\" on (Interaction tab) the map's 3D button raises the "
                                    "polygons to it. The field becomes public."))
        form.addRow(tr("3D height field (m)"), self.i_height)
        right_layout.addLayout(form)
        self.i_fields = QTableWidget(0, 7)
        self.i_fields.setHorizontalHeaderLabels([tr("Field"), tr("Popup"), tr("Popup title"), tr("Type"),
                                                 tr("Search"), tr("Feature key"), tr("Filter")])
        self.i_fields.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.i_fields.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        fields_note = QLabel(tr("Only checked fields become public (popup, search, filter). "
                                "The feature key should be unique and never empty, e.g. a "
                                "parcel number; without one, feature links only work in the "
                                "same version of the map."))
        fields_note.setWordWrap(True)  # unwrapped, it made the tab ~2000 px wide (list squeezed)
        right_layout.addWidget(fields_note)
        right_layout.addWidget(self.i_fields, 1)
        self.i_stack = QStackedWidget()
        self.i_stack.addWidget(right)
        self.i_stack.addWidget(self._raster_page())
        split.addWidget(self.i_stack)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 3)
        split.setSizes([300, 660])  # else the field table's width squeezes the list
        self.i_split = split
        layout.addWidget(split, 1)
        return widget

    def _raster_page(self):
        page = QWidget()
        form = QFormLayout(page)
        self.r_title = QLineEdit()
        self.r_format = QComboBox()
        self.r_format.addItem(tr("WebP (small, transparent; the default)"), "webp")
        self.r_format.addItem(tr("PNG (sharp, transparent; larger)"), "png")
        self.r_format.addItem(tr("JPEG (photos; no transparency)"), "jpeg")
        self.r_min = QSpinBox()
        self.r_min.setRange(-1, 22)
        self.r_min.setSpecialValueText(tr("as the map"))
        self.r_min.valueChanged.connect(self._raster_estimate)
        # Sharpest detail, as the size of a pixel on the ground: "image" (as
        # sharp as the image), "map" (the publication's maximum tile zoom) or
        # a zoom level. Zooming in further only enlarges these images.
        self.r_detail = QComboBox()
        self.r_detail.setToolTip(tr("How much detail the web map can show: the size of one image pixel "
                                    "on the ground when zoomed in fully. Each finer step means about 4× "
                                    "more images and a larger export."))
        self.r_detail.currentIndexChanged.connect(lambda *_: self._raster_estimate())
        self._raster_choice = "map"
        self.r_quality = QSpinBox()
        self.r_quality.setRange(1, 100)
        self.r_opacity = QDoubleSpinBox()
        self.r_opacity.setRange(0, 1)
        self.r_opacity.setSingleStep(0.1)
        self.r_live = QCheckBox(tr("Load live from its server (web tiles / WMS)"))
        self.r_live.setToolTip(tr(
            "An XYZ tile or WMS layer: the visitors' browsers load its images from its own server "
            "while browsing (always up to date, nothing to render or upload), and a click on a WMS "
            "layer shows what the server knows about that place (GetFeatureInfo). Needs an https "
            "address without login and a server that allows other sites to use its images (CORS); "
            "otherwise, or when unticked, QGIS renders the layer into the release."))
        self.r_live.toggled.connect(self._raster_live_toggled)
        self.r_legend = QCheckBox(tr("Show in the legend"))
        self.r_legend.toggled.connect(self._legend_box_toggled)
        self.r_estimate = QLabel()
        self.r_estimate.setWordWrap(True)
        form.addRow(tr("Title in the viewer"), self.r_title)
        form.addRow("", self.r_live)
        form.addRow(tr("Image format"), self.r_format)
        form.addRow(tr("Sharpest detail"), self.r_detail)
        form.addRow(tr("Shown from zoom"), self.r_min)
        form.addRow(tr("Quality (JPEG/WebP)"), self.r_quality)
        form.addRow(tr("Initial opacity"), self.r_opacity)
        form.addRow("", self.r_legend)
        form.addRow("", self.r_estimate)
        form.addRow("", _note(tr("Raster layers are drawn by QGIS exactly as on the canvas into their own "
                                  "image tile archive (data/raster-….pmtiles). Vector layers always stay "
                                  "vector tiles. Zoomed in beyond the sharpest detail, the images are "
                                  "enlarged.")))
        return page

    def _raster_live_toggled(self, live: bool) -> None:
        """The rendering settings do not apply to a layer loaded live."""
        for widget in (self.r_format, self.r_detail, self.r_min, self.r_quality, self.r_estimate):
            widget.setEnabled(not (live and self.r_live.isEnabled()))

    def _raster_detail(self):
        """(raster_max_zoom, raster_match_native) of the "Sharpest detail" choice."""
        choice = self.r_detail.currentData() if self.r_detail.count() else self._raster_choice
        if choice == "image":
            return None, True
        if choice == "map" or choice is None:
            return None, False
        return int(choice), False

    def _fill_raster_detail(self, plan):
        """The "Sharpest detail" choices for this layer: like the image (when
        its resolution is known), like the map, or a pixel size per zoom."""
        from ..publishing.raster_tiles import ground_resolution, sharp_zoom  # pylint: disable=import-outside-toplevel
        lat = plan.latitude
        best = sharp_zoom(plan.native_m, lat, online=plan.online) if plan.native_m else None
        choice = self.r_detail.currentData() if self.r_detail.count() else self._raster_choice
        self.r_detail.blockSignals(True)
        self.r_detail.clear()
        if best is not None:
            like = (tr("Like the service's sharpest tiles: {} per pixel (recommended)") if plan.online
                    else tr("Like the image: {} per pixel (recommended)"))
            self.r_detail.addItem(like.format(_metres(plan.native_m)), "image")
        finer = (tr(" – finer than the service, no more detail") if plan.online
                 else tr(" – finer than the image, no more detail"))
        map_zoom = self.e_max_zoom.value()
        self.r_detail.addItem(tr("Like the map: {} per pixel").format(
            _metres(ground_resolution(map_zoom, lat))) + (finer if best is not None and map_zoom > best
                                                          else ""), "map")
        # Pixel sizes from "Like the image" (one step finer than the image:
        # beyond it only the export grows) down to the zoom the layer is shown from.
        top = 21 if best is None else best
        low = self.r_min.value() if self.r_min.value() >= 0 else self.e_min_zoom.value()
        zooms = set(range(max(low, 8), top + 1))
        if isinstance(choice, int):
            zooms.add(choice)  # a saved choice outside the range stays
        for zoom in sorted(zooms, reverse=True):
            if zoom in (best, map_zoom) and zoom != choice:
                continue  # the two entries above (a saved fixed zoom keeps its own: it stays fixed)
            label = tr("{} per pixel").format(_metres(ground_resolution(zoom, lat)))
            if zoom in (best, map_zoom):  # same size as an entry above: say which one is fixed
                label = tr("{} (fixed, zoom {})").format(label, zoom)
            self.r_detail.addItem(label + (finer if best is not None and zoom > best else ""), zoom)
        index = self.r_detail.findData(choice)
        self.r_detail.setCurrentIndex(index if index >= 0 else self.r_detail.findData("map"))
        self.r_detail.blockSignals(False)

    def _raster_estimate(self):
        if not self.current_layer_id or self.i_stack.currentIndex() != 1:
            return
        from ..publishing.raster_tiles import LARGE_TILES_PER_LAYER, plan_layer  # pylint: disable=import-outside-toplevel
        layer = self.project.mapLayer(self.current_layer_id)
        high, match = self._raster_detail()
        config = LayerConfig(self.current_layer_id,
                             raster_min_zoom=self.r_min.value() if self.r_min.value() >= 0 else None,
                             raster_max_zoom=high, raster_match_native=match)
        profile = PublicationProfile()
        profile.view.min_zoom, profile.view.max_zoom = self.e_min_zoom.value(), self.e_max_zoom.value()
        try:
            plan = plan_layer(self.project, layer, config, profile, self._extent())
        except Exception:  # noqa: BLE001 - no extent yet
            self.r_estimate.setText("")
            return
        self._fill_raster_detail(plan)
        self.r_estimate.setText(raster_resolution_text(plan) + "\n" + tr(
            "At most {} tiles at zooms {}–{} in the export extent.").format(
            plan.tiles, plan.min_zoom, plan.max_zoom) + ("\n⚠ " + "; ".join(plan.warnings) if plan.warnings else "")
            + ("\n⚠ " + tr("Very many tiles: the export will take hours. A coarser “Sharpest detail” "
                            "or a smaller extent makes it much faster.")
               if plan.tiles > LARGE_TILES_PER_LAYER else ""))

    def _basemap_tab(self):
        from qgis.PyQt.QtWidgets import QScrollArea  # pylint: disable=import-outside-toplevel
        page = QWidget()
        outer = QVBoxLayout(page)
        bundled = QGroupBox(tr("OpenStreetMap vector basemap (copied into the release)"))
        form = QFormLayout(bundled)
        outer.addWidget(bundled)
        self.b_kind = QComboBox()
        self.b_kind.addItem(tr("No basemap (only the project's layers)"), "none")
        self.b_kind.addItem(tr("OpenStreetMap vector basemap (Protomaps)"), "protomaps")
        self.b_latest = QRadioButton(tr("Download the area from the latest Protomaps daily build (internet "
                                        "needed while exporting)"))
        self.b_custom = QRadioButton(tr("Use this PMTiles file or URL (Protomaps schema):"))
        source_row = QHBoxLayout()
        self.b_source = QLineEdit()
        self.b_source.setPlaceholderText("https://…/planet.pmtiles  |  C:/maps/hungary.pmtiles")
        browse = QPushButton("…")
        browse.clicked.connect(self._choose_basemap_file)
        self.b_browse = browse
        source_row.addWidget(self.b_source, 1)
        source_row.addWidget(browse)
        self.b_flavors = {}
        flavors_row = QHBoxLayout()
        titles = {"light": tr("Light"), "dark": tr("Dark"), "white": tr("White"), "grayscale": tr("Grayscale"),
                  "black": tr("Black")}
        for flavor in BASEMAP_FLAVORS:
            box = QCheckBox(titles[flavor])
            box.toggled.connect(self._refresh_basemap_initial)
            self.b_flavors[flavor] = box
            flavors_row.addWidget(box)
        flavors_row.addStretch(1)
        self.b_initial = QComboBox()
        self.b_max = QSpinBox()
        self.b_max.setRange(0, 15)
        self.b_padding = QSpinBox()
        self.b_padding.setRange(0, 1000)
        self.b_padding.setSuffix(" %")
        self.b_overview_zoom = QSpinBox()
        self.b_overview_zoom.setRange(0, 15)
        self.b_overview_km = QSpinBox()
        self.b_overview_km.setRange(0, 5000)
        self.b_overview_km.setSuffix(" km")
        form.addRow(tr("Basemap"), self.b_kind)
        self.b_kind.currentIndexChanged.connect(self._basemap_kind_changed)
        form.addRow("", self.b_latest)
        form.addRow("", self.b_custom)
        form.addRow("", source_row)
        form.addRow(tr("Styles offered"), flavors_row)
        form.addRow(tr("Most detailed zoom"), self.b_max)
        form.addRow(tr("Area around the extent"), self.b_padding)
        form.addRow(tr("Overview zooms (0 to)"), self.b_overview_zoom)
        form.addRow(tr("Overview area"), self.b_overview_km)
        form.addRow("", _note(tr(
            "The basemap is vector tiles like the map: only the tiles of your area are copied into the "
            "release (data/basemap.pmtiles) with fonts generated for its labels, so visitors never load "
            "anything from another site. Visitors can switch styles or turn it off. Map data © "
            "OpenStreetMap contributors (ODbL), shown automatically in the attribution.")))
        # Web basemaps: QGIS's own XYZ connections (Browser -> XYZ Tiles),
        # each with "Use in web map"; loaded by the visitor's browser.
        web = QGroupBox(tr("Web basemaps (XYZ tiles or WMS, loaded from their server while browsing)"))
        web_layout = QVBoxLayout(web)
        self.b_xyz = QTableWidget(0, 6)
        self.b_xyz.setHorizontalHeaderLabels([tr("Use"), tr("Name"), tr("Tile address (XYZ or WMS)"),
                                              tr("Attribution"), tr("Min z"), tr("Max z")])
        self.b_xyz.horizontalHeaderItem(0).setToolTip(tr("Offered in the web map's basemap menu"))
        self.b_xyz.horizontalHeaderItem(1).setToolTip(tr("The name of the QGIS XYZ connection"))
        header = self.b_xyz.horizontalHeader()
        header.setSectionResizeMode(0, header.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, header.ResizeMode.Stretch)
        for column, width in ((1, 190), (3, 170), (4, 55), (5, 55)):
            self.b_xyz.setColumnWidth(column, width)
        self.b_xyz.setMinimumHeight(170)
        self.b_xyz.setWordWrap(False)
        self.b_xyz.itemChanged.connect(self._refresh_basemap_initial)
        buttons = QHBoxLayout()
        add = QPushButton(tr("Add new…"))
        add.setToolTip(tr("A new XYZ connection: saved in QGIS too (Browser → XYZ Tiles)."))
        add.clicked.connect(lambda: self._add_xyz_row(XyzBasemap(max_zoom=19), used=True, editable_name=True))
        reload_button = QPushButton(tr("Reload from QGIS"))
        reload_button.setToolTip(tr("List the XYZ connections saved in QGIS again (added meanwhile in the Browser)."))
        reload_button.clicked.connect(lambda: self._fill_xyz_table(self._xyz_rows()))
        wms_button = QPushButton(tr("Add WMS…"))
        wms_button.setToolTip(tr("A WMS service (e.g. official orthophotos) as a web basemap: from a WMS layer "
                                 "of the project or by its address and layer names."))
        wms_button.clicked.connect(self._add_wms)
        for button in (add, wms_button, reload_button):
            buttons.addWidget(button)
        buttons.addStretch(1)
        web_layout.addWidget(self.b_xyz)
        web_layout.addLayout(buttons)
        web_layout.addWidget(_note(tr(
            "The list is QGIS's own XYZ tile connections (Browser → XYZ Tiles): tick the ones the web map "
            "offers. New ones and edited attributions are saved there too. Addresses use {z}, {x}, {y} "
            "({-y}: TMS rows, {s}: a/b/c servers) and must be https://. Visitors choose them in the map's "
            "basemap menu; their browser loads the tiles from that server while browsing (nothing is copied "
            "into the release, and the page allows exactly these servers). Use only addresses you are "
            "allowed to use, with the attribution the service requires. The ticked ones are also kept in "
            "the project and in the exported settings file.")))
        outer.addWidget(web)
        # Terrain: a DEM raster layer (heights in metres) for the 3D view,
        # the hillshade and elevation profiles.
        relief = QGroupBox(tr("Terrain (3D relief, hillshade, elevation profiles)"))
        relief_form = QFormLayout(relief)
        from qgis.gui import QgsMapLayerComboBox  # pylint: disable=import-outside-toplevel
        from qgis.core import QgsMapLayerProxyModel  # pylint: disable=import-outside-toplevel
        self.t_layer = QgsMapLayerComboBox()
        try:
            self.t_layer.setFilters(QgsMapLayerProxyModel.Filter.RasterLayer)
        except AttributeError:
            self.t_layer.setFilters(Qgis.LayerFilter.RasterLayer)
        try:
            self.t_layer.setAllowEmptyLayer(True, tr("(no terrain)"))
        except TypeError:
            self.t_layer.setAllowEmptyLayer(True)
        self.t_layer.setProject(self.project)
        # Heights are read from a file (GDAL): online services are not offered.
        self.t_layer.setExcludedProviders(["wms", "wcs", "arcgismapserver", "arcgisfeatureserver",
                                           "virtualraster", "postgresraster"])
        searchable(self.t_layer)
        self.t_layer.setToolTip(tr("A raster layer of ground heights in metres (DEM, DTM), read from its file."))
        self.t_hillshade = QCheckBox(tr("Hillshade: shaded relief drawn above the basemap (also in 2D)"))
        self.t_exaggeration = QDoubleSpinBox()
        self.t_exaggeration.setRange(1.0, 5.0)
        self.t_exaggeration.setSingleStep(0.5)
        self.t_exaggeration.setSuffix(" ×")
        self.t_layer.layerChanged.connect(self._terrain_chosen)
        self._terrain_chosen(self.t_layer.currentLayer())
        relief_form.addRow(tr("Elevation layer (DEM)"), self.t_layer)
        relief_form.addRow("", self.t_hillshade)
        relief_form.addRow(tr("Height exaggeration in 3D"), self.t_exaggeration)
        relief_form.addRow("", _note(tr(
            "The heights are resampled to web tiles (data/terrain.pmtiles) for the area of the map. "
            "Visitors get an elevation profile for measured lines and, with \"3D view\" switched on "
            "(Interaction tab), a 3D button (tilted view with relief; with a 3D height field also "
            "raised buildings). The heights become public.")))
        outer.addWidget(relief)
        start = QFormLayout()
        start.addRow(tr("Basemap shown at start"), self.b_initial)
        outer.insertLayout(0, start)
        outer.addStretch(1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(page)
        return scroll

    def _project_wms_layers(self):
        """(name, service URL, layers, format) of the project's WMS layers."""
        from qgis.core import QgsDataSourceUri  # pylint: disable=import-outside-toplevel
        out = []
        for layer in self.project.mapLayers().values():
            if not isinstance(layer, QgsRasterLayer) or (layer.providerType() or "").lower() != "wms":
                continue
            uri = QgsDataSourceUri()
            uri.setEncodedUri(layer.source())
            # XYZ and WMTS (tile matrix sets) layers use the same provider; not GetMap services.
            if uri.param("type") in ("xyz", "wmts") or uri.param("tileMatrixSet") or not uri.param("url"):
                continue
            out.append((layer.name(), uri.param("url"), ",".join(uri.params("layers")),
                        uri.param("format") or "image/png"))
        return sorted(out, key=lambda item: item[0].lower())

    def _add_wms(self):
        """A WMS service as a web basemap (one GetMap image per 256 px tile)."""
        from qgis.PyQt.QtWidgets import QDialogButtonBox  # pylint: disable=import-outside-toplevel
        from ..publishing.xyz import wms_template  # pylint: disable=import-outside-toplevel
        dialog = QDialog(self)
        dialog.setWindowTitle(tr("Add WMS"))
        form = QFormLayout(dialog)
        project_layers = self._project_wms_layers()
        source = QComboBox()
        source.addItem(tr("(type the address below)"), None)
        for item in project_layers:
            source.addItem(item[0], item)
        searchable(source)
        title, url, layers, attribution = QLineEdit(), QLineEdit(), QLineEdit(), QLineEdit()
        url.setPlaceholderText("https://…/wms")
        layers.setPlaceholderText(tr("layer names, comma separated"))
        image_format = QComboBox()
        for value in ("image/png", "image/jpeg"):
            image_format.addItem(value, value)

        def from_project(index):
            item = source.itemData(index)
            if item:
                title.setText(item[0])
                url.setText(item[1])
                layers.setText(item[2])
                image_format.setCurrentIndex(max(0, image_format.findData(item[3])))
        source.currentIndexChanged.connect(from_project)
        if project_layers:
            form.addRow(tr("WMS layer of the project"), source)
        form.addRow(tr("Name"), title)
        form.addRow(tr("Service address"), url)
        form.addRow(tr("Layers"), layers)
        form.addRow(tr("Image format"), image_format)
        form.addRow(tr("Attribution"), attribution)
        form.addRow("", _note(tr("The service must be https:// and allow use in web maps (Web Mercator, "
                                 "EPSG:3857). Visitors' browsers request one image per map tile from it.")))
        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        box.accepted.connect(dialog.accept)
        box.rejected.connect(dialog.reject)
        form.addRow(box)
        dialog.resize(560, dialog.sizeHint().height())
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return None
        if not url.text().strip().lower().startswith("https://") or not layers.text().strip():
            QMessageBox.warning(self, tr("Add WMS"), tr("An https:// service address and at least one layer name are needed."))
            return None
        entry = XyzBasemap(title=title.text().strip() or layers.text().strip(),
                           url=wms_template(url.text(), layers.text().strip(), image_format.currentData()),
                           attribution=attribution.text().strip(), min_zoom=0, max_zoom=20)
        self._add_xyz_row(entry, used=True, editable_name=True)
        self._refresh_basemap_initial()
        return entry

    def _add_xyz_row(self, entry, used=True, editable_name=True):
        """One web basemap row; the name of an existing QGIS connection is fixed
        (editing it would make another connection)."""
        self.b_xyz.blockSignals(True)
        row = self.b_xyz.rowCount()
        self.b_xyz.insertRow(row)
        use = QTableWidgetItem()
        https = str(entry.url).startswith("https://") or not entry.url
        flags = Qt.ItemFlag.ItemIsUserCheckable | (Qt.ItemFlag.ItemIsEnabled if https else Qt.ItemFlag.NoItemFlags)
        use.setFlags(flags)
        use.setCheckState(_check(used and https))
        if not https:
            use.setToolTip(tr("Web pages can only load https:// tiles."))
        self.b_xyz.setItem(row, 0, use)
        for column, value in enumerate((entry.title, entry.url, entry.attribution,
                                        str(entry.min_zoom), str(entry.max_zoom)), start=1):
            item = QTableWidgetItem(value)
            if column == 1 and not editable_name:
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.b_xyz.setItem(row, column, item)
        self.b_xyz.blockSignals(False)
        self._refresh_basemap_initial()

    def _fill_xyz_table(self, used):
        """The web map's basemaps (ticked, in their order), then every other
        XYZ connection saved in QGIS (not ticked)."""
        try:
            from .xyz_connections import qgis_xyz_connections  # pylint: disable=import-outside-toplevel
            saved = qgis_xyz_connections()
        except Exception:  # noqa: BLE001 - settings are a convenience
            saved = []
        in_qgis = {entry.title for entry in saved}
        self.b_xyz.setRowCount(0)
        for entry in used:
            self._add_xyz_row(entry, used=True,
                              editable_name=entry.title.strip().replace("/", "-") not in in_qgis)
        # QGIS keeps "/" in a connection's name as "-" (xyz_connections).
        titles = {entry.title.strip().replace("/", "-") for entry in used}
        for entry in saved:
            if entry.title not in titles:
                self._add_xyz_row(entry, used=False, editable_name=False)

    def _xyz_rows(self, used_only=True):
        """The ticked web basemaps (or every row), in table order."""
        out = []
        for row in range(self.b_xyz.rowCount()):
            cell = lambda column: (self.b_xyz.item(row, column).text().strip()  # noqa: E731
                                   if self.b_xyz.item(row, column) else "")
            ticked = self.b_xyz.item(row, 0) is not None and self.b_xyz.item(row, 0).checkState() == CHECKED
            if not cell(2) or (used_only and not ticked):
                continue
            try:
                low, high = int(cell(4) or 0), int(cell(5) or 19)
            except ValueError:
                low, high = 0, 19
            out.append(XyzBasemap(title=cell(1) or f"XYZ {row + 1}", url=cell(2), attribution=cell(3),
                                  min_zoom=low, max_zoom=high))
        return out

    # ------------------------------------------------------------------ parcel report
    def _layer_combo(self, geometry=None, allow_empty=False, any_layer=False, empty_text=None):
        from qgis.gui import QgsMapLayerComboBox  # pylint: disable=import-outside-toplevel
        from qgis.core import QgsMapLayerProxyModel  # pylint: disable=import-outside-toplevel
        combo = QgsMapLayerComboBox()
        flags = "All" if any_layer else {"polygon": "PolygonLayer", "line": "LineLayer",
                                         None: "VectorLayer"}[geometry]
        try:
            combo.setFilters(getattr(QgsMapLayerProxyModel.Filter, flags))
        except AttributeError:
            combo.setFilters(getattr(Qgis.LayerFilter, flags))
        if empty_text is not None:
            try:
                combo.setAllowEmptyLayer(allow_empty, empty_text)
            except TypeError:  # QGIS < 3.20: no text for the empty entry
                combo.setAllowEmptyLayer(allow_empty)
        else:
            combo.setAllowEmptyLayer(allow_empty)
        combo.setProject(self.project)
        return searchable(combo)

    def _guess_address_number(self, layer):
        """A field named like a house number, else none (the user picks it)."""
        names = {f.name().lower(): f.name() for f in layer.fields()} if layer is not None else {}
        for name in ("hsz", "hazszam", "házszám", "haz_szam", "housenumber", "house_number",
                     "addr:housenumber", "number", "szam"):
            if name in names:
                self.i_address_number.setField(names[name])
                return
        self.i_address_number.setField("")

    @staticmethod
    def _field_combo(layer_combo, allow_empty=False):
        from qgis.gui import QgsFieldComboBox  # pylint: disable=import-outside-toplevel
        combo = QgsFieldComboBox()
        combo.setAllowEmptyFieldName(allow_empty)
        combo.setLayer(layer_combo.currentLayer())
        layer_combo.layerChanged.connect(combo.setLayer)
        return combo

    @staticmethod
    def _fields_table():
        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels([tr("Field (tick to show)"), tr("Title")])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().setVisible(False)
        table.setMinimumHeight(110)
        return table


    # Layer combo boxes follow the project's layers and fire when it is
    # cleared, also for a closed window; bound methods (not closures over
    # self) let a closed window be freed with its combo boxes.
    def _map_only_toggled(self, on: bool) -> None:
        """Map only: the other viewer options are kept but have no effect."""
        for key, box in self.i_flags.items():
            if key != "map_only":
                box.setEnabled(not on)
        if not on and "street_view" in self.i_flags:
            self.i_google_key.setEnabled(self.i_flags["street_view"].isChecked())
        else:
            self.i_google_key.setEnabled(False)

    def _terrain_chosen(self, layer):
        self.t_hillshade.setEnabled(layer is not None)
        self.t_exaggeration.setEnabled(layer is not None)

    def _parcel_layer_changed(self, layer):
        self._fill_fields_table(self.p_fields, layer, [])

    def _zoning_layer_changed(self, layer):
        self._fill_fields_table(self.p_zone_fields, layer, [])

    def _regulation_layer_changed(self, layer):
        self._fill_fields_table(self.p_regulation_fields, layer, [])

    @staticmethod
    def _fill_fields_table(table, layer, chosen):
        chosen = {p.field: p for p in chosen}
        names = [f.name() for f in layer.fields()] if layer is not None else []
        table.setRowCount(len(names))
        for row, name in enumerate(names):
            item = QTableWidgetItem(name)
            item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(_check(name in chosen))
            if name in chosen:  # its type (url, number …) is kept: the table has no type column
                item.setData(Qt.ItemDataRole.UserRole, chosen[name].type)
            table.setItem(row, 0, item)
            table.setItem(row, 1, QTableWidgetItem(chosen[name].alias if name in chosen else ""))

    @staticmethod
    def _read_fields_table(table):
        out = []
        for row in range(table.rowCount()):
            if table.item(row, 0).checkState() == CHECKED:
                title = table.item(row, 1).text().strip() if table.item(row, 1) else ""
                kind = table.item(row, 0).data(Qt.ItemDataRole.UserRole) or "string"
                out.append(PopupField(table.item(row, 0).text(), title, kind))
        return out

    @staticmethod
    def _scrolled(widget):
        """``widget`` in a scroll area (no frame): shown whole where there is
        room, scrolled on a small screen instead of making the window larger."""
        from qgis.PyQt.QtWidgets import QFrame, QScrollArea  # pylint: disable=import-outside-toplevel
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(widget)
        return scroll

    def _parcel_tab(self):
        from qgis.PyQt.QtWidgets import QScrollArea  # pylint: disable=import-outside-toplevel
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        widget = QWidget()
        scroll.setWidget(widget)
        layout = QVBoxLayout(widget)
        self.p_enabled = QCheckBox(tr("Clicking a parcel shows its report: area, parts cut by the zoning "
                                      "and the regulation lines, zones and restrictions"))
        layout.addWidget(self.p_enabled)
        top = QHBoxLayout()
        parcel_box = QGroupBox(tr("Parcels"))
        form = QFormLayout(parcel_box)
        self.p_layer = self._layer_combo("polygon")
        self.p_key = self._field_combo(self.p_layer)
        self.p_fields = self._fields_table()
        self.p_layer.layerChanged.connect(self._parcel_layer_changed)
        form.addRow(tr("Parcel layer"), self.p_layer)
        form.addRow(tr("Parcel id (unique, e.g. hrsz)"), self.p_key)
        form.addRow(tr("Parcel data shown"), self.p_fields)
        top.addWidget(parcel_box, 1)
        zoning_box = QGroupBox(tr("Zoning (parts of the parcel)"))
        form = QFormLayout(zoning_box)
        self.p_zoning = self._layer_combo("polygon")
        self.p_code = self._field_combo(self.p_zoning)
        self.p_zone_fields = self._fields_table()
        self.p_zoning.layerChanged.connect(self._zoning_layer_changed)
        self.p_zoning.layerChanged.connect(self._guess_zone_code)
        self.p_cuts = QListWidget()
        self.p_cuts.setMaximumHeight(90)
        form.addRow(tr("Zone layer (its style gives the zone colours)"), self.p_zoning)
        form.addRow(tr("Zone code field"), self.p_code)
        form.addRow(tr("Zone values shown per part"), self.p_zone_fields)
        form.addRow(tr("Lines that cut parcels"), self.p_cuts)
        top.addWidget(zoning_box, 1)
        layout.addLayout(top)
        restrictions_box = QGroupBox(tr("Restrictions (shown with their legend symbol when they touch the parcel)"))
        rlayout = QVBoxLayout(restrictions_box)
        self.p_restrictions = QTableWidget(0, 6)
        self.p_restrictions.setHorizontalHeaderLabels([tr("Layer"), tr("Title"), tr("Name field"),
                                                       tr("Distance (m)"), tr("Explanation"), tr("Legal reference")])
        header = self.p_restrictions.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        for column in (1, 4, 5):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Stretch)
        self.p_restrictions.verticalHeader().setVisible(False)
        self.p_restrictions.setMinimumHeight(220)
        rlayout.addWidget(self.p_restrictions)
        rlayout.addWidget(_note(tr("Tick the layers that restrict building. Lines and points need a "
                                   "distance (protection zone); polygons count where they overlap. Only "
                                   "the title, explanation, reference and the chosen name field become "
                                   "public.")))
        layout.addWidget(restrictions_box)
        bottom = QHBoxLayout()
        regulation_box = QGroupBox(tr("Zone regulations table (optional, e.g. the local building code)"))
        form = QFormLayout(regulation_box)
        self.p_regulation = self._layer_combo(None, allow_empty=True)
        self.p_regulation_code = self._field_combo(self.p_regulation, allow_empty=True)
        self.p_regulation_fields = self._fields_table()
        self.p_regulation.layerChanged.connect(self._regulation_layer_changed)
        self.p_regulation.layerChanged.connect(self._guess_regulation_code)
        form.addRow(tr("Table"), self.p_regulation)
        form.addRow(tr("Zone code field"), self.p_regulation_code)
        form.addRow(tr("Fields shown"), self.p_regulation_fields)
        # The full regulation texts (one simple-HTML text per zone).
        self.p_text = self._layer_combo(None, allow_empty=True)
        self.p_text_code = self._field_combo(self.p_text, allow_empty=True)
        self.p_text_field = self._field_combo(self.p_text, allow_empty=True)
        self.p_text.layerChanged.connect(self._guess_text_fields)
        self.p_text.setToolTip(tr(
            "Optional table: a zone code field and a text field with every regulation that applies in the "
            "zone, as simple HTML (headings, paragraphs, lists, tables; anything else is removed). The "
            "parcel report shows it under each zone, opened on request. The texts become public."))
        form.addRow(tr("Full texts table"), self.p_text)
        form.addRow(tr("Its zone code field"), self.p_text_code)
        form.addRow(tr("Its text field (HTML)"), self.p_text_field)
        bottom.addWidget(regulation_box, 1)
        other_box = QGroupBox(tr("Accuracy and notice"))
        form = QFormLayout(other_box)
        self.p_min_area = QDoubleSpinBox()
        self.p_min_area.setRange(0, 1000)
        self.p_min_area.setSuffix(" m²")
        self.p_min_share = QDoubleSpinBox()
        self.p_min_share.setRange(0, 50)
        self.p_min_share.setSuffix(" %")
        self.p_disclaimer = QPlainTextEdit()
        self.p_disclaimer.setMaximumHeight(70)
        self.p_disclaimer.setPlaceholderText(tr("Empty: the viewer's standard notice ('Information only, not an "
                                                "official certificate…') in the viewer's language"))
        form.addRow(tr("Ignore parts smaller than"), self.p_min_area)
        form.addRow(tr("Ignore restriction overlaps below"), self.p_min_share)
        form.addRow(tr("Notice shown on every report"), self.p_disclaimer)
        bottom.addWidget(other_box, 1)
        layout.addLayout(bottom)
        return scroll

    def _guess_zone_code(self, layer):
        """Zone code field: the field QGIS styles / labels the zone layer by
        (e.g. szab_ov), unless one is chosen already - never a feature id
        (the report showed fid numbers instead of the zone codes)."""
        from ..publishing.parcel_report import guess_zone_field, looks_like_id  # pylint: disable=import-outside-toplevel
        if layer is None or not looks_like_id(layer, self.p_code.currentField()):
            return
        guessed = guess_zone_field(layer)
        if guessed:
            self.p_code.setField(guessed)

    def _guess_regulation_code(self, layer):
        """A regulations table chosen: pick its zone code field — the one named
        like the zone layer's code field (e.g. szab_ov), else a usual code name."""
        if layer is None or self.p_regulation_code.currentField():
            return
        names = {field.name().lower(): field.name() for field in layer.fields()}
        for wanted in (self.p_code.currentField(), "szab_ov", "ovezet", "övezet", "kod", "kód",
                       "code", "zone", "zone_code"):
            if wanted and wanted.lower() in names:
                self.p_regulation_code.setField(names[wanted.lower()])
                return

    def _guess_text_fields(self, layer):
        """A texts table chosen: its zone code field (as the regulations table)
        and its longest-named text field like html / szoveg / eloiras."""
        if layer is None:
            return
        names = {field.name().lower(): field.name() for field in layer.fields()}
        if not self.p_text_code.currentField():
            for wanted in (self.p_code.currentField(), "szab_ov", "ovezet", "kod", "code", "zone"):
                if wanted and wanted.lower() in names:
                    self.p_text_code.setField(names[wanted.lower()])
                    break
        if not self.p_text_field.currentField():
            for name in sorted(names, key=len, reverse=True):
                if any(word in name for word in ("html", "szoveg", "szöveg", "eloiras", "előírás", "text")):
                    self.p_text_field.setField(names[name])
                    break

    def _fill_parcel_tab(self, profile):
        info = profile.parcel_info
        project_layer = self.project.mapLayer
        self.p_enabled.setChecked(info.enabled)
        for combo, layer_id in ((self.p_layer, info.parcel_layer_id), (self.p_zoning, info.zoning_layer_id),
                                (self.p_regulation, info.regulation_layer_id), (self.p_text, info.text_layer_id)):
            if layer_id and project_layer(layer_id) is not None:
                combo.setLayer(project_layer(layer_id))
            elif combo in (self.p_regulation, self.p_text):
                combo.setLayer(None)
            elif info.enabled:  # these two have no empty choice: say so, not a silent other layer
                self.log(tr("Parcel report: a layer of these settings is not in this project; "
                            "check the Parcel report tab."))
        # Fields as in these settings (empty ones too: not the previous settings' choice).
        self.p_text_code.setField(info.text_code_field or "")
        self.p_text_field.setField(info.text_field or "")
        self._fill_fields_table(self.p_fields, self.p_layer.currentLayer(), info.fields)
        self._fill_fields_table(self.p_zone_fields, self.p_zoning.currentLayer(), info.zoning_fields)
        self._fill_fields_table(self.p_regulation_fields, self.p_regulation.currentLayer(), info.regulation_fields)
        self.p_key.setField(info.key_field or "")
        self.p_code.setField(info.zoning_code_field or "")
        self._guess_zone_code(self.p_zoning.currentLayer())  # an id field saved before: the real code
        self.p_regulation_code.setField(info.regulation_code_field or "")
        cuts = {c.layer_id: c for c in info.cut_lines}
        restrictions = {r.layer_id: r for r in info.restrictions}
        self.p_cuts.clear()
        self.p_restrictions.setRowCount(0)
        for node in self.project.layerTreeRoot().findLayers():
            layer = node.layer()
            if not isinstance(layer, QgsVectorLayer) or not layer.isSpatial():
                continue
            if layer.geometryType() == 1 or getattr(layer.geometryType(), "value", None) == 1:
                item = QListWidgetItem(layer.name())
                item.setData(LAYER_ROLE, layer.id())
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(_check(layer.id() in cuts))
                self.p_cuts.addItem(item)
            config = restrictions.get(layer.id())
            row = self.p_restrictions.rowCount()
            self.p_restrictions.insertRow(row)
            name = QTableWidgetItem(layer.name())
            name.setData(LAYER_ROLE, layer.id())
            name.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            name.setCheckState(_check(config is not None))
            self.p_restrictions.setItem(row, 0, name)
            self.p_restrictions.setItem(row, 1, QTableWidgetItem(config.title if config else layer.name()))
            fields = QComboBox()
            fields.addItem("", "")
            for field in layer.fields():
                fields.addItem(field.name(), field.name())
            fields.setCurrentIndex(max(0, fields.findData(config.name_field if config else "")))
            self.p_restrictions.setCellWidget(row, 2, fields)
            distance = QDoubleSpinBox()
            distance.setRange(0, 1000)
            distance.setValue(config.buffer_m if config else 0)
            self.p_restrictions.setCellWidget(row, 3, distance)
            self.p_restrictions.setItem(row, 4, QTableWidgetItem(config.note if config else ""))
            self.p_restrictions.setItem(row, 5, QTableWidgetItem(config.reference if config else ""))
        self.p_min_area.setValue(info.min_area)
        self.p_min_share.setValue(info.min_share)
        self.p_disclaimer.setPlainText(info.disclaimer)

    def _collect_parcel_tab(self, profile):
        info = profile.parcel_info
        info.enabled = self.p_enabled.isChecked()
        info.parcel_layer_id = self.p_layer.currentLayer().id() if self.p_layer.currentLayer() else ""
        info.key_field = self.p_key.currentField()
        info.fields = self._read_fields_table(self.p_fields)
        info.zoning_layer_id = self.p_zoning.currentLayer().id() if self.p_zoning.currentLayer() else ""
        info.zoning_code_field = self.p_code.currentField()
        info.zoning_fields = self._read_fields_table(self.p_zone_fields)
        regulation = self.p_regulation.currentLayer()
        info.regulation_layer_id = regulation.id() if regulation else ""
        info.regulation_code_field = self.p_regulation_code.currentField() if regulation else ""
        info.regulation_fields = self._read_fields_table(self.p_regulation_fields) if regulation else []
        texts = self.p_text.currentLayer()
        info.text_layer_id = texts.id() if texts else ""
        info.text_code_field = self.p_text_code.currentField() if texts else ""
        info.text_field = self.p_text_field.currentField() if texts else ""
        info.cut_lines = [CutLineConfig(self.p_cuts.item(i).data(LAYER_ROLE), self.p_cuts.item(i).text())
                          for i in range(self.p_cuts.count()) if self.p_cuts.item(i).checkState() == CHECKED]
        restrictions = []
        for row in range(self.p_restrictions.rowCount()):
            item = self.p_restrictions.item(row, 0)
            if item.checkState() != CHECKED:
                continue
            restrictions.append(RestrictionConfig(
                layer_id=item.data(LAYER_ROLE), title=self.p_restrictions.item(row, 1).text().strip(),
                name_field=self.p_restrictions.cellWidget(row, 2).currentData() or "",
                buffer_m=float(self.p_restrictions.cellWidget(row, 3).value()),
                note=self.p_restrictions.item(row, 4).text().strip(),
                reference=self.p_restrictions.item(row, 5).text().strip()))
        info.restrictions = restrictions
        info.min_area = float(self.p_min_area.value())
        info.min_share = float(self.p_min_share.value())
        info.disclaimer = self.p_disclaimer.toPlainText().strip()

    def _choose_basemap_file(self):
        path, _ = QFileDialog.getOpenFileName(self, tr("Basemap"), "", "PMTiles (*.pmtiles)")
        if path:
            self.b_source.setText(path)
            self.b_custom.setChecked(True)

    def _basemap_kind_changed(self, *_):
        """No basemap: its source, styles, zooms and area have no effect."""
        on = self.b_kind.currentData() == "protomaps"
        for widget in (self.b_latest, self.b_custom, self.b_source, self.b_browse, self.b_max, self.b_padding,
                       self.b_overview_zoom, self.b_overview_km, *self.b_flavors.values()):
            widget.setEnabled(on)
        self._refresh_basemap_initial()

    def _refresh_basemap_initial(self, *_):
        current, current_text = self.b_initial.currentData(), self.b_initial.currentText()
        self.b_initial.blockSignals(True)
        self.b_initial.clear()
        self.b_initial.addItem(tr("None (switched off)"), "none")
        for flavor, box in self.b_flavors.items():
            if box.isChecked() and self.b_kind.currentData() == "protomaps":
                self.b_initial.addItem(box.text(), flavor)
        for number, entry in enumerate(self._xyz_rows() if hasattr(self, "b_xyz") else [], start=1):
            self.b_initial.addItem(f"{tr('Web')}: {entry.title}", f"xyz-{number}")
        # The same basemap by its name: web basemaps are numbered by position,
        # which changes when a row above is added or unticked.
        index = self.b_initial.findText(current_text) if current_text else -1
        if index < 0:
            index = self.b_initial.findData(current) if current else -1
        self.b_initial.setCurrentIndex(index if index >= 0 else min(1, self.b_initial.count() - 1))
        self.b_initial.blockSignals(False)

    def _output_tab(self):
        widget = QWidget()
        form = QFormLayout(widget)
        self.o_archive = QComboBox()
        self.o_archive.addItem(tr("PMTiles (vector tiles for static web hosting)"), "pmtiles")
        self.o_archive.addItem(tr("PMTiles + MBTiles copy"), "both")
        self.o_archive.addItem(tr("MBTiles only (desktop / preview; not for direct web hosting)"), "mbtiles")
        dir_row = QHBoxLayout()
        self.o_dir = QLineEdit()
        dir_button = QPushButton("…")
        dir_button.clicked.connect(self._choose_dir)
        dir_row.addWidget(self.o_dir)
        dir_row.addWidget(dir_button)
        self.o_xyz = QCheckBox(tr("Also write the legacy XYZ web package (web/)"))
        self.o_zip = QCheckBox(tr("Also write an offline ZIP of the release"))
        self.o_cpu = QSpinBox()
        self.o_cpu.setRange(1, 100)
        self.o_fidelity = QComboBox()
        self.o_fidelity.addItem(tr("Vector-first: approximate where declared and report"), 0)
        self.o_fidelity.addItem(tr("Strict: fail if any component is unsupported or approximated"), 1)
        self.o_overzoom = QComboBox()
        self.o_overzoom.addItem(tr("Keep showing the last tiles beyond the maximum zoom"), 0)
        self.o_overzoom.addItem(tr("Hide layers beyond the maximum zoom"), 1)
        self.o_labels = QComboBox()
        self.o_labels.addItem(tr("Whole polygon"), 0)
        self.o_labels.addItem(tr("Visible polygon"), 1)
        self.o_labels.addItem(tr("As set in each layer's labels"), 2)
        self.o_all_fields = QCheckBox(tr("Publish ALL attribute fields in the tiles (not recommended)"))
        self.o_thin_hairlines = QCheckBox(tr("Thin hairlines: draw zero-width lines thinner than QGIS"))
        self.o_thin_hairlines.setToolTip(tr(
            "QGIS draws a line or outline of width 0 (a hairline, e.g. parcel boundaries) one screen "
            "pixel wide: two pixels on a high-resolution screen, and where many run close together the "
            "map looks filled in. With this option the web map draws them thinner (one device pixel on a "
            "high-resolution screen, a lighter line on others), a little wider when zoomed far in, so "
            "they stay visible at every zoom. Dashed hairlines keep their width. Layers drawn as images "
            "zoomed out are rendered at twice the resolution, so their hairlines match. Off: as in QGIS."))
        self.o_low_memory = QCheckBox(tr("Low memory web map: keep fewer tiles in the browser"))
        self.o_low_memory.setToolTip(tr(
            "The browser keeps the map tiles of about one zoom level besides those on screen (otherwise "
            "five): much less memory with detailed maps (a city's parcels), at the cost of loading tiles "
            "again when you return to a place (usually from the browser's cache). On screens above "
            "200 % scale (phones) the map is drawn at 2 device pixels per CSS pixel."))
        self.o_light_tiles = QCheckBox(tr("Lighter tiles when zoomed out: leave out features under half a pixel"))
        self.o_light_tiles.setToolTip(tr(
            "Fills and thin lines smaller than half a pixel at a zoom level are left out of that zoom's "
            "tiles, and the outlines in the tiles of the zoom levels below each layer's last are "
            "simplified a little more (a quarter pixel). Detailed layers (parcels shown when zoomed out) "
            "then need less memory and download in the browser. The last zoom level of each layer keeps "
            "every feature and its exact shape. Off: every feature at every zoom, as QGIS draws them."))
        self.o_fast_markers = QCheckBox(tr("Fast marker lines: let the browser place screen-size line markers"))
        self.o_fast_markers.setToolTip(tr(
            "Marker lines whose spacing is set in screen units (points, millimetres, pixels) keep that "
            "spacing on screen at every zoom, so their markers are normally computed for every zoom level: "
            "most of a big export. With this option the browser places them along the lines instead: a "
            "much faster export, but the markers are not at QGIS's positions (spacing within about 0.7-1.4x, "
            "markers may be missing at tile edges). Off: exact positions."))
        small_row = QHBoxLayout()
        self.o_small_labels = QCheckBox(tr("Hide labels smaller than"))
        self.o_small_labels.setToolTip(tr(
            "Labels whose text size is set in map units (metres) shrink as the map zooms out. Hide them "
            "where their text is smaller than this on screen, too small to read (a data-defined size: "
            "each label by its own size). Labels sized in points, millimetres or pixels are not affected. "
            "\"Label every feature\" shrinks such a label to fit no smaller than this either. QGIS's own pixel "
            "size-based visibility of a label (Rendering tab) is always honoured."))
        self.o_small_label_px = QDoubleSpinBox()
        self.o_small_label_px.setRange(1.0, 48.0)
        self.o_small_label_px.setDecimals(1)
        self.o_small_label_px.setValue(6.0)
        self.o_small_label_px.setSuffix(" px")
        self.o_small_labels.toggled.connect(self.o_small_label_px.setEnabled)
        small_row.addWidget(self.o_small_labels)
        small_row.addWidget(self.o_small_label_px)
        small_row.addWidget(QLabel(tr("(text sized in map units)")))
        small_row.addStretch(1)
        cache_row = QHBoxLayout()
        self.o_reuse = QCheckBox(tr("Reuse unchanged layers from earlier exports (faster)"))
        self.o_reuse.setToolTip(tr("Layers whose data files, style and export settings did not change "
                                   "since an earlier export in this output folder are not processed "
                                   "again. Database, web and memory layers are always exported."))
        clear_cache = QPushButton(tr("Clear cache…"))
        clear_cache.clicked.connect(self.clear_cache)
        cache_row.addWidget(self.o_reuse, 1)
        cache_row.addWidget(clear_cache)
        form.addRow(tr("Archive"), self.o_archive)
        form.addRow(tr("Local output folder"), dir_row)
        self.o_versions = QCheckBox(tr("Keep earlier versions in the local folder (releases, rollback)"))
        self.o_versions.setToolTip(tr("Off: each export replaces the map in <folder>/<name>/ (one site, "
                                      "ready to copy to any web server). On: each export is kept as a "
                                      "version in releases/ and the folder's index.html opens the "
                                      "current one, with rollback. Only for the local destination."))
        form.addRow("", self.o_versions)
        form.addRow("", self.o_xyz)
        form.addRow("", self.o_zip)
        form.addRow(tr("CPU limit (%)"), self.o_cpu)
        form.addRow(tr("Fidelity"), self.o_fidelity)
        form.addRow(tr("Beyond the maximum zoom"), self.o_overzoom)
        form.addRow(tr("Polygon labels"), self.o_labels)
        form.addRow("", self.o_all_fields)
        form.addRow("", self.o_fast_markers)
        form.addRow("", self.o_thin_hairlines)
        form.addRow("", self.o_low_memory)
        form.addRow("", self.o_light_tiles)
        form.addRow("", small_row)
        form.addRow("", cache_row)
        form.addRow("", _note(tr("Vector layers are always published as vector tiles (MVT) in a "
                                  "PMTiles archive, never as images. Only QGIS raster layers become image "
                                  "tiles, each in its own archive. Sprites, patterns, legend swatches and "
                                  "fonts are styling assets.")))
        return widget

    def clear_cache(self):
        """Delete the export cache of the local output folder."""
        from ..core.export_cache import ExportCache  # pylint: disable=import-outside-toplevel
        from ..publishing.controller import cache_dir  # pylint: disable=import-outside-toplevel
        try:
            cache = ExportCache(cache_dir(self.collect()))
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return
        size = cache.size()
        if not size:
            QMessageBox.information(self, tr("Cache"), tr("The cache of this output folder is empty."))
            return
        answer = QMessageBox.question(
            self, tr("Cache"), tr("Delete the export cache ({:.0f} MB)? The next export processes "
                                  "every layer again.").format(size / 1024 / 1024))
        if answer == QMessageBox.StandardButton.Yes:
            cache.clear()
            self.status.setText(tr("Export cache deleted."))

    def _choose_dir(self):
        path = QFileDialog.getExistingDirectory(self, tr("Local output folder"), self.o_dir.text())
        if path:
            self.o_dir.setText(path)

    def _destination_tab(self):
        from .r2_guide import FIELD_HELP  # pylint: disable=import-outside-toplevel
        widget = QWidget()
        form = QFormLayout(widget)
        self.d_form = form
        self.d_kind = QComboBox()
        self.d_kind.addItem(tr("Local only (no upload)"), "local")
        self.d_kind.addItem(tr("Cloudflare R2"), "r2")
        self.d_kind.addItem(tr("Other S3-compatible storage"), "s3")
        self.d_kind.addItem(tr("SSH / SFTP server (one folder, not versioned)"), "ssh")
        self._dest_family, self._dest_other = None, {}  # see _destination_kind_changed
        self.d_account = QLineEdit()
        self.d_account.setPlaceholderText(tr("32 characters – or paste the S3 API URL / dashboard address"))
        self.d_endpoint = QLineEdit()
        self.d_endpoint.setPlaceholderText(tr("R2: leave empty (derived from the account id)"))
        self.d_bucket = QLineEdit()
        self.d_bucket.setPlaceholderText("maps")
        self.d_prefix = QLineEdit()
        self.d_prefix.setPlaceholderText("maps/<slug>")
        self.d_public = QLineEdit()
        self.d_public.setPlaceholderText("https://maps.example.com")
        for field, key in ((self.d_account, "account"), (self.d_endpoint, "endpoint"),
                           (self.d_bucket, "bucket"), (self.d_prefix, "prefix"), (self.d_public, "public")):
            field.setToolTip(tr(FIELD_HELP[key]))
        # SSH / SFTP server: the site goes straight into one folder (no versions).
        self.d_ssh_host = QLineEdit()
        self.d_ssh_host.setPlaceholderText(tr("server name or address – or paste user@server:/folder"))
        self.d_ssh_host.setToolTip(tr("The SSH server, e.g. www.example.com. Pasting user@server:/folder or "
                                      "sftp://user@server:port/folder fills the user, port and folder too."))
        self.d_ssh_host.editingFinished.connect(self._parse_ssh_target)
        self.d_ssh_port = QSpinBox()
        self.d_ssh_port.setRange(1, 65535)
        self.d_ssh_port.setValue(22)
        self.d_ssh_user = QLineEdit()
        self.d_ssh_user.setPlaceholderText(tr("login name"))
        self.d_ssh_user.setToolTip(tr("The SSH login. Empty: the user of the saved password below, "
                                      "else your ssh settings' default."))
        self.d_ssh_dir = QLineEdit()
        self.d_ssh_dir.setPlaceholderText(tr("e.g. /var/www/html/map, or public_html/map in your home folder"))
        self.d_ssh_dir.setToolTip(tr("The map's files go straight into this folder (created if missing) "
                                     "and replace the previous map there; no versions are kept. Absolute, "
                                     "or relative to the login's home folder. A file with the same name as "
                                     "one of the map's (e.g. index.html) is replaced; only files QWebMap "
                                     "uploaded before are ever deleted, your other files stay."))
        self.d_ssh_key = QLineEdit()
        self.d_ssh_key.setPlaceholderText(tr("optional – empty: ssh-agent or your default keys (~/.ssh)"))
        self.d_ssh_key.setToolTip(tr("A private key file (OpenSSH format) on this computer. A key with a "
                                     "passphrase: enter the passphrase as the password below."))
        self.d_ssh_key_row = QWidget()
        key_row = QHBoxLayout(self.d_ssh_key_row)
        key_row.setContentsMargins(0, 0, 0, 0)
        key_browse = QPushButton(tr("Browse…"))
        key_browse.clicked.connect(self._choose_ssh_key)
        key_row.addWidget(self.d_ssh_key, 1)
        key_row.addWidget(key_browse)
        self.d_ssh_password = QLineEdit()
        self.d_ssh_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.d_ssh_password.setPlaceholderText(tr("Password or key passphrase"))
        self.d_ssh_password.setToolTip(tr("Used only while this window is open (not saved anywhere). Empty "
                                          "with a key that needs no passphrase, or with ssh-agent."))
        self.d_ssh_password_row = QWidget()
        password_row = QHBoxLayout(self.d_ssh_password_row)
        password_row.setContentsMargins(0, 0, 0, 0)
        save_password = QPushButton(tr("Save in QGIS…"))
        save_password.setToolTip(tr("Store the user and this password encrypted in QGIS and select "
                                    "them above"))
        save_password.clicked.connect(self.save_ssh_password)
        password_row.addWidget(self.d_ssh_password, 1)
        password_row.addWidget(save_password)
        # Pasted Cloudflare addresses: take the account id (and bucket) from them.
        self.d_account.editingFinished.connect(lambda: self._parse_pasted(self.d_account))
        self.d_endpoint.editingFinished.connect(lambda: self._parse_pasted(self.d_endpoint))
        self.d_bucket.editingFinished.connect(lambda: self._parse_pasted(self.d_bucket))
        self.d_address = QLabel()
        self.d_address.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        for field in (self.d_public, self.d_prefix, getattr(self, "e_slug", None)):
            if field is not None:
                field.textChanged.connect(self._update_address)
        self.d_retention = QSpinBox()
        self.d_retention.setRange(1, 100)
        self.d_conditional = QCheckBox(tr("Storage supports conditional writes (R2, AWS S3)"))
        auth_row = QHBoxLayout()
        try:
            from qgis.gui import QgsAuthConfigSelect  # pylint: disable=import-outside-toplevel
            self.d_auth = QgsAuthConfigSelect(widget)
        except ImportError:
            self.d_auth = None
        if self.d_auth is not None:
            auth_row.addWidget(self.d_auth)
            self.d_auth.setToolTip(tr(FIELD_HELP["auth"]))
        help_row = QHBoxLayout()
        guide = QPushButton(tr("Step-by-step: set up Cloudflare R2…"))
        guide.setToolTip(tr("Where to find each value in the Cloudflare dashboard"))
        guide.clicked.connect(self.show_r2_guide)
        self.d_guide = guide
        help_row.addWidget(guide)
        help_row.addStretch(1)
        self.d_help_row = form.rowCount()
        form.addRow("", help_row)
        form.addRow(tr("Destination"), self.d_kind)
        self.d_rows = {}
        form.addRow(tr("Cloudflare account id"), self.d_account)
        self.d_rows["account"] = self.d_account
        form.addRow(tr("S3 API endpoint"), self.d_endpoint)
        self.d_rows["endpoint"] = self.d_endpoint
        form.addRow(tr("Bucket"), self.d_bucket)
        form.addRow(tr("Prefix in the bucket"), self.d_prefix)
        form.addRow(tr("SSH server"), self.d_ssh_host)
        form.addRow(tr("Port"), self.d_ssh_port)
        form.addRow(tr("User"), self.d_ssh_user)
        form.addRow(tr("Folder on the server"), self.d_ssh_dir)
        form.addRow(tr("Private key file"), self.d_ssh_key_row)
        form.addRow(tr("Public base URL (custom domain)"), self.d_public)
        form.addRow(tr("Map address"), self.d_address)
        form.addRow(tr("Saved credentials (QGIS authentication: user = access key id, "
                       "password = secret)"), auth_row)
        self.d_auth_label = form.labelForField(auth_row)
        self.d_session_row = QWidget()
        session = QHBoxLayout(self.d_session_row)
        session.setContentsMargins(0, 0, 0, 0)
        self.d_session_key = QLineEdit()
        self.d_session_key.setPlaceholderText(tr("Access Key ID"))
        self.d_session_key.setToolTip(tr(FIELD_HELP["session"]))
        self.d_session_secret = QLineEdit()
        self.d_session_secret.setEchoMode(QLineEdit.EchoMode.Password)
        self.d_session_secret.setPlaceholderText(tr("Secret Access Key"))
        self.d_session_secret.setToolTip(tr(FIELD_HELP["session"]))
        save_keys = QPushButton(tr("Save keys in QGIS…"))
        save_keys.setToolTip(tr("Store these keys encrypted in QGIS and select them above"))
        save_keys.clicked.connect(self.save_keys)
        session.addWidget(self.d_session_key)
        session.addWidget(self.d_session_secret)
        session.addWidget(save_keys)
        form.addRow(tr("Or keys for this session only"), self.d_session_row)
        form.addRow(tr("Or a password for this session only"), self.d_ssh_password_row)
        self.d_retention.setToolTip(tr(
            "How many releases Releases and rollback… → Delete old releases… keeps. Nothing is deleted "
            "automatically: until you delete them, every release stays in the storage (and is billed)."))
        form.addRow(tr("Releases to keep"), self.d_retention)
        form.addRow("", self.d_conditional)
        self.d_kind.currentIndexChanged.connect(self._destination_kind_changed)
        buttons = QHBoxLayout()
        test = QPushButton(tr("Test connection"))
        test.clicked.connect(self.test_connection)
        cors = QPushButton(tr("Show CORS policy"))
        cors.clicked.connect(self.show_cors)
        history = QPushButton(tr("Releases and rollback…"))
        history.clicked.connect(self.show_history)
        self.d_cors, self.d_history, self.d_test = cors, history, test
        buttons.addWidget(test)
        buttons.addWidget(cors)
        buttons.addWidget(history)
        buttons.addStretch(1)
        form.addRow("", buttons)
        self.d_note = _note("")
        form.addRow("", self.d_note)
        return widget

    def _review_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        self.review = QTextBrowser()
        self.review.setOpenLinks(False)
        layout.addWidget(self.review)
        row = QHBoxLayout()
        refresh = QPushButton(tr("Refresh review"))
        refresh.clicked.connect(self.refresh_review)
        self.approve = QCheckBox(tr("I understand that the geometry of the selected layers and the "
                                    "fields listed above become public at the target address."))
        row.addWidget(refresh)
        row.addWidget(self.approve, 1)
        layout.addLayout(row)
        return widget

    # ------------------------------------------------------------------ populate / collect
    def _populate(self, profile: PublicationProfile):
        self.e_title.setText(profile.title)
        self.e_slug.setText(profile.slug)
        self._slug_title = profile.title
        self.e_description.setPlainText(profile.description)
        self.e_locale.setCurrentIndex(max(0, self.e_locale.findData(profile.locale)))
        self.e_attribution.setText(profile.attribution)
        self.e_logo.setText(profile.logo_path)
        self.t_layer.setLayer(self.project.mapLayer(profile.terrain.layer_id))
        self.t_hillshade.setChecked(profile.terrain.hillshade)
        self.t_exaggeration.setValue(profile.terrain.exaggeration)
        info = profile.info
        self.i_issuer.setText(info.issuer)
        self.i_decree.setText(info.decree)
        self.i_legal_date.setText(info.legal_date)
        self.i_data_date.setText(info.data_date)
        self.i_docs.setRowCount(0)
        for document in info.documents:
            self._add_document_row(document.title, document.path)
        self.e_min_zoom.setValue(profile.view.min_zoom)
        self.e_max_zoom.setValue(profile.view.max_zoom)
        self.e_max_view.setValue(profile.view.max_view_zoom)
        self.e_limit_extent.setChecked(profile.view.limit_to_extent)
        self.e_extent_layer.blockSignals(True)
        self.e_extent_layer.setLayer(self.project.mapLayer(profile.view.extent_layer)
                                     if profile.view.extent_layer else None)
        self.e_extent_layer.blockSignals(False)
        if profile.view.extent_layer and self.e_extent_layer.currentLayer() is None:
            profile.view.extent_layer = ""  # the layer is gone: keep its last extent, fixed
            if profile.view.extent_mode == "layer":
                profile.view.extent_mode = "fixed" if profile.view.extent else "canvas"
        self._set_extent_mode(profile.view.extent_mode)
        self._fill_tree(profile)  # extent label refreshed by _use_canvas_extent
        if hasattr(self.e_accent, "setColor"):
            from qgis.PyQt.QtGui import QColor  # pylint: disable=import-outside-toplevel
            self.e_accent.setColor(QColor(profile.accent_color))
        else:
            self.e_accent.setText(profile.accent_color)
        themes = self.project.mapThemeCollection().mapThemes()
        self.theme_pick.clear()
        self.theme_pick.addItems(themes)
        self.themes_list.blockSignals(True)
        self.themes_list.clear()
        for name in themes:
            item = QListWidgetItem(name)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(_check(name in profile.themes.names))
            self.themes_list.addItem(item)
        self.themes_list.blockSignals(False)
        self._refresh_initial_theme()
        self.theme_initial.setCurrentIndex(max(0, self.theme_initial.findData(profile.themes.initial)))
        self._fill_parcel_tab(profile)
        basemap = profile.basemap
        self.b_kind.setCurrentIndex(max(0, self.b_kind.findData(basemap.kind)))
        (self.b_custom if basemap.source else self.b_latest).setChecked(True)
        self.b_source.setText(basemap.source)
        for flavor, box in self.b_flavors.items():
            box.setChecked(flavor in basemap.flavors)
        self._fill_xyz_table(basemap.xyz)
        self._basemap_kind_changed()  # (also lists the start basemaps)
        self.b_initial.setCurrentIndex(max(0, self.b_initial.findData(basemap.initial)))
        self.b_max.setValue(basemap.max_zoom)
        self.b_padding.setValue(int(round(basemap.padding * 100)))
        self.b_overview_zoom.setValue(basemap.overview_zoom)
        self.b_overview_km.setValue(int(basemap.overview_km))
        for key, box in self.i_flags.items():
            box.setChecked(bool(getattr(profile.interaction, key)))
        self.i_google_key.setText(profile.interaction.google_api_key)
        address_layer = self.project.mapLayer(profile.interaction.address_layer_id)
        self.i_address_layer.setLayer(address_layer)
        self.i_address_number.setLayer(address_layer)
        self.i_address_street.setLayer(address_layer)
        self.i_address_number.setField(profile.interaction.address_number_field)
        self.i_address_street.setField(profile.interaction.address_street_field)
        self.i_google_key.setEnabled(profile.interaction.street_view and not profile.interaction.map_only)
        # The Interaction tab shows the new settings: the widgets still hold
        # the previous layer's values, which must not be stored into them.
        self.current_layer_id = None
        self.layer_configs = {c.layer_id: c for c in profile.layers}
        if self.tabs.tabText(self.tabs.currentIndex()) == tr("Interaction"):
            self._fill_interaction_layers()
        else:
            self.i_layers.blockSignals(True)
            self.i_layers.clear()
            self.i_layers.blockSignals(False)
        self.o_archive.setCurrentIndex(max(0, self.o_archive.findData(profile.output.archive)))
        self.o_dir.setText(profile.output.local_directory)
        self.o_xyz.setChecked(profile.output.xyz_package)
        self.o_zip.setChecked(profile.output.zip)
        self.o_cpu.setValue(max(1, profile.output.cpu_percent))
        self.o_fidelity.setCurrentIndex(max(0, self.o_fidelity.findData(profile.output.fidelity_mode)))
        self.o_overzoom.setCurrentIndex(max(0, self.o_overzoom.findData(profile.output.overzoom)))
        self.o_labels.setCurrentIndex(max(0, self.o_labels.findData(profile.output.polygon_labels_base)))
        self.o_all_fields.setChecked(profile.output.include_all_fields)
        self.o_fast_markers.setChecked(profile.output.fast_markers)
        self.o_thin_hairlines.setChecked(profile.output.thin_hairlines)
        self.o_low_memory.setChecked(profile.output.low_memory)
        self.o_light_tiles.setChecked(profile.output.min_feature_px > 0)
        self.o_small_labels.setChecked(profile.output.min_label_px > 0)
        self.o_small_label_px.setEnabled(profile.output.min_label_px > 0)
        if profile.output.min_label_px > 0:
            self.o_small_label_px.setValue(profile.output.min_label_px)
        self.o_reuse.setChecked(profile.output.reuse_unchanged)
        self.o_versions.setChecked(profile.output.local_versions)
        dest = profile.destination
        self._dest_family, self._dest_other = None, {}  # the profile's own values, no swap
        self.d_kind.setCurrentIndex(max(0, self.d_kind.findData(dest.kind)))
        self.d_account.setText(dest.account_id)
        self.d_endpoint.setText(dest.endpoint)
        self.d_bucket.setText(dest.bucket)
        self.d_prefix.setText(dest.prefix)
        self.d_public.setText(dest.public_base_url)
        self.d_retention.setValue(dest.retention)
        self.d_conditional.setChecked(dest.conditional_writes)
        self.d_ssh_host.setText(dest.host)
        self.d_ssh_port.setValue(dest.port if 1 <= dest.port <= 65535 else 22)
        self.d_ssh_user.setText(dest.user)
        self.d_ssh_dir.setText(dest.remote_dir)
        self.d_ssh_key.setText(dest.identity_file)
        if self.d_auth is not None:
            self.d_auth.setConfigId(dest.credential_ref)
        self._destination_kind_changed()
        self._update_address()
        # Zooms from a settings file or a preset: showing the simple view
        # never replaces them (__init__ then says what the opened settings are).
        self.simple.settings_loaded(False, automatic=False)
        if self.is_simple_view():
            self.simple.refresh()

    def _tab_changed(self, index):
        if self.tabs.widget(index) is not None and self.tabs.tabText(index) == tr("Interaction"):
            self._fill_interaction_layers()
        if self.tabs.tabText(index) == tr("Review"):
            self.refresh_review()

    def _included_ids(self):
        return [item.data(0, LAYER_ROLE) for item in self._tree_items()
                if item.checkState(COL_PUBLISH) == CHECKED]

    def _fill_interaction_layers(self):
        self._store_layer_fields()
        self.i_layers.blockSignals(True)
        self.i_layers.clear()
        layers = [self.project.mapLayer(layer_id) for layer_id in self._included_ids()]
        # Removed from the project while the window is open: skipped.
        layers = sorted((layer for layer in layers if layer is not None),
                        key=lambda layer: (_fold(layer.name()), layer.name()))
        for layer in layers:
            layer_id = layer.id()
            item = QListWidgetItem(layer.name())
            item.setData(Qt.ItemDataRole.UserRole, layer_id)
            item.setToolTip(layer.name())
            try:
                item.setIcon(QgsIconUtils.iconForLayer(layer))
            except (AttributeError, TypeError):
                pass
            self.i_layers.addItem(item)
        self.i_layers.blockSignals(False)
        # A find box only where the list is long.
        long_list = self.i_layers.count() > LAYER_FILTER_FROM
        self.i_layers_filter.setVisible(long_list)
        if not long_list:
            self.i_layers_filter.clear()
        self._filter_interaction_layers()
        self.current_layer_id = None
        first = next((row for row in range(self.i_layers.count())
                      if not self.i_layers.item(row).isHidden()), None)
        if first is not None:
            self.i_layers.setCurrentRow(first)

    def _filter_interaction_layers(self, *_):
        text = _fold(self.i_layers_filter.text())
        for row in range(self.i_layers.count()):
            item = self.i_layers.item(row)
            item.setHidden(bool(text) and text not in _fold(item.text()))

    def _interaction_layer_changed(self, current, previous):
        self._store_layer_fields()
        self.current_layer_id = current.data(Qt.ItemDataRole.UserRole) if current else None
        if not self.current_layer_id:
            return
        layer = self.project.mapLayer(self.current_layer_id)
        if layer is None:
            self.current_layer_id = None
            return
        config = self.layer_configs.setdefault(self.current_layer_id, LayerConfig(self.current_layer_id))
        if isinstance(layer, QgsRasterLayer):
            self.i_stack.setCurrentIndex(1)
            self.r_title.setText(config.title)
            self.r_format.setCurrentIndex(max(0, self.r_format.findData(config.raster_format)))
            if config.raster_hidpi:
                # "Sharp on high-resolution screens" (512 px tiles) is gone:
                # the same sharpest detail is one zoom further.
                config.raster_hidpi = False
                if config.raster_max_zoom is not None:
                    config.raster_max_zoom = min(22, config.raster_max_zoom + 1)
                elif not config.raster_match_native:
                    config.raster_max_zoom = min(22, self.e_max_zoom.value() + 1)
            self.r_min.blockSignals(True)
            self.r_min.setValue(-1 if config.raster_min_zoom is None else config.raster_min_zoom)
            self.r_min.blockSignals(False)
            self._raster_choice = "image" if config.raster_max_zoom is None and config.raster_match_native \
                else "map" if config.raster_max_zoom is None else config.raster_max_zoom
            self.r_detail.blockSignals(True)
            self.r_detail.clear()
            self.r_detail.blockSignals(False)
            self.r_quality.setValue(config.raster_quality)
            web = layer.providerType() == "wms"
            self.r_live.blockSignals(True)
            self.r_live.setEnabled(web)
            self.r_live.setChecked(web and config.raster_live)
            self.r_live.blockSignals(False)
            self._raster_live_toggled(self.r_live.isChecked())
            self.r_opacity.setValue(config.opacity)
            self.r_legend.setChecked(config.legend)
            self._raster_estimate()
            return
        self.i_stack.setCurrentIndex(0)
        self.i_title.setText(config.title)
        self.i_display.setText(config.display_expression)
        self.i_opacity.setValue(config.opacity)
        self.i_legend.setChecked(config.legend)
        self.i_label_always.setChecked(config.label_always)
        self.i_snap.setChecked(config.snap)
        self.i_links.setChecked(config.deep_links)
        self.i_height.clear()
        self.i_height.addItem(tr("(none)"), "")
        polygon = getattr(layer, "geometryType", lambda: None)() == QgsWkbTypes.PolygonGeometry
        fields = sorted(layer.fields() if polygon else [], key=lambda f: not f.isNumeric())
        for field in fields:  # numbers first; text holding numbers ("12.5") works too
            self.i_height.addItem(field.name() if field.isNumeric() else f"{field.name()} ({tr('text')})",
                                  field.name())
        self.i_height.setCurrentIndex(max(0, self.i_height.findData(config.height_field)))
        self.i_height.setEnabled(polygon)
        popups = {p.field: p for p in config.popup_fields}
        filters = {f.field: f for f in config.filter_fields}
        fields = layer.fields()
        self.i_fields.setRowCount(fields.count())
        for row in range(fields.count()):
            name = fields.at(row).name()
            item = QTableWidgetItem(name)
            item.setFlags(Qt.ItemFlag.ItemIsEnabled)
            self.i_fields.setItem(row, 0, item)
            for column, value in ((1, name in popups), (4, name in config.search_fields),
                                  (5, name in config.key_fields)):
                box = QTableWidgetItem()
                box.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
                box.setCheckState(_check(value))
                self.i_fields.setItem(row, column, box)
            self.i_fields.setItem(row, 2, QTableWidgetItem(popups[name].alias if name in popups else ""))
            kind = QComboBox()
            for value in FIELD_TYPES:
                kind.addItem(value, value)
            guess = popups[name].type if name in popups else self._guess_type(fields.at(row))
            kind.setCurrentIndex(max(0, kind.findData(guess)))
            self.i_fields.setCellWidget(row, 3, kind)
            flt = QComboBox()
            flt.addItem(tr("no filter"), "")
            for value, label in (("values", tr("values")), ("range", tr("range")), ("text", tr("text"))):
                flt.addItem(label, value)
            flt.setCurrentIndex(max(0, flt.findData(filters[name].kind if name in filters else "")))
            self.i_fields.setCellWidget(row, 6, flt)

    @staticmethod
    def _guess_type(field) -> str:
        name = field.typeName().lower()
        if field.isNumeric():
            return "integer" if "int" in name else "number"
        if "bool" in name:
            return "boolean"
        if "date" in name or "time" in name:
            return "date"
        return "string"

    def _store_layer_fields(self):
        if not self.current_layer_id:
            return
        config = self.layer_configs.setdefault(self.current_layer_id, LayerConfig(self.current_layer_id))
        if isinstance(self.project.mapLayer(self.current_layer_id), QgsRasterLayer):
            config.title = self.r_title.text().strip()
            config.raster_format = self.r_format.currentData()
            config.raster_min_zoom = self.r_min.value() if self.r_min.value() >= 0 else None
            config.raster_max_zoom, config.raster_match_native = self._raster_detail()
            config.raster_quality = self.r_quality.value()
            if self.r_live.isEnabled():
                config.raster_live = self.r_live.isChecked()
            config.raster_hidpi = False
            config.opacity = float(self.r_opacity.value())
            config.legend = self.r_legend.isChecked()
            return
        config.title = self.i_title.text().strip()
        config.display_expression = self.i_display.text().strip()
        config.opacity = float(self.i_opacity.value())
        config.legend = self.i_legend.isChecked()
        config.label_always = self.i_label_always.isChecked()
        config.snap = self.i_snap.isChecked()
        config.deep_links = self.i_links.isChecked()
        config.height_field = self.i_height.currentData() or ""
        popups, search, keys, filters = [], [], [], []
        titles = {f.field: f.alias for f in config.filter_fields}  # (no widget: kept)
        for row in range(self.i_fields.rowCount()):
            name = self.i_fields.item(row, 0).text()
            if self.i_fields.item(row, 1).checkState() == CHECKED:
                popups.append(PopupField(name, self.i_fields.item(row, 2).text().strip(),
                                         self.i_fields.cellWidget(row, 3).currentData()))
            if self.i_fields.item(row, 4).checkState() == CHECKED:
                search.append(name)
            if self.i_fields.item(row, 5).checkState() == CHECKED:
                keys.append(name)
            kind = self.i_fields.cellWidget(row, 6).currentData()
            if kind:
                filters.append(FilterField(name, kind, titles.get(name, "")))
        config.popup_fields, config.search_fields = popups, search
        config.key_fields, config.filter_fields = keys, filters

    def collect(self) -> PublicationProfile:
        self._store_layer_fields()
        profile = self.profile
        profile.title = self.e_title.text().strip()
        profile.slug = self.e_slug.text().strip() or slugify(profile.title)
        profile.description = self.e_description.toPlainText().strip()
        profile.locale = self.e_locale.currentData()
        profile.attribution = self.e_attribution.text().strip()
        profile.logo_path = self.e_logo.text().strip()
        terrain_layer = self.t_layer.currentLayer()
        profile.terrain.layer_id = terrain_layer.id() if terrain_layer is not None else ""
        profile.terrain.hillshade = self.t_hillshade.isChecked()
        profile.terrain.exaggeration = float(self.t_exaggeration.value())
        profile.info.issuer = self.i_issuer.text().strip()
        profile.info.decree = self.i_decree.text().strip()
        profile.info.legal_date = self.i_legal_date.text().strip()
        profile.info.data_date = self.i_data_date.text().strip()
        profile.info.documents = self._documents()
        profile.view.min_zoom = self.e_min_zoom.value()
        profile.view.max_zoom = self.e_max_zoom.value()
        profile.view.max_view_zoom = max(self.e_max_view.value(), profile.view.max_zoom)
        profile.view.limit_to_extent = self.e_limit_extent.isChecked()
        layers = []
        for item in self._tree_items():
            layer_id = item.data(0, LAYER_ROLE)
            config = self.layer_configs.get(layer_id) or LayerConfig(layer_id)
            config.included = item.checkState(COL_PUBLISH) == CHECKED
            config.initially_visible = config.included and item.checkState(COL_VISIBLE) == CHECKED
            config.toggleable = not config.included or item.checkState(COL_TOGGLE) == CHECKED
            if config.included and not config.toggleable:
                config.initially_visible = True
            config.min_scale, config.max_scale, config.labels_min_scale = self._item_scales(item)
            config.zoomed_out, config.zoomed_out_below = self._item_zoomed(item)
            config.legend = item.checkState(COL_LEGEND) == CHECKED
            layers.append(config)
        profile.layers = layers
        groups = []
        folded = {tuple(g.path) for g in profile.groups if not g.expanded}  # (no widget: kept)
        for item in self._group_items():
            toggleable = item.checkState(COL_TOGGLE) == CHECKED
            visible = item.checkState(COL_VISIBLE) == CHECKED or not toggleable
            expanded = tuple(item.data(0, GROUP_ROLE)) not in folded
            if not toggleable or not visible or not expanded:  # only groups that differ from the defaults
                groups.append(GroupConfig(list(item.data(0, GROUP_ROLE)), toggleable=toggleable,
                                          initially_visible=visible, expanded=expanded))
        profile.groups = groups
        names = [self.themes_list.item(i).text() for i in range(self.themes_list.count())
                 if self.themes_list.item(i).checkState() == CHECKED]
        profile.themes.names = names
        profile.themes.initial = self.theme_initial.currentData() if self.theme_initial.currentData() in names else ""
        if hasattr(self.e_accent, "color"):
            profile.accent_color = self.e_accent.color().name()
        else:
            profile.accent_color = self.e_accent.text().strip() or "#2563eb"
        self._collect_parcel_tab(profile)
        basemap = profile.basemap
        basemap.kind = self.b_kind.currentData()
        basemap.source = self.b_source.text().strip() if self.b_custom.isChecked() else ""
        basemap.flavors = [f for f, box in self.b_flavors.items() if box.isChecked()] or ["light"]
        basemap.xyz = self._xyz_rows()
        basemap.initial = self.b_initial.currentData() or "none"
        xyz_ids = [f"xyz-{n}" for n in range(1, len(basemap.xyz) + 1)]
        if basemap.initial != "none" and basemap.initial not in basemap.flavors + xyz_ids:
            basemap.initial = basemap.flavors[0]
        basemap.max_zoom = self.b_max.value()
        basemap.padding = self.b_padding.value() / 100.0
        basemap.overview_zoom = min(self.b_overview_zoom.value(), basemap.max_zoom)
        basemap.overview_km = float(self.b_overview_km.value())
        for key, box in self.i_flags.items():
            setattr(profile.interaction, key, box.isChecked())
        profile.interaction.google_api_key = self.i_google_key.text().strip()
        address_layer = self.i_address_layer.currentLayer()
        profile.interaction.address_layer_id = address_layer.id() if address_layer is not None else ""
        profile.interaction.address_number_field = self.i_address_number.currentField() if address_layer else ""
        profile.interaction.address_street_field = self.i_address_street.currentField() if address_layer else ""
        if address_layer is not None and not profile.interaction.address_number_field:
            profile.interaction.address_layer_id = ""
        out = profile.output
        out.archive = self.o_archive.currentData()
        out.local_directory = self.o_dir.text().strip()
        out.xyz_package, out.zip = self.o_xyz.isChecked(), self.o_zip.isChecked()
        out.cpu_percent = self.o_cpu.value()
        out.fidelity_mode = self.o_fidelity.currentData()
        out.overzoom = self.o_overzoom.currentData()
        out.polygon_labels_base = self.o_labels.currentData()
        out.include_all_fields = self.o_all_fields.isChecked()
        out.fast_markers = self.o_fast_markers.isChecked()
        out.thin_hairlines = self.o_thin_hairlines.isChecked()
        out.low_memory = self.o_low_memory.isChecked()
        out.min_feature_px = (out.min_feature_px or 0.5) if self.o_light_tiles.isChecked() else 0.0
        out.min_label_px = self.o_small_label_px.value() if self.o_small_labels.isChecked() else 0.0
        out.reuse_unchanged = self.o_reuse.isChecked()
        out.local_versions = self.o_versions.isChecked()
        dest = profile.destination
        dest.kind = self.d_kind.currentData()
        dest.account_id = self.d_account.text().strip()
        dest.endpoint = self.d_endpoint.text().strip()
        dest.bucket = self.d_bucket.text().strip()
        dest.prefix = self.d_prefix.text().strip()
        dest.public_base_url = self.d_public.text().strip().rstrip("/")
        dest.retention = self.d_retention.value()
        dest.conditional_writes = self.d_conditional.isChecked()
        dest.host = self.d_ssh_host.text().strip()
        dest.port = self.d_ssh_port.value()
        dest.user = self.d_ssh_user.text().strip()
        dest.remote_dir = self.d_ssh_dir.text().strip()
        dest.identity_file = self.d_ssh_key.text().strip()
        dest.credential_ref = self.d_auth.configId() if self.d_auth is not None else ""
        return profile

    # ------------------------------------------------------------------ actions
    def apply_preset(self, module):
        """Fill the settings from ``module`` (a publishing.presets module)."""
        profile = self.collect()
        notes = module.apply(self.project, profile)
        self.profile = profile
        self._populate(profile)
        for note in notes:
            self.log(note)
        self.status.setText(tr("Preset applied: {}. Review the settings before publishing.").format(module.TITLE))
        if notes:
            QMessageBox.information(self, module.TITLE, "\n".join(notes[:30]))

    def log(self, text: str):
        self.logbox.appendPlainText(str(text))
        QgsMessageLog.logMessage(str(text), TAG, Qgis.MessageLevel.Info)

    def _save_xyz_connections(self):
        """The web basemaps also as QGIS XYZ connections (when the settings are
        saved, not on every read of the window, so half-typed rows stay out)."""
        try:
            from .xyz_connections import save_qgis_xyz_connections  # pylint: disable=import-outside-toplevel
            save_qgis_xyz_connections(self._xyz_rows(used_only=False))
        except Exception:  # noqa: BLE001 - settings are a convenience; never block the window
            pass

    def save_settings(self, quiet=False) -> bool:
        """``quiet`` (closing the window): no message, and settings with
        problems are not saved, so the last valid ones stay (an invalid
        profile would not load next time)."""
        if self._project_gone:
            if not quiet:
                QMessageBox.warning(self, tr("Settings"), tr("The project these settings belong to was "
                                                             "closed; they are not saved."))
            return False
        profile = self.collect()
        self._save_xyz_connections()
        problems = validate(profile)
        if problems:
            if not quiet:
                QMessageBox.warning(self, tr("Settings"), "\n".join(problems[:12]))
            return False
        store.save_profile(self.project, profile)
        self._saved_json = store.dumps_profile(profile)
        self._slug_follows = False
        self.status.setText(tr("Settings saved in the project (save the project file to keep them)."))
        return True

    def export_settings_file(self, path=None) -> bool:
        interactive = not path
        if not path:
            start = os.path.join(os.path.dirname(self.project.fileName()) or os.path.expanduser("~"),
                                 f"{self.e_slug.text().strip() or 'web-map'}.q2vt.json")
            path, _ = QFileDialog.getSaveFileName(self, tr("Export settings"), start,
                                                  tr("Publication settings (*.q2vt.json *.json)"))
        if not path:
            return False
        profile = self.collect()
        keys = self._exportable_credentials(profile)
        if keys and interactive and QMessageBox.question(
                self, tr("Export settings"),
                tr("Include the object storage keys (the secret key too) in the file?\n\n"
                   "Yes: whoever has the file can upload to the storage; keep it private. "
                   "No: the file has every other setting; the keys are entered again where it is imported."),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            keys = None
        try:
            # With the keys: readable by the owner only (POSIX; an existing
            # file too, changed before anything is written into it).
            flags = os.O_WRONLY | os.O_CREAT | getattr(os, "O_BINARY", 0)  # (Windows: no second newline translation)
            handle = open(os.open(path, flags, 0o600 if keys else 0o666), "w", encoding="utf-8")
            with handle:
                if keys and hasattr(os, "fchmod"):
                    os.fchmod(handle.fileno(), 0o600)
                handle.truncate()
                handle.write(store.export_document(profile, self.project, keys))
        except OSError as error:
            QMessageBox.warning(self, tr("Export settings"), str(error))
            return False
        if keys:
            self.status.setText(tr("Settings exported to {} with the object storage keys (secret included: "
                                   "keep the file private).").format(path))
        elif profile.destination.kind == "ssh":
            self.status.setText(tr("Settings exported to {} (without the SSH password).").format(path))
        else:
            self.status.setText(tr("Settings exported to {} (no object storage keys).").format(path))
        return True

    def _exportable_credentials(self, profile):
        """The destination's keys for the settings file (the owner wants them
        there): the pasted session keys, else the saved QGIS configuration."""
        if profile.destination.kind in ("local", "ssh"):  # an SSH password never goes into a file
            return None
        from ..publishing.providers.base import Credentials  # pylint: disable=import-outside-toplevel
        key, secret = self.d_session_key.text().strip(), self.d_session_secret.text()
        if key and secret:
            return Credentials(key, secret)
        if not profile.destination.credential_ref:
            return None
        try:
            from ..publishing.credentials import from_auth_config  # pylint: disable=import-outside-toplevel
            return from_auth_config(profile.destination.credential_ref)
        except PublishingError as error:
            self.log(tr("The keys were not exported: {}").format(error.message))
            return None

    def import_settings_file(self, path=None, same_map=None) -> bool:
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, tr("Import settings"),
                                                  os.path.dirname(self.project.fileName()) or "",
                                                  tr("Publication settings (*.q2vt.json *.json)"))
        if not path:
            return False
        try:
            with open(path, encoding="utf-8") as handle:
                text = handle.read()
            profile, notes = store.import_document(text, self.project)
            keys = store.document_credentials(text)
        except (OSError, ValueError, KeyError, PublishingError) as error:
            QMessageBox.warning(self, tr("Import settings"),
                                tr("Not a publication settings file:\n{}").format(error))
            return False
        if same_map is None:
            answer = QMessageBox.question(
                self, tr("Import settings"),
                tr("Yes: keep publishing the same web map as the file (same address).\n"
                   "No: a new, separate web map with these settings.\n"
                   "Cancel: import nothing."),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel)
            if answer not in (QMessageBox.StandardButton.Yes, QMessageBox.StandardButton.No):
                return False  # Cancel, Esc or the title bar's close button
            same_map = answer == QMessageBox.StandardButton.Yes
        if not same_map:
            profile = store.as_new_publication(profile)
        known = {config.layer_id for config in profile.layers}
        for node in self.project.layerTreeRoot().findLayers():
            layer = node.layer()
            if publishable(layer) and layer.id() not in known:
                profile.layers.append(LayerConfig(layer.id(), included=False, initially_visible=False))
        if keys is not None:
            profile.destination.credential_ref = ""  # an id of the other computer's QGIS
        self.profile = profile
        self._slug_follows = False  # the file's address
        self._populate(profile)
        for note in notes:
            self.log(note)
        if keys is not None:
            self._import_credentials(keys)
        if profile.basemap.xyz:  # web basemaps: also QGIS XYZ connections at once
            try:
                from .xyz_connections import save_qgis_xyz_connections  # pylint: disable=import-outside-toplevel
                save_qgis_xyz_connections(profile.basemap.xyz)
                self.log(tr("{} web basemap(s) imported (also as QGIS XYZ connections).").format(
                    len(profile.basemap.xyz)))
            except Exception:  # noqa: BLE001 - settings are a convenience
                pass
        self.status.setText(tr("Settings imported from {}. Check them, then Save settings to keep them "
                               "in the project.").format(os.path.basename(path)))
        return True

    def _import_credentials(self, keys):
        """Keys from a settings file: usable at once (session keys), and saved
        encrypted in QGIS when possible (kept after a restart)."""
        self.d_session_key.setText(keys.access_key_id)
        self.d_session_secret.setText(keys.secret_access_key)
        from ..publishing.credentials import store_auth_config  # pylint: disable=import-outside-toplevel
        bucket = self.d_bucket.text().strip() or "maps"
        name = f"{'R2' if self.d_kind.currentData() == 'r2' else 'S3'} {bucket} (QWebMap)"
        try:
            config_id = store_auth_config(name, keys.access_key_id, keys.secret_access_key)
        except PublishingError as error:
            self.log(tr("Object storage keys imported for this session ({}).").format(error.message))
            return
        if self.d_auth is not None:
            self.d_auth.setConfigId(config_id)
        self.profile.destination.credential_ref = config_id
        self.d_session_key.clear()
        self.d_session_secret.clear()
        self.log(tr("Object storage keys imported and saved encrypted in QGIS as “{}”.").format(name))

    def _busy(self, busy: bool):
        for button in (self.btn_save, self.btn_export, self.btn_publish, self.btn_close):
            button.setEnabled(not busy)
        # The settings stay as the export / upload read them: no editing,
        # importing or presets meanwhile.
        self.tabs.setEnabled(not busy)
        if getattr(self, "simple", None) is not None:
            self.simple.setEnabled(not busy)
            if self.is_simple_view():
                self.progress.setVisible(busy)
        self.btn_settings_file.setEnabled(not busy)
        self.btn_preset.setEnabled(not busy)
        # (Switching views shows the settings again, a preview render with it.)
        self.btn_simple.setEnabled(not busy)
        self.btn_advanced.setEnabled(not busy)
        self.btn_cancel.setEnabled(busy)

    def _block_qgis(self, block: bool):
        """The local export runs here, on the main thread, and keeps QGIS
        drawing meanwhile: the rest of QGIS takes no input until it ends
        (a layer removed or another project opened under the export would
        crash it). Only this window (Cancel) does."""
        modality = Qt.WindowModality.ApplicationModal if block else Qt.WindowModality.NonModal
        if self.windowModality() == modality:
            return
        visible = self.isVisible()
        if visible:
            self.hide()  # (a shown window's modality only changes when shown again)
        self.setWindowModality(modality)
        if visible:
            self.show()

    def cancel(self):
        if self.feedback is not None:
            self.feedback.cancel()
        if self.task is not None:
            self.task.cancel()

    def _extent(self) -> QgsRectangle:
        extent = self._current_extent_3857()
        if not extent:
            raise PublishingError("Q2VT_PUB_PROFILE_INVALID", tr("Choose an extent."))
        return QgsRectangle(*extent)

    def export_locally(self) -> bool:
        # Settings with problems: said at once, before the extent question and
        # the zoomed-out estimate (which can take a while) are asked for nothing.
        problems = validate(self.collect())
        if problems:
            QMessageBox.warning(self, tr("Settings"), "\n".join(problems[:12]))
            return False
        if not self._confirm_extent():
            return False
        if not self._check_zoom_load_before_export():
            return False
        if not self._check_large_rasters():
            return False
        if not self.save_settings():
            return False
        from ..publishing.controller import export_local  # pylint: disable=import-outside-toplevel
        self.feedback = DialogFeedback(self)
        self._busy(True)
        self._block_qgis(True)
        self.progress.setValue(0)
        self.logbox.clear()
        try:
            result = export_local(self.project, self.profile, self._extent(), self.feedback,
                                  stage_callback=lambda s: self.status.setText(tr("Stage: ") + s))
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return False
        except Exception:  # noqa: BLE001
            self._fail("ERROR", tr("Export failed."), traceback.format_exc())
            return False
        finally:
            self._block_qgis(False)
            self._busy(False)
            self.feedback = None
        self.local_result = result
        self.local_profile_json = store.dumps_profile(self.profile)
        self._watch_export()
        self.status.setText(tr("Local web map ready: {} ({} files, {:.1f} MB).").format(
            result.entry_path, len(result.release.files), result.release.total_bytes / 1e6))
        if result.mbtiles_copy:
            self.log(tr("MBTiles: {}").format(result.mbtiles_copy))
        if result.zip_path:
            self.log(tr("Offline ZIP: {}").format(result.zip_path))
        for warning in result.warnings:
            self.log(f"⚠ {warning}")
        self._update_local_buttons()
        return True

    def _watch_export(self):
        """Publish reuses the local export only while the project's layers
        stay as exported: a data, style, source or layer change since (the
        window is not modal) makes it out of date."""
        watched = getattr(self, "_watched_layers", None)
        if watched is None:
            watched = self._watched_layers = set()
            for signal in (self.project.layersAdded, self.project.layersRemoved, self.project.crsChanged):
                signal.connect(self._export_outdated)
        for layer_id, layer in self.project.mapLayers().items():
            if layer_id in watched:
                continue
            watched.add(layer_id)
            for name in ("dataChanged", "styleChanged", "rendererChanged", "repaintRequested", "dataSourceChanged"):
                signal = getattr(layer, name, None)
                if signal is not None:
                    signal.connect(self._export_outdated)

    def _export_outdated(self, *_):
        self.local_profile_json = None  # (the export itself stays for Preview / Open folder)

    def _fail(self, code, message, detail=""):
        self.status.setText(f"{code}: {message}")
        if detail:
            self.log(detail)
        QMessageBox.warning(self, tr("Web map"), f"{message}\n\n{code}")

    def _existing_map_dir(self) -> str:
        """The web map exported into the output folder under the current
        address name (by this window or earlier: its index.html is there),
        else ""."""
        base = self.o_dir.text().strip()
        slug = self.e_slug.text().strip() or slugify(self.e_title.text().strip())
        if not base or not slug:
            return ""
        from ..publishing.controller import output_folder  # pylint: disable=import-outside-toplevel
        folder = os.path.join(output_folder(base), slug)
        return folder if os.path.isfile(os.path.join(folder, "index.html")) else ""

    def _local_map_dir(self) -> str:
        """What Preview and Open folder show: the map in the output folder for
        the current settings, else the one this window last exported."""
        folder = self._existing_map_dir()
        if folder:
            return folder
        if self.local_result and os.path.isfile(os.path.join(self.local_result.publication_dir, "index.html")):
            return self.local_result.publication_dir
        return ""

    def _update_local_buttons(self, *_):
        available = bool(self._local_map_dir())
        if getattr(self, "simple", None) is not None:
            self.simple.update_buttons()
        for button in (self.btn_preview, self.btn_folder):
            button.setEnabled(available)
        self.btn_preview.setToolTip(
            tr("Opens the web map exported into the output folder in your browser (served from this "
               "computer)") if available else tr("Export the web map locally first"))

    def preview(self):
        folder = self._local_map_dir()
        if not folder:
            self._update_local_buttons()
            return
        from ..publishing.preview_server import PreviewServer  # pylint: disable=import-outside-toplevel
        if self.preview_server is not None and self.preview_server.root != os.path.realpath(folder):
            self.preview_server.stop()  # exported elsewhere since (another name or folder)
            self.preview_server = None
        if self.preview_server is None:
            # The publication folder only: not the work files, the cache or
            # other maps next to it.
            self.preview_server = PreviewServer(folder).start()
        url = self.preview_server.url("index.html")
        self.log(tr("Preview: {}").format(url))
        QDesktopServices.openUrl(QUrl(url))

    def open_folder(self):
        folder = self._local_map_dir()
        if folder:
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    def open_map(self):
        if self.public_url.startswith("file:"):
            # A local web map: browsers do not run the viewer from file://
            # (its modules and the byte ranges of its archives): served as Preview.
            self.preview()
        elif self.public_url:
            QDesktopServices.openUrl(QUrl(self.public_url))

    def copy_link(self):
        if self.public_url:
            QGuiApplication.clipboard().setText(self.public_url)
            self.status.setText(tr("Link copied: {}").format(self.public_url))

    def copy_embed_code(self) -> str:
        """Copy an <iframe> of the online map in embed mode (?embed); a local
        copy cannot be shown in another site. Returns the code ("" = none)."""
        url = self.public_url if self.public_url.startswith(("http://", "https://")) else \
            self._target_url(self.collect())
        if not url:
            self.status.setText(
                tr("Enter the public URL of the server folder (Destination tab): the embed code needs "
                   "the map's web address.") if self.d_kind.currentData() == "ssh" else
                tr("Publish the map online first (Destination tab): a local copy "
                   "cannot be shown in another web page."))
            return ""
        code = embed_code(url, self.e_title.text().strip() or self.profile.title)
        QGuiApplication.clipboard().setText(code)
        self.status.setText(tr("Embed code copied. Paste it into the other page's HTML:\n{}").format(code))
        return code

    def _credentials(self):
        from ..publishing.credentials import from_auth_config  # pylint: disable=import-outside-toplevel
        from ..publishing.providers.base import Credentials  # pylint: disable=import-outside-toplevel
        if self.profile.destination.kind == "ssh":  # optional: keys and ssh-agent need none
            if self.d_ssh_password.text():
                return Credentials(self.d_ssh_user.text().strip(), self.d_ssh_password.text())
            # Only a configuration selected while SSH was chosen (_destination_kind_changed).
            if self.profile.destination.credential_ref:
                return from_auth_config(self.profile.destination.credential_ref, ssh=True)
            return None
        if self.d_session_key.text().strip() and self.d_session_secret.text():
            return Credentials(self.d_session_key.text().strip(), self.d_session_secret.text())
        return from_auth_config(self.profile.destination.credential_ref)

    def _provider(self):
        from ..publishing.providers import provider_for  # pylint: disable=import-outside-toplevel
        profile = self.profile
        prefix = "" if profile.destination.kind == "ssh" else publication_prefix(profile)  # SSH: one folder
        return provider_for(profile.destination, self._credentials(), prefix)

    def test_connection(self):
        profile = self.collect()
        if profile.destination.kind == "local":
            QMessageBox.information(self, tr("Destination"), tr("Local only: nothing to test."))
            return
        try:
            provider = self._provider()  # may ask for the QGIS master password: normal cursor
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)  # an SSH login can take seconds
            try:
                checks = provider.inspect()
            finally:
                QApplication.restoreOverrideCursor()
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return
        text = "\n".join(f"{'✔' if ok else '✖'} {name}: {detail}" for name, ok, detail in checks)
        QMessageBox.information(self, tr("Connection"), text)

    def show_r2_guide(self):
        from .r2_guide import R2GuideDialog  # pylint: disable=import-outside-toplevel
        self.r2_guide = R2GuideDialog(self)
        self.r2_guide.show()

    def _parse_pasted(self, field):
        """A Cloudflare address pasted into the account, endpoint or bucket
        field: account id (+ bucket, + jurisdiction endpoint) taken from it."""
        from ..publishing.providers.r2 import parse_pasted  # pylint: disable=import-outside-toplevel
        text = field.text().strip()
        found = parse_pasted(text)
        if not found or (field is self.d_bucket and "://" not in text and "." not in text):
            return
        if self.d_kind.currentData() == "local":
            self.d_kind.setCurrentIndex(max(0, self.d_kind.findData("r2")))
        self.d_account.setText(found["account_id"])
        self.d_endpoint.setText(found.get("endpoint", ""))
        if found.get("bucket"):
            self.d_bucket.setText(found["bucket"])
        elif field is self.d_bucket:
            self.d_bucket.clear()

    def _destination_kind_changed(self, *_):
        from .r2_guide import FIELD_HELP  # pylint: disable=import-outside-toplevel
        kind = self.d_kind.currentData()
        ssh, storage = kind == "ssh", kind in ("r2", "s3")
        # SSH and object storage never share the saved login or the public URL: switching
        # between them puts the other's values aside and brings back this one's (or none).
        family = "ssh" if ssh else "storage"
        if self._dest_family not in (None, family):
            self._dest_other[self._dest_family] = (
                self.d_public.text(), self.d_auth.configId() if self.d_auth is not None else "")
            public, ref = self._dest_other.pop(family, ("", ""))
            self.d_public.setText(public)
            if self.d_auth is not None:
                self.d_auth.setConfigId(ref)
        self._dest_family = family
        local = kind == "local"  # nothing uploaded: no destination fields at all
        for widget, shown in ((self.d_account, kind == "r2"), (self.d_endpoint, storage),
                              (self.d_bucket, storage), (self.d_prefix, storage),
                              (self.d_session_row, storage), (self.d_retention, storage),
                              (self.d_conditional, storage), (self.d_ssh_host, ssh), (self.d_ssh_port, ssh),
                              (self.d_ssh_user, ssh), (self.d_ssh_dir, ssh), (self.d_ssh_key_row, ssh),
                              (self.d_ssh_password_row, ssh), (self.d_public, not local),
                              (self.d_address, not local)):
            widget.setVisible(shown)
            label = self.d_form.labelForField(widget)
            if label is not None:
                label.setVisible(shown)
        if self.d_auth is not None:
            self.d_auth.setVisible(not local)
        if self.d_auth_label is not None:
            self.d_auth_label.setVisible(not local)
        for widget in (self.d_cors, self.d_history):  # releases, CORS: object storage only
            widget.setVisible(storage)
        self.d_guide.setVisible(not ssh)  # (also how to set up R2 when choosing a destination)
        self.d_test.setVisible(not local)
        label = self.d_form.labelForField(self.d_endpoint)
        if label is not None:
            label.setText(tr("S3 API endpoint (optional)") if kind == "r2" else tr("S3 API endpoint"))
        label = self.d_form.labelForField(self.d_public)
        if label is not None:
            label.setText(tr("Public URL of the folder (optional)") if ssh else tr("Public base URL (custom domain)"))
        self.d_public.setPlaceholderText("https://www.example.com/map" if ssh else "https://maps.example.com")
        self.d_public.setToolTip(tr("The address of the folder on the web, e.g. https://www.example.com/map. "
                                    "Used for Open map / Copy link and to check that the new map is served "
                                    "there. Empty: nothing is checked.") if ssh else tr(FIELD_HELP["public"]))
        if self.d_auth_label is not None:
            self.d_auth_label.setText(
                tr("Saved password (QGIS authentication: user = SSH user, password = password or "
                   "passphrase)") if ssh else
                tr("Saved credentials (QGIS authentication: user = access key id, password = secret)"))
        if self.d_auth is not None:
            self.d_auth.setToolTip(
                tr("A password (or key passphrase) saved encrypted in QGIS (protected by the QGIS master "
                   "password): a Basic configuration with user name = SSH user and password. “Save in "
                   "QGIS…” below makes one.") if ssh else tr(FIELD_HELP["auth"]))
        self.d_note.setText(
            tr("The map's files go straight into the folder and replace the previous map there (and any "
               "file with the same name): no versions, no rollback. Unchanged files are not uploaded "
               "again, index.html is replaced last, and only files QWebMap uploaded before are ever "
               "deleted (listed in .q2vt-files.json in the folder). Uses the OpenSSH client (sftp) of this "
               "computer. A new server's host key is accepted on first use; a changed one stops the "
               "upload.") + (tr(" On Windows a password or passphrase needs OpenSSH 8.4 or newer (Windows "
                                 "10's built-in client is older: use a key or ssh-agent there).")
                              if os.name == "nt" else "") if ssh else
            tr("Publish writes the map into the output folder (Output tab) on this computer: nothing is "
               "uploaded. Copy that folder to any web server, or choose a destination above.") if local else
            tr("Use bucket-scoped API tokens. The S3 API endpoint is not the public "
               "address: connect a custom domain to the bucket (r2.dev is rate "
               "limited and meant for development). Nothing is created, made "
               "public or deleted in your account automatically."))
        self._update_address()

    def _parse_ssh_target(self):
        """``user@server:/folder`` (or an sftp:// address) pasted into the
        server field: the user, port and folder taken from it."""
        from ..publishing.providers.ssh import parse_target  # pylint: disable=import-outside-toplevel
        found = parse_target(self.d_ssh_host.text())
        if not found:  # a plain host name or address stays as typed
            return
        self.d_ssh_host.setText(str(found["host"]))
        filled = []
        for key, field, label in (("user", self.d_ssh_user, tr("user")),
                                  ("remote_dir", self.d_ssh_dir, tr("folder"))):
            if found.get(key) and field.text().strip() != found[key]:
                field.setText(str(found[key]))
                filled.append(f"{label} {found[key]}")
        if found.get("port") and self.d_ssh_port.value() != found["port"]:
            self.d_ssh_port.setValue(int(found["port"]))
            filled.append(tr("port {}").format(found["port"]))
        if filled:
            self.status.setText(tr("Taken from the server address: {}.").format(", ".join(filled)))

    def _choose_ssh_key(self):
        start = self.d_ssh_key.text().strip() or os.path.join(os.path.expanduser("~"), ".ssh")
        path, _ = QFileDialog.getOpenFileName(self, tr("Private key file"), start)
        if path:
            self.d_ssh_key.setText(path)

    def save_ssh_password(self):
        """The SSH user and password, stored encrypted in the QGIS
        authentication database (Basic configuration), then selected."""
        from ..publishing.credentials import store_auth_config  # pylint: disable=import-outside-toplevel
        user, password = self.d_ssh_user.text().strip(), self.d_ssh_password.text()
        if not password:  # the user is optional, as in the User field (ssh's default user)
            QMessageBox.information(self, tr("Password"), tr("Enter the password (or the key's passphrase) "
                                                             "first."))
            return
        server = self.d_ssh_host.text().strip() or "server"
        name = f"SSH {user}@{server} (QWebMap)" if user else f"SSH {server} (QWebMap)"
        try:
            config_id = store_auth_config(name, user, password)
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return
        if self.d_auth is not None:
            self.d_auth.setConfigId(config_id)
        self.d_ssh_password.clear()
        self.status.setText(tr("Password saved encrypted in QGIS as “{}” and selected.").format(name))

    def _update_address(self, *_):
        public = self.d_public.text().strip().rstrip("/")
        if self.d_kind.currentData() == "ssh":
            self.d_address.setText(f"{public}/" if public else tr("— (optional: enter the folder's public URL)"))
            return
        if self.d_kind.currentData() == "local" or not public:
            self.d_address.setText(tr("— (enter the public base URL)") if self.d_kind.currentData() != "local"
                                   else tr("— (local only)"))
            return
        from ..publishing.profile import normalize_prefix  # pylint: disable=import-outside-toplevel
        try:
            prefix = self.d_prefix.text().strip()
            prefix = normalize_prefix(prefix) if prefix else \
                f"maps/{self.e_slug.text().strip() or slugify(self.e_title.text().strip())}"
            self.d_address.setText(f"{public}/{prefix}/")
        except PublishingError:
            self.d_address.setText(tr("— (check the prefix)"))

    def save_keys(self):
        """The session keys, stored encrypted in the QGIS authentication
        database as a Basic configuration, then selected."""
        from ..publishing.credentials import store_auth_config  # pylint: disable=import-outside-toplevel
        key, secret = self.d_session_key.text().strip(), self.d_session_secret.text()
        if not key or not secret:
            QMessageBox.information(self, tr("Keys"), tr("Paste the Access Key ID and the Secret Access "
                                                         "Key of the R2 API token first."))
            return
        bucket = self.d_bucket.text().strip() or "maps"
        name = f"{'R2' if self.d_kind.currentData() == 'r2' else 'S3'} {bucket} (QWebMap)"
        try:
            config_id = store_auth_config(name, key, secret)
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return
        if self.d_auth is not None:
            self.d_auth.setConfigId(config_id)
        self.d_session_key.clear()
        self.d_session_secret.clear()
        self.status.setText(tr("Keys saved encrypted in QGIS as “{}” and selected.").format(name))

    def show_cors(self):
        profile = self.collect()
        origin = profile.destination.public_base_url or "https://maps.example.com"
        from urllib.parse import urlparse  # pylint: disable=import-outside-toplevel
        parsed = urlparse(origin)
        policy = ('[\n  {\n    "AllowedOrigins": ["' + f"{parsed.scheme}://{parsed.netloc}" + '"],\n'
                  '    "AllowedMethods": ["GET", "HEAD"],\n'
                  '    "AllowedHeaders": ["Range", "If-Match", "If-None-Match"],\n'
                  '    "ExposeHeaders": ["Accept-Ranges", "Content-Range", "Content-Length", "ETag"],\n'
                  '    "MaxAgeSeconds": 3600\n  }\n]')
        box = QMessageBox(self)
        box.setWindowTitle(tr("CORS policy"))
        box.setText(tr("Only needed when the viewer is served from another origin than the map data. "
                       "Merge it with the bucket's existing rules in the Cloudflare dashboard (R2 → "
                       "bucket → Settings → CORS policy); the plugin does not change it."))
        box.setDetailedText(policy)
        box.exec()

    def show_history(self):
        self.collect()  # the destination as now on the tab, not as last saved
        try:
            provider = self._provider()
            releases = provider.list_releases()
            pointer, _ = provider.read_pointer()
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return
        from .deployment_history import DeploymentHistoryDialog  # pylint: disable=import-outside-toplevel
        DeploymentHistoryDialog(self, provider, self.profile, releases,
                                pointer.get("releaseId") if pointer else None).exec()

    @staticmethod
    def _inverted_scales_note():
        return tr("Visible scales: the zoomed-out limit is not a smaller scale than the zoomed-in "
                  "limit, so the layer is shown at no zoom (Layers tab: Visible scales).")

    def refresh_review(self):
        profile = self.collect()
        dest = profile.destination
        server = f"{dest.user}@{dest.host}" if dest.user else dest.host
        target = self._target_url(profile) or (
            tr("{} (port {}), folder {}").format(server, dest.port, dest.remote_dir) if dest.kind == "ssh"
            else tr("local folder only"))
        lines = [tr("Target: ") + target, ""]
        for config in profile.layers:
            if not config.included:
                continue
            layer = self.project.mapLayer(config.layer_id)
            if layer is None:
                continue
            # Saved inverted by an older version (not a validate() error: the
            # settings would not load): the layer shows at no zoom.
            inverted = bool(config.min_scale and config.max_scale and config.max_scale >= config.min_scale)
            if isinstance(layer, QgsRasterLayer):
                lines.append(f"■ {config.title or layer.name()} — " + tr(
                    "raster layer: its image as QGIS draws it, inside the extent ({} format)").format(
                    config.raster_format.upper()))
                if inverted:
                    lines.append("   ⚠ " + self._inverted_scales_note())
                if (layer.providerType() or "").lower() in ("wms", "xyz", "arcgismapserver", "wcs"):
                    lines.append("   ⚠ " + tr("Online map service: check that its licence allows republishing."))
                if not config.toggleable:
                    lines.append("   " + tr("Always shown (visitors cannot switch it off)"))
                continue
            lines.append(f"■ {config.title or layer.name()} — {layer.featureCount()} "
                         + tr("features in the layer (published: those inside the extent drawn by "
                              "the exported rules)"))
            if inverted:
                lines.append("   ⚠ " + self._inverted_scales_note())
            if not config.toggleable:
                lines.append("   " + tr("Always shown (visitors cannot switch it off)"))
            lines.append("   " + tr("Geometry and generated label/style values: public"))
            if config.popup_fields:
                lines.append("   " + tr("Popup fields: ") + ", ".join(p.field for p in config.popup_fields))
            if config.search_fields:
                lines.append("   " + tr("Searchable fields: ") + ", ".join(config.search_fields))
            if config.display_expression and (config.popup_fields or config.deep_links):
                # Each feature's label goes into the feature lookup files: the
                # fields the expression reads are public too.
                names = set(layer.fields().names())
                used = sorted(c for c in QgsExpression(config.display_expression).referencedColumns()
                              if c in names)
                lines.append("   " + tr("Feature label of every feature (display expression {}), public; "
                                        "fields used: ").format(config.display_expression)
                             + (", ".join(used) or tr("none")))
            if config.filter_fields:
                lines.append("   " + tr("Filter fields (also in the tiles): ")
                             + ", ".join(f.field for f in config.filter_fields))
            lines.append("   " + tr("Feature key: ") + (", ".join(config.key_fields) or
                                                       tr("none (links valid in one version only)")))
            if not config.initially_visible:
                lines.append("   " + tr("Hidden at start (still published)"))
        if profile.output.include_all_fields:
            lines += ["", tr("WARNING: all attribute fields are written to the tiles and can be "
                             "downloaded by anyone.")]
        if profile.basemap.kind == "protomaps":
            lines += ["", tr("Basemap: OpenStreetMap vector tiles of the area, bundled into the release; "
                             "downloaded from {} while exporting.").format(
                profile.basemap.source or "build.protomaps.com")]
        if profile.themes.names:
            lines.append(tr("Views (map themes): ") + ", ".join(profile.themes.names))
        if profile.terrain.layer_id:
            layer = self.project.mapLayer(profile.terrain.layer_id)
            lines += ["", tr("Terrain: the heights of {} inside the map's area (web tiles)").format(
                layer.name() if layer else "?")]
        heights = [c for c in profile.layers if c.included and c.height_field]
        if heights:
            lines.append(tr("3D height fields (public): ") + ", ".join(
                f"{(self.project.mapLayer(c.layer_id).name() if self.project.mapLayer(c.layer_id) else c.layer_id)}"
                f".{c.height_field}" for c in heights))
        extras = [name for on, name in [(profile.interaction.overview_map, tr("overview map")),
                                         (profile.interaction.three_d, tr("3D view")),
                                         (profile.interaction.drawing, tr("drawing tools")),
                                         (profile.interaction.street_view, tr("Street View"))] if on]
        if extras:
            lines.append(tr("Viewer extras: ") + ", ".join(extras))
        if heights and not profile.interaction.three_d:
            lines.append(tr("NOTE: 3D height fields are set but \"3D view\" is off (Interaction tab): "
                            "the map shows no 3D button."))
        if profile.interaction.address_layer_id:
            layer = self.project.mapLayer(profile.interaction.address_layer_id)
            lines += ["", tr("House number search: street and number of every address in the area ({})").format(
                layer.name() if layer else "?")]
        if profile.info.documents:
            lines += ["", tr("Documents (downloadable by anyone): ")
                      + ", ".join(f"{d.title} ({os.path.basename(d.path)})" for d in profile.info.documents)]
        info = profile.parcel_info
        if info.enabled:
            lines += ["", tr("Parcel report (public for every parcel in the extent): area, parts by zone, "
                             "restrictions touching it.")]
            if info.fields:
                lines.append("   " + tr("Parcel fields: ") + ", ".join(f.field for f in info.fields))
            if info.zoning_fields:
                lines.append("   " + tr("Zone fields: ") + ", ".join(f.field for f in info.zoning_fields))
            names = [r.name_field for r in info.restrictions if r.name_field]
            if names:
                lines.append("   " + tr("Restriction name fields: ") + ", ".join(names))
            for layer_id, label in ((info.regulation_layer_id, tr("Zone regulations table: ")),
                                    (info.text_layer_id, tr("Full regulation texts (HTML): "))):
                if layer_id:
                    layer = self.project.mapLayer(layer_id)
                    lines.append("   " + label + (layer.name() if layer else "?"))
        external = [f"{tr('web basemap')} „{x.title}” ({urlparse(x.url).hostname or '?'})"
                    for x in profile.basemap.xyz]
        if profile.interaction.street_view and profile.interaction.google_api_key.strip():
            external.append(tr("Google Street View (Google's script and your API key)"))
        for name, url in self._live_layers(profile):
            external.append(tr("live layer „{}” loaded from {} (its address is in the published "
                               "files)").format(name, urlparse(url).hostname or "?"))
        local = profile.destination.kind == "local"
        lines += ["", tr("External resources for visitors: ") + ("; ".join(external) if external else tr(
                      "none (no CDN, no third-party tiles, no telemetry)."))]
        if profile.destination.kind in ("r2", "s3"):
            lines.append(tr("Cost: storage of the archive and retained releases plus requests; R2 has no "
                            "egress fees but limits above the free tier are billed — see "
                            "https://developers.cloudflare.com/r2/pricing/ (checked 1 Oct 2026)."))
        if self.local_result:
            lines.append(tr("Last local export: {} files, {:.1f} MB.").format(
                len(self.local_result.release.files), self.local_result.release.total_bytes / 1e6))
        review = needs_review(profile, self._live_review_extra(profile))
        if local:  # nothing goes online: nothing to approve
            lines += ["", tr("Local only: the map is written to the output folder, nothing is uploaded "
                             "and no approval is needed.")]
        else:
            lines += ["", tr("Approval needed (first publication or what becomes public changed).")
                      if review else tr("Approved earlier for this exact data scope.")]
        self.review.setPlainText("\n".join(lines))
        self.approve.setVisible(not local)
        self.approve.setChecked(not review)
        self._review_fp = disclosure_fingerprint(profile, self._live_review_extra(profile))

    def _live_layers(self, profile):
        """[(layer name, tile or WMS address)] of the included raster layers
        the visitors' browsers load live from their own server."""
        from ..publishing.headless import live_layers  # pylint: disable=import-outside-toplevel
        return live_layers(self.project, profile)

    def _live_review_extra(self, profile):
        """The live layers' addresses in the disclosure fingerprint (None
        without any: the fingerprint of earlier approvals stays; the same
        as a command-line publication's, publishing.headless)."""
        from ..publishing.headless import live_review_extra  # pylint: disable=import-outside-toplevel
        return live_review_extra(self.project, profile)

    @staticmethod
    def _target_url(profile):
        if profile.destination.kind == "local" or not profile.destination.public_base_url:
            return ""
        from ..publishing.public_verify import join_url  # pylint: disable=import-outside-toplevel
        if profile.destination.kind == "ssh":  # the folder itself (its address percent-encoded)
            from ..publishing.folder_publish import folder_url  # pylint: disable=import-outside-toplevel
            return folder_url(profile) + "index.html"
        return join_url(profile.destination.public_base_url, publication_prefix(profile), "index.html")

    def publish(self):
        profile = self.collect()
        if profile.destination.kind == "local":
            if self.export_locally():
                self.public_url = QUrl.fromLocalFile(self.local_result.entry_path).toString()
                self.btn_open.setEnabled(True)
            return
        # Approved only for what the Review tab showed: a field made public
        # since then needs the review again.
        extra = self._live_review_extra(profile)
        if needs_review(profile, extra) and (not self.approve.isChecked()
                                             or self._review_fp != disclosure_fingerprint(profile, extra)):
            self.tabs.setCurrentIndex(self.tabs.count() - 1)
            self.refresh_review()
            QMessageBox.information(self, tr("Review"), tr("Review what becomes public and tick the "
                                                           "approval before publishing."))
            return
        # Reuse a valid local export of identical settings (retry/new destination);
        # compared before the approval is recorded: approving changes nothing exported.
        # The map view now (current map view mode): a pan since the export is a new extent.
        try:
            self._current_extent_3857()
        except Exception:  # noqa: BLE001 - checked again by the export
            pass
        reuse = self.local_result is not None and self.local_profile_json == store.dumps_profile(profile)
        if needs_review(profile, extra):
            profile.approval.fingerprint = disclosure_fingerprint(profile, extra)
            profile.approval.approved_at = _dt.datetime.now(_dt.timezone.utc).isoformat()
        if not reuse:
            if not self.export_locally():
                return
        try:
            credentials = self._credentials()
            provider = self._provider()
        except PublishingError as error:
            self._fail(error.code, error.message, error.detail)
            return
        from ..publishing.controller import publication_dirs  # pylint: disable=import-outside-toplevel
        _, work_dir = publication_dirs(profile)
        # A copy: the worker thread must not see edits made meanwhile.
        self.task = UploadTask(self.local_result.release, copy.deepcopy(profile), provider, work_dir,
                               credentials.secrets() if credentials is not None else [])
        self.task.progressChanged.connect(lambda value: self.progress.setValue(int(value)))
        self.task.message.connect(self.log)
        self.task.taskCompleted.connect(self._published)
        self.task.taskTerminated.connect(self._published)
        self._busy(True)
        self.status.setText(tr("Uploading and verifying…"))
        QgsApplication.taskManager().addTask(self.task)

    def _published(self):
        task, self.task = self.task, None
        self._busy(False)
        if task is None:
            return
        try:
            self._report_published(task)
        finally:
            # Closed while uploading, or its project closed meanwhile (its
            # settings are not this project's): the plugin lets go of it now.
            if not self.isVisible() or self._project_gone:
                self.done(QDialog.DialogCode.Rejected)

    def _report_published(self, task):
        if task.error:
            self._fail("ERROR", tr("Publishing failed."), task.error)
            return
        result = task.result
        if result is None:  # cancelled before it started
            self.status.setText(tr("Publishing cancelled."))
            return
        for check in result.checks.checks:
            self.log(f"{'✔' if check.ok else '✖'} {check.name}: {check.detail}")
        if result.state == ReleaseState.PUBLISHED:
            self.public_url = result.stable_url
            if not self._project_gone:  # never into another project
                store.save_profile(self.project, self.profile)
            self.btn_open.setEnabled(bool(self.public_url))
            self.btn_copy.setEnabled(bool(self.public_url))
            if result.versioned_url:
                self.status.setText(tr("Published: {}\nThis version: {}").format(result.stable_url,
                                                                                 result.versioned_url))
            elif result.stable_url:  # one folder on an SSH server: no versions
                self.status.setText(tr("Published: {}").format(result.stable_url))
            else:
                self.status.setText(result.message)
            for warning in result.warnings:
                self.log(f"⚠ {warning}")
        else:
            self._fail(result.code or result.state.value, result.message or result.state.value)
        if self._project_gone and self.iface is not None and result.state == ReleaseState.PUBLISHED:
            # Said outside the window, which closes (see _published).
            self.iface.messageBar().pushMessage(tr("Web map"), self.status.text(),
                                                Qgis.MessageLevel.Success, 0)

    # Size and position of the window, kept between QGIS sessions (QGIS settings).
    GEOMETRY_KEY = "QGIS2VectorTilesFork/publishDialog/geometry"  # pre-rename key, kept

    def _default_size(self):
        """Wide enough for the tabs' contents where the screen has room (the
        tabs scroll on a smaller screen), at least 980 × 760."""
        from qgis.PyQt.QtWidgets import QScrollArea  # pylint: disable=import-outside-toplevel
        pages = [self.tabs.widget(i) for i in range(self.tabs.count())]
        # (A scroll area's own size hint is capped: its contents' instead.)
        content = max((page.widget().sizeHint().width() if isinstance(page, QScrollArea) and page.widget()
                       else page.sizeHint().width()) for page in pages) if pages else 0
        width, height = max(980, content + 60), 760
        screen = self.screen() if hasattr(self, "screen") else None
        screen = screen or QGuiApplication.primaryScreen()
        if screen is not None:
            room = screen.availableGeometry()
            width, height = min(width, int(room.width() * 0.95)), min(height, int(room.height() * 0.92))
        self.resize(width, height)

    def _restore_geometry(self):
        try:
            saved = QgsSettings().value(self.GEOMETRY_KEY)
            if not saved or not self.restoreGeometry(saved):
                return
        except (TypeError, ValueError):
            return
        # A screen that is gone (laptop undocked): back to the default size and place.
        frame = self.frameGeometry()
        if not any(screen.availableGeometry().intersects(frame) for screen in QGuiApplication.screens()):
            self._default_size()
            primary = QGuiApplication.primaryScreen()
            if primary is not None:
                self.move(primary.availableGeometry().center() - self.rect().center())

    def _save_geometry(self):
        try:
            QgsSettings().setValue(self.GEOMETRY_KEY, self.saveGeometry())
        except (TypeError, ValueError):
            pass

    def showEvent(self, event):  # noqa: N802
        super().showEvent(event)
        self._give_up_drawing()  # opened again (Web menu) while drawing

    def done(self, result):  # every close of a shown window: Close, title bar ✕ and Escape
        if self.feedback is not None:
            return  # a local export is running (its Cancel button stops it)
        if self.isVisible() and not self._may_close():
            return  # back to the settings
        self._closing()
        super().done(result)

    def _may_close(self) -> bool:
        """Changed settings that cannot be saved (closing keeps only valid
        ones): ask before they are lost instead of dropping them silently."""
        if self._project_gone:
            return True
        try:
            if self._profile_json() == self._saved_json:
                return True
            problems = validate(self.collect())
        except Exception:  # noqa: BLE001 - closing must not fail
            return True
        if not problems:
            return True
        answer = QMessageBox.question(
            self, tr("Close without saving?"),
            tr("Your changes cannot be saved until these are fixed:") + "\n\n" + "\n".join(problems[:8])
            + "\n\n" + tr("Close the window and lose the changes since the last save?"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        return answer == QMessageBox.StandardButton.Yes

    def _closing(self):
        """Settings and window geometry saved, project link ended: on every
        close (done(), or closeEvent for a hidden window)."""
        self._give_up_drawing()
        self._save_geometry()
        if self.task is not None:
            QMessageBox.information(self, tr("Web map"), tr("Publishing is still running in the "
                                                            "background; see the task bar."))
        if not self._project_gone:
            try:
                # Saved only when changed: closing must not mark the project modified.
                if self._profile_json() != self._saved_json:
                    self.save_settings(quiet=True)
            except Exception:  # noqa: BLE001 - closing must not fail
                pass
        if self.task is not None:
            return  # still told when another project opens: the upload must not save into it
        try:
            self.project.cleared.disconnect(self._on_project_cleared)
        except (TypeError, RuntimeError):
            pass
        try:
            root = self.project.layerTreeRoot()
            for signal in (root.addedChildren, root.removedChildren, root.nameChanged):
                signal.disconnect(self._layers_changed)
        except (TypeError, RuntimeError):
            pass
        self._tree_timer.stop()

    def closeEvent(self, event):  # noqa: N802
        if not self.isVisible():  # hidden (drawing the extent, or never shown): no done()
            self._closing()
        super().closeEvent(event)  # a shown window: reject() -> done()
