"""Copy server utilities and launch the local tile server."""

import platform
import shlex
import subprocess
import json

from os import makedirs
from os.path import join, basename, exists, isfile
from shutil import copy2, copytree, which
from sys import prefix
from typing import Optional


from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsLayerDefinition,
    QgsMapBoxGlStyleConverter,
    QgsVectorTileLayer,
    QgsMapBoxGlStyleConversionContext
)

from qgis.PyQt.QtCore import qVersion

if int(qVersion()[0]) == 5:
    from PyQt5.QtGui import QImage
else:
    from PyQt6.QtGui import QImage

from ..utils.config import _RESOURCES, _PORT, _EPSG_CRS, _SERVER, _MAPLIBRE_LABELS_FACTOR
from .fidelity import expressions as ex
from .fidelity.zoom import fit_zoom
from .tiles_generator import mbtiles_uri

class ServerInitializer:
    """Copy server utilities and launch the local tile server."""

    LINUX_ACTIVATOR = r'''
#!/bin/bash
# Only an earlier tile server listening on the port (not browsers connected
# to it, nor another program using the port, such as MinIO).
for pid in $(lsof -t -iTCP:18111991 -sTCP:LISTEN 2>/dev/null); do
    ps -p "$pid" -o args= 2>/dev/null | grep -q tiles_server.py && kill "$pid" 2>/dev/null
done
cd "$(dirname "$0")"
echo "Starting MBTiles server..."
_Q2VT_PYTHON _Q2VT_UTILS --port 18111991 &
sleep 2
URL="http://localhost:18111991/viewer/viewer.html?v=10031993"
if command -v xdg-open &>/dev/null; then xdg-open "$URL"; elif command -v open &>/dev/null; then open "$URL"; fi
'''
    WINDOWS_ACTIVATOR = r'''
@echo off
rem UTF-8 from here on: the Python path below may hold non-ASCII letters
chcp 65001 > nul
rem Only an earlier tile server on the port, not another program using it (MinIO...)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 18111991 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Get-CimInstance Win32_Process -Filter ('ProcessId=' + $_.OwningProcess) } | Where-Object { $_.CommandLine -like '*tiles_server.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" || (
    rem PowerShell blocked by AppLocker or GPO: netstat for the PID, wmic for its
    rem command line. Without wmic either, an earlier server keeps the port.
    for /f "tokens=5" %%p in ('netstat -ano -p tcp ^| findstr /r /c:":18111991 .*LISTENING"') do (
        wmic process where "ProcessId=%%p" get CommandLine 2>nul | findstr /c:"tiles_server.py" >nul && taskkill /f /pid %%p >nul
    )
)
cd /d "%~dp0"
echo Starting MBTiles server...
start "MBTiles Server" "_Q2VT_PYTHON" "_Q2VT_UTILS" --port 18111991
timeout /t 2 /nobreak > nul
start "" "http://localhost:18111991/viewer/viewer.html?v=10031993"
'''

    WINDOWS_WRAPPER = r'''
Set WshShell = CreateObject("WScript.Shell")
base = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
rem Doubled quotes: cmd /c strips one pair when the path holds & ( ) ^ @
WshShell.Run "cmd /c """"" & base & "utils\activate_server.bat""""", 0
Set WshShell = Nothing
'''

    def __init__(self, extent, min_zoom: int, viewer: int, output_dir: str,
                 max_zoom: Optional[int] = None):
        self.extent = extent
        self.min_zoom = min_zoom
        # Exported zooms as the user chose them (min_zoom is offset by the viewer).
        self.max_zoom = max_zoom if max_zoom is not None else min_zoom + viewer
        self.viewer = viewer
        self.viewer_dir = join(_RESOURCES, 'ml_viewer' if viewer == 0 else 'ol_viewer')
        self.output_dir = output_dir
        self.port = _PORT  # use different port for each viewer to allow running both simultaneously

    def serve_tiles(self, launch: bool = True):
        """Copy server utilities and (optionally) launch the local tile server."""
        utils_dir = join(self.output_dir, "utils")
        makedirs(utils_dir, exist_ok=True)
        dest_activator, dest_wrapper = self._write_server_files(
            self.output_dir, utils_dir
        )
        center = self._get_center_wgs84()
        python_exe = self._get_python_exe()
        self._configure_server_placeholders(
            self.output_dir, utils_dir, dest_activator, dest_wrapper, center, python_exe
        )
        self._save_as_local_qlr()
        if launch:
            self._launch_server(self.output_dir, dest_activator, dest_wrapper)

    def _save_as_local_qlr(self):
        """ Save vector tiles as ocal styled QgsVectorLayer"""
        # Create vector tiles layer
        output = join(self.output_dir, "tiles.mbtiles")
        layer = QgsVectorTileLayer(mbtiles_uri(output), "Vector Tiles")
        layer = QgsProject.instance().addMapLayer(layer, False)
        QgsProject.instance().layerTreeRoot().insertLayer(0, layer)

        # Convert local style path to unc path so QGIS could read the sprite correctly and apply it on tiles layer
        style_dir = join(self.output_dir, 'style')
        local_style = join(style_dir, 'style.json')
        context = QgsMapBoxGlStyleConversionContext()
        if exists(join(style_dir, 'sprite')):
            sprite_img = QImage(join(style_dir, 'sprite', 'sprite@2x.png'))
            sprite_json = join(style_dir, 'sprite', 'sprite@2x.json')
            with open(sprite_json, 'r', encoding='utf-8') as handle:
                sprite_dict = json.load(handle)
            context.setSprites(sprite_img,sprite_dict)

        with open(local_style, 'r', encoding='utf-8') as f:
            style_data = json.load(f)
            if self.viewer == 0:
                # Fix style due to mismatch between maplibre and qgis glyphs rendering method
                for style_layer in style_data['layers']:
                    paint = style_layer.get('paint')
                    layout = style_layer.get('layout')                
                    # Typed multiplication: sizes may be expressions or zoom
                    # curves, where Python `list * float` raises TypeError.
                    if paint and paint.get('text-halo-width'):
                        paint['text-halo-width'] = ex.mul(
                            paint['text-halo-width'], _MAPLIBRE_LABELS_FACTOR)
                    if layout and layout.get('text-size'):
                        layout['text-size'] = ex.mul(layout['text-size'], _MAPLIBRE_LABELS_FACTOR)
                        
            json_string = json.dumps(style_data)
            converter = QgsMapBoxGlStyleConverter()
            converter.convert(json_string, context)
            if converter.renderer():
                layer.setRenderer(converter.renderer())                
            if converter.labeling():
                layer.setLabeling(converter.labeling())
    
        # Save layer as QLR
        style_dir = join(self.output_dir, "style")
        makedirs(style_dir, exist_ok=True)
        qlr_path = join(style_dir, "tiles.qlr")
        node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
        QgsLayerDefinition().exportLayerDefinition(qlr_path, [node])

    def _write_server_files(self, output_folder: str, utils_dir: str):
        """Copy/write the server, viewer, and launcher files to the output directory."""
        if platform.system() == "Windows":
            dest_activator = join(utils_dir, 'activate_server.bat')
            with open(dest_activator, "w", encoding="utf-8", newline="") as activator:
                activator.write(self.WINDOWS_ACTIVATOR)
            del activator
            dest_wrapper = join(output_folder, 'activate_server.vbs')
            with open(dest_wrapper, "w", encoding="utf-8", newline="") as wrapper_file:
                wrapper_file.write(self.WINDOWS_WRAPPER)
            del wrapper_file
        else:
            dest_wrapper = None
            dest_activator = join(output_folder, 'activate_server.sh')
            with open(dest_activator, "w", encoding="utf-8", newline="") as activator:
                activator.write(self.LINUX_ACTIVATOR)
            del activator
        copy2(_SERVER, utils_dir)
        copytree(self.viewer_dir, join(utils_dir, "viewer"), dirs_exist_ok=True)
        return dest_activator, dest_wrapper

    def _get_center_wgs84(self) -> str:
        """Return the map extent center as a '[lon, lat]' string in EPSG:4326."""
        src_crs = QgsCoordinateReferenceSystem(f"EPSG:{_EPSG_CRS}")
        dest_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(
            src_crs, dest_crs, QgsProject.instance().transformContext()
        )
        center = transform.transform(self.extent.center())
        return f"[{center.x()}, {center.y()}]"

    def _get_bounds_wgs84(self) -> str:
        """The export extent as '[[west, south], [east, north]]' (EPSG:4326)."""
        transform = QgsCoordinateTransform(
            QgsCoordinateReferenceSystem(f"EPSG:{_EPSG_CRS}"),
            QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance().transformContext())
        box = transform.transformBoundingBox(self.extent)
        return (f"[[{box.xMinimum()}, {box.yMinimum()}], "
                f"[{box.xMaximum()}, {box.yMaximum()}]]")

    def _start_zoom(self) -> float:
        """Zoom that shows the export extent (the OpenLayers viewer has no
        fitBounds placeholder: its compiled bundle takes a zoom)."""
        # In MapLibre (512 px) zooms; the OpenLayers zoom is one higher.
        return fit_zoom(self.extent.width(), self.extent.height(),
                        self.min_zoom, self.max_zoom - self.viewer)

    @staticmethod
    def _get_python_exe() -> str:
        """Return the Python executable path for the current platform."""
        system = platform.system()
        if system == "Windows":
            return join(prefix, "pythonw3.exe")
        # macOS (QGIS.app, Homebrew, conda) has it in bin/ as Linux does:
        # the first that exists.
        candidates = [join(prefix, "bin", "python3"), join(prefix, "python3"),
                      join(prefix, "bin", "python"), which("python3")]
        for candidate in candidates:
            if candidate and isfile(candidate):
                return candidate
        return candidates[0]

    def _configure_server_placeholders(
        self,
        output_folder: str,
        utils_dir: str,
        activator: str,
        wrapper: Optional[str],
        center: str,
        python_exe: str,
    ):
        """Replace template placeholders in server, viewer, and launcher files."""
        viewer = join(utils_dir, "viewer", 'viewer.html')
        self.replace_in_file(
            viewer,
            {
                # First: the numbers inserted below are not searched for it.
                "18111991": str(self.port),
                "_Q2VT_MINZOOM": str(self.min_zoom + self.viewer),
                "_Q2VT_MAXZOOM": str(self.max_zoom),
                "_Q2VT_BOUNDS": self._get_bounds_wgs84(),
                "_Q2VT_CENTER": center,
            },
        )
        self.replace_in_file(
            join(utils_dir, basename(_SERVER)),
            {"18111991": str(self.port)},
        )
        activator_dir = utils_dir if wrapper else output_folder
        server = join(utils_dir, "tiles_server.py")
        if wrapper:
            # Next to the batch file (it starts with cd /d "%~dp0"): no folder
            # name with non-ASCII letters (C:\Users\Kovács\...) in the file.
            server = "tiles_server.py"
            # Inside the batch file's double quotes only % is special.
            python_exe, server = python_exe.replace("%", "%%"), server.replace("%", "%%")
        else:
            python_exe, server = shlex.quote(python_exe), shlex.quote(server)
        self.replace_in_file(
            join(activator_dir, basename(activator)),
            {
                "18111991": str(self.port),
                "10031993": str(self.viewer + 1),
                # Last: the paths are not searched for the other placeholders.
                "_Q2VT_PYTHON": python_exe,
                "_Q2VT_UTILS": server,
            },
        )
        self.replace_in_file(
            join(output_folder, 'style', 'style.json'),
            # Only the tile URL's token: the style holds the layers' values
            # (a category or an id may be 10031993).
            {
                "?v=10031993": f"?v={self.viewer + 1}",
            },
        )
        if self.viewer_dir.endswith("ol_viewer"):
            self.replace_in_file(
                join(utils_dir, "viewer", "bundle.js"),
                {
                    "18111991": str(self.port),
                    "_Q2VT_MINZOOM": str(self._start_zoom() + self.viewer),
                    "_Q2VT_CENTER": center,
                }
            )

    @staticmethod
    def _launch_server(output_folder: str, activator: str, wrapper: Optional[str]):
        """Launch the tile server subprocess."""
        command = "wscript.exe" if wrapper else "bash"
        launch_file = wrapper if wrapper else activator
        subprocess.Popen(
            [command, join(output_folder, basename(launch_file))], cwd=output_folder
        )

    @staticmethod
    def replace_in_file(file_path: str, replacements: dict) -> None:
        """Replace all keys with their values in the given file."""
        if not exists(file_path):
            raise FileNotFoundError(file_path)
        if not replacements:
            raise ValueError("empty replacements")
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            for old, new in replacements.items():
                content = content.replace(old, new)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
        except OSError as exc:
            raise OSError(f"failed: {file_path}") from exc