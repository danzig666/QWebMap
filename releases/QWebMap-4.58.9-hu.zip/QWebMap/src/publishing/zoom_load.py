"""
zoom_load.py

How heavy the published layers are when the web map is zoomed out, and
from which zoom their features, and separately their labels, are worth
drawing (Publish window, Map tab: *Zoomed-out load…*).

A layer drawn at every scale is in the tiles of every zoom; zoomed out, one
tile holds all of it (a city's parcels: several MB the browser must load and
draw, into specks smaller than a pixel). Labels weigh even more: every label
of the tile is laid out, and only the few that do not collide can show.

The estimate reads a random sample of each layer's features inside the
export extent (sizes, vertex counts, label texts, where they are) and
counts its features there; per zoom it estimates the busiest tile (features
and bytes) and how many labels could show in it. Suggestions:

* features from the first zoom where the typical feature is at least
  ``VISIBLE_PX`` pixels across (points: where they no longer cover the tile
  as a solid mass), when the layer's busiest tile is heavy below it;
* labels from the first zoom where at least half the labels of the busiest
  tile can be placed (polygon labels also: where the typical polygon is about
  as wide as its label) and the tile has at most ``HEAVY_LABELS`` of them,
  when fewer than half of them fit, or more than that many are laid out,
  where they start now. Labels are the slowest part of the map to draw:
  every label of a tile is shaped and tested for collisions on every frame,
  even those that end up hidden.

These are the "balanced" thresholds; a speed (``SPEEDS``, the window's
slider) from "very slow" to "very fast" scales them: faster hides small
features and crowded labels from closer zooms. Only where a layer starts
changes: zoomed in, everything is shown.

A layer heavy where its features are still worth seeing is kept visible but
lighter below a zoom (LayerConfig.zoomed_out): merged per style and tile, or
as images. Merging suits polygons whose symbols are plain fills of a few
styles; outlines (the inner ones are lost), pattern and other complex fills,
effects, per-feature (data-defined) styles or many styles get images
(``merge_fit``).
"""

import math
import random
import statistics
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsExpression,
                       QgsExpressionContext, QgsExpressionContextUtils, QgsFeatureRequest,
                       QgsRectangle, QgsUnitTypes, QgsVectorLayer)

from ..core.fidelity.units import MapUnitContext

EARTH = 40075016.68557849          # Web Mercator x-extent
TILE_PX = 512                      # MapLibre draws a tile of zoom z at 512 px at map zoom z
SAMPLE = 2000                      # features read per layer
VISIBLE_PX = 2.0                   # a feature narrower than this is a speck
HEAVY_BYTES = 400 * 1024           # a layer's part of one tile that slows the map down
HEAVY_FEATURES = 15000             # features of one layer in one tile
POINT_CELL_PX = 6                  # points denser than one per 6×6 px are a solid mass
HEAVY_LABELS = 1500                # labels of one layer laid out in one tile
# Share of a layer's tile left when its features are merged per style
# (LayerConfig.zoomed_out "merged"): measured on 100 000 parcels in six
# categories, 1-4 % at zooms 10-14; images ("image") leave no vector data.
MERGED_SHARE = 0.05
MERGED_STYLES = 6                  # the styles MERGED_SHARE was measured with
MAX_MERGED_STYLES = 64             # more styles: merging joins too little
# Fill symbol layers merging keeps as they are (one colour per shape).
PLAIN_FILLS = ("SimpleFill",)


@dataclass(frozen=True)
class Speed:
    """How eager the suggestions are: ``visible_px`` the size a feature
    needs, ``heavy`` the factor on HEAVY_BYTES / HEAVY_FEATURES, ``label_fit``
    the share of labels that must fit, ``label_room`` how wide a polygon must
    be for its label (× the label), ``point_cell_px`` the point spacing."""

    name: str
    visible_px: float
    heavy: float
    label_fit: float
    label_room: float
    point_cell_px: float


SPEEDS = (
    Speed("very slow", 0.5, 4.0, 0.2, 0.3, 3),
    Speed("slow", 1.0, 2.0, 0.35, 0.45, 4),
    Speed("balanced", VISIBLE_PX, 1.0, 0.5, 0.6, POINT_CELL_PX),
    Speed("fast", 4.0, 0.5, 0.7, 0.9, 10),
    Speed("very fast", 8.0, 0.2, 0.9, 1.3, 16),
)
BALANCED = 2  # index into SPEEDS


@dataclass
class LayerLoad:
    """One layer's zoomed-out load and the suggested limits (zooms)."""

    layer_id: str
    name: str
    kind: str                       # "point" | "line" | "polygon"
    features: int
    shown_from: int                 # first zoom the layer is shown at now
    tile_features: Dict[int, int] = field(default_factory=dict)   # busiest tile, per zoom
    tile_bytes: Dict[int, int] = field(default_factory=dict)
    feature_px: float = 0.0         # typical feature size in px at zoom 0 (× 2**z)
    draws_features: bool = True     # False: labels only (no symbol)
    suggested_from: Optional[int] = None
    labels: bool = False
    labels_from: int = 0            # first zoom its labels are shown at now
    label_capacity: float = 0.0     # labels that fit in one tile
    label_share: float = 1.0        # features that have a label text
    label_bytes: Dict[int, int] = field(default_factory=dict)
    label_width_px: float = 0.0     # a typical label's width
    suggested_labels_from: Optional[int] = None
    zoomed_out: str = "full"        # how it is drawn zoomed out now: "full" | "merged" | "image"
    zoomed_out_below: Optional[int] = None
    suggested_mode: Optional[str] = None    # "merged" | "image" below suggested_mode_below
    suggested_mode_below: Optional[int] = None
    mode_needed: bool = False
    styles: int = 1                 # distinct symbols of the renderer
    merge_note: str = ""            # why merging does not suit it ("": it does)

    def drawn(self, zoom: int, mode: Optional[str] = None, below: Optional[int] = None) -> Tuple[float, float]:
        """(features, bytes) of the busiest tile at a zoom drawn in a mode
        (None: as it is set now; "full": every feature)."""
        if mode is None:
            mode, below = self.zoomed_out, self.zoomed_out_below
        count, size = self.tile_features.get(zoom, 0), self.tile_bytes.get(zoom, 0)
        if mode in ("merged", "image") and below and zoom < below:
            share = self.merged_share() if mode == "merged" else 0.0
            return count * share, size * share
        return count, size

    def heavy(self, zoom: int, factor: float = 1.0, mode: Optional[str] = None,
              below: Optional[int] = None) -> bool:
        count, size = self.drawn(zoom, mode, below)
        return size >= HEAVY_BYTES * factor or count >= HEAVY_FEATURES * factor

    def merged_share(self) -> float:
        """Share of the tile left merged: more styles, more pieces."""
        return min(1.0, MERGED_SHARE * max(1.0, self.styles / MERGED_STYLES))

    def mergeable(self) -> bool:
        return self.kind == "polygon" and not self.merge_note

    def modes(self) -> Tuple[str, ...]:
        """The zoomed-out modes for this layer: merging joins polygons only."""
        return ("full", "merged", "image") if self.kind == "polygon" else ("full", "image")

    def mode_suggested(self) -> bool:
        """The suggested mode is worth applying (_suggest): the layer is
        heavy at zooms it draws that are not hidden by the suggested limit."""
        return self.mode_needed and self.suggested_mode is not None

    def label_count(self, zoom: int) -> float:
        """Labels of the busiest tile (features with a label text)."""
        return self.tile_features.get(zoom, 0) * self.label_share

    def labels_heavy(self, zoom: int, factor: float = 1.0) -> bool:
        """So many labels in the busiest tile that laying them out is slow."""
        return self.label_count(zoom) > HEAVY_LABELS * factor

    def labels_shown(self, zoom: int) -> float:
        """Share of the busiest tile's labels that can be placed."""
        count = self.label_count(zoom)
        return 1.0 if count <= 0 else min(1.0, self.label_capacity / count)


def pixel_size(zoom: float) -> float:
    """Web Mercator units per screen pixel at a MapLibre zoom."""
    return EARTH / (TILE_PX * 2.0 ** zoom)


def zoom_scale_factor(project, extent_3857: QgsRectangle) -> float:
    """QGIS map scale of zoom 0 for this project (as the export converts):
    scale(z) = factor / 2**z."""
    crs = project.crs()
    to_wgs = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:3857"),
                                    QgsCoordinateReferenceSystem("EPSG:4326"), project)
    try:
        latitude = to_wgs.transform(extent_3857.center()).y()
    except Exception:  # noqa: BLE001 - a broken extent: the equator
        latitude = 0.0
    units = "degrees" if crs.isGeographic() else getattr(crs.mapUnits(), "name", "meters")
    context = MapUnitContext.for_project(crs.authid() in ("EPSG:3857", "EPSG:900913"), str(units),
                                         latitude)
    return context.top_scale


def scale_for_zoom(factor: float, zoom: int) -> float:
    """The web-only "hidden when zoomed out beyond" scale that shows a layer
    from ``zoom`` on (rounded down to a round number QGIS-style)."""
    exact = factor / (2.0 ** zoom)
    step = 10 ** max(0, int(math.log10(exact)) - 1)
    return float(math.floor(exact / step) * step)


def zoom_for_scale(factor: float, scale: float) -> float:
    return math.log2(factor / scale) if scale and scale > 0 else 0.0


def _kind(layer: QgsVectorLayer) -> str:
    kind = layer.geometryType()
    return {0: "point", 1: "line"}.get(int(getattr(kind, "value", kind)), "polygon")


def _label_settings(layer: QgsVectorLayer):
    """The layer's (first) label settings, or None."""
    if not layer.labelsEnabled() or layer.labeling() is None:
        return None
    labeling = layer.labeling()
    if labeling.type() == "simple":
        return labeling.settings()
    root = labeling.rootRule() if hasattr(labeling, "rootRule") else None
    for rule in (root.descendants() if root is not None else []):
        if rule.settings() is not None and rule.active():
            return rule.settings()
    return None


def _font_px(settings) -> float:
    text = settings.format()
    size, unit = float(text.size()), QgsUnitTypes.encodeUnit(text.sizeUnit())
    per_unit = {"Point": 96.0 / 72.0, "MM": 96.0 / 25.4, "Pixel": 1.0, "Inch": 96.0}.get(unit)
    return size * per_unit if per_unit else 12.0  # map units and others: a typical size


def _visible_from(layer: QgsVectorLayer, config, factor: float, min_zoom: int,
                  labels: bool = False) -> int:
    """First zoom the layer (or its labels) is shown at now."""
    from .qgis_model import layer_scale_range  # pylint: disable=import-outside-toplevel
    low, _high = layer_scale_range(layer, config)
    if labels and getattr(config, "labels_min_scale", 0):
        low = min(low, config.labels_min_scale) if low else config.labels_min_scale
    return max(min_zoom, int(math.floor(zoom_for_scale(factor, low) + 1e-6))) if low else min_zoom


def analyse_layer(layer: QgsVectorLayer, config, extent_3857: QgsRectangle, zooms: Tuple[int, int],
                  factor: float, project, seed: int = 7) -> Optional[LayerLoad]:
    """The zoomed-out load of one vector layer inside the extent, or None
    when no feature of it is there."""
    min_zoom, max_zoom = zooms
    to_layer = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:3857"), layer.crs(), project)
    to_web = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:3857"), project)
    try:
        rect = to_layer.transformBoundingBox(extent_3857)
    except Exception:  # noqa: BLE001 - outside the layer CRS's area
        return None
    request = QgsFeatureRequest().setFilterRect(rect).setNoAttributes() \
        .setFlags(QgsFeatureRequest.Flag.NoGeometry)
    ids = [feature.id() for feature in layer.getFeatures(request)]
    if not ids:
        return None
    rng = random.Random(seed)
    sample_ids = ids if len(ids) <= SAMPLE else rng.sample(ids, SAMPLE)
    settings = _label_settings(layer)
    label_expression = None
    context = QgsExpressionContext()
    context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
    if settings is not None:
        text = settings.getLabelExpression().expression() if settings.isExpression else \
            QgsExpression.quotedColumnRef(settings.fieldName)
        label_expression = QgsExpression(text)
        label_expression.prepare(context)
    sizes, vertices, centres, label_lengths = [], [], [], []
    for feature in layer.getFeatures(QgsFeatureRequest().setFilterFids(sample_ids)):
        geometry = feature.geometry()
        if geometry is None or geometry.isEmpty():
            continue
        try:
            box = to_web.transformBoundingBox(geometry.boundingBox())
        except Exception:  # noqa: BLE001
            continue
        sizes.append(max(box.width(), box.height()))
        vertices.append(max(1, geometry.constGet().nCoordinates()))
        centres.append((box.center().x(), box.center().y()))
        if label_expression is not None:
            context.setFeature(feature)
            value = label_expression.evaluate(context)
            label_lengths.append(len(str(value)) if value not in (None, "") and str(value) != "NULL" else 0)
    if not centres:
        return None
    kind = _kind(layer)
    renderer = layer.renderer()
    load = LayerLoad(layer.id(), layer.name(), kind, len(ids),
                     _visible_from(layer, config, factor, min_zoom),
                     draws_features=renderer is not None and renderer.type() != "nullSymbol")
    if kind == "polygon" and renderer is not None:
        load.styles, load.merge_note = merge_fit(renderer)
    mode, below = getattr(config, "zoomed_out", "full"), getattr(config, "zoomed_out_below", None)
    if mode in ("merged", "image") and below:
        load.zoomed_out, load.zoomed_out_below = mode, int(below)
    scale_up = len(ids) / len(centres)
    typical = statistics.median(sizes) if kind != "point" else 0.0
    load.feature_px = typical / pixel_size(0)
    mean_vertices = statistics.mean(vertices)
    if label_expression is not None:
        load.labels = True
        load.labels_from = _visible_from(layer, config, factor, min_zoom, labels=True)
        if settings.scaleVisibility and settings.minimumScale > 0:  # the labels' own QGIS limit
            load.labels_from = max(load.labels_from,
                                   int(math.floor(zoom_for_scale(factor, settings.minimumScale) + 1e-6)))
        texts = [n for n in label_lengths if n]
        load.label_share = len(texts) / len(label_lengths) if label_lengths else 0.0
        chars = statistics.mean(texts) if texts else 0.0
        font = _font_px(settings)
        width, height = 0.6 * font * chars + 4.0, 1.2 * font + 2.0
        load.label_capacity = (TILE_PX * TILE_PX) / max(1.0, width * height * 1.5)
        load.label_width_px = width
    for zoom in range(min_zoom, max_zoom + 1):
        cell = EARTH / 2.0 ** zoom
        counts: Dict[Tuple[int, int], int] = {}
        for x, y in centres:
            key = (int(math.floor(x / cell)), int(math.floor(y / cell)))
            counts[key] = counts.get(key, 0) + 1
        busiest = max(counts.values())
        # Few sampled features per tile: the sample says little; the mean
        # density of the occupied tiles is steadier.
        estimate = busiest * scale_up if busiest >= 8 else len(ids) / len(counts)
        tile_features = int(min(len(ids), max(1.0, estimate)))
        px = load.feature_px * 2 ** zoom
        if kind == "point":
            per_feature = 12.0
        else:
            per_feature = 12.0 + 3.0 * min(mean_vertices, max(2.0, 2.0 * px))
        load.tile_features[zoom] = tile_features
        load.tile_bytes[zoom] = int(tile_features * per_feature) if load.draws_features else 0
        if load.labels:
            label_bytes = 16.0 + 8.0 + (per_feature if kind == "polygon" else 0.0)  # point, text, polygon
            load.label_bytes[zoom] = int(tile_features * load.label_share * label_bytes)
    _suggest(load, max_zoom)
    return load


def _symbols(renderer) -> list:
    from qgis.core import QgsRenderContext  # pylint: disable=import-outside-toplevel
    try:
        return list(renderer.symbols(QgsRenderContext()))
    except Exception:  # noqa: BLE001 - a renderer without a symbol list
        return []


def _effect_on(item) -> bool:
    """A paint effect that changes the look (not the default stack)."""
    from qgis.core import QgsPaintEffectRegistry  # pylint: disable=import-outside-toplevel
    effect = item.paintEffect() if hasattr(item, "paintEffect") else None
    return effect is not None and effect.enabled() and not QgsPaintEffectRegistry.isDefaultStack(effect)


def _data_defined(item) -> bool:
    properties = item.dataDefinedProperties() if hasattr(item, "dataDefinedProperties") else None
    return properties is not None and properties.hasActiveProperties()


def merge_fit(renderer) -> Tuple[int, str]:
    """(distinct symbols, why merging the features of one style per tile
    does not suit this polygon renderer; "" when it does). Merging joins the
    features of one symbol into one shape: an outline is drawn only around
    the joined shape (the ones between the features are lost), a pattern or
    gradient is laid out once over it, and per-feature styles or many styles
    leave little to join."""
    from qgis.core import QgsLineSymbolLayer  # pylint: disable=import-outside-toplevel
    kind = renderer.type()
    if kind in ("invertedPolygonRenderer", "25dRenderer", "heatmapRenderer", "pointDisplacement",
                "pointCluster", "embeddedSymbol"):
        return 1, tr_note("its renderer draws more than the features' own shapes")
    symbols = _symbols(renderer)
    styles = max(1, len(symbols))
    if styles > MAX_MERGED_STYLES:
        return styles, tr_note("{} styles: too many to join").format(styles)
    for symbol in symbols:
        if _data_defined(symbol) or _effect_on(symbol):
            return styles, tr_note("data-defined or effect styling")
        for layer in symbol.symbolLayers():
            if not layer.enabled():
                continue
            if _data_defined(layer):
                return styles, tr_note("per-feature (data-defined) styling")
            if _effect_on(layer):
                return styles, tr_note("draw effects")
            if isinstance(layer, QgsLineSymbolLayer):
                return styles, tr_note("outlines (the ones between features would be lost)")
            if layer.layerType() not in PLAIN_FILLS:
                return styles, tr_note("{} fills (laid out once over the joined shape)").format(layer.layerType())
            from qgis.PyQt.QtCore import Qt  # pylint: disable=import-outside-toplevel
            pen = layer.strokeStyle() if hasattr(layer, "strokeStyle") else Qt.PenStyle.NoPen
            if pen != Qt.PenStyle.NoPen and layer.strokeColor().alpha() > 0:
                return styles, tr_note("outlines (the ones between features would be lost)")
    return styles, ""


def tr_note(text: str) -> str:
    from qgis.PyQt.QtCore import QCoreApplication  # pylint: disable=import-outside-toplevel
    return QCoreApplication.translate("ZoomLoad", text)


def _feature_visible(load: LayerLoad, zoom: int, speed: Speed = SPEEDS[BALANCED]) -> bool:
    if load.kind == "point":
        cells = (TILE_PX / speed.point_cell_px) ** 2
        return load.tile_features.get(zoom, 0) <= cells
    return load.feature_px * 2 ** zoom >= speed.visible_px


def _suggest(load: LayerLoad, max_zoom: int, speed: Speed = SPEEDS[BALANCED]) -> None:
    """Fill the suggestions (None: leave as it is)."""
    load.suggested_from = load.suggested_labels_from = None
    load.suggested_mode = load.suggested_mode_below = None
    load.mode_needed = False
    start = load.shown_from
    if load.draws_features and load.heavy(start, speed.heavy) and not _feature_visible(load, start, speed):
        for zoom in range(start + 1, max_zoom + 1):
            if _feature_visible(load, zoom, speed):
                load.suggested_from = zoom
                break
    if load.draws_features and load.heavy(start, speed.heavy, "full"):
        # Kept visible but lighter: merged (polygons) or images below the
        # first zoom every feature is light enough at (the last zoom when
        # none is); the mode already set is kept, only its zoom moves.
        below = next((z for z in range(start + 1, max_zoom + 1)
                      if not load.heavy(z, speed.heavy, "full")), max_zoom)
        if below > start and below > (load.zoomed_out_below or 0):
            load.suggested_mode = load.zoomed_out if load.zoomed_out in load.modes() and \
                load.zoomed_out != "full" else ("merged" if load.mergeable() else "image")
            load.suggested_mode_below = below
            first = load.suggested_from if load.suggested_from is not None else start
            load.mode_needed = any(load.heavy(z, speed.heavy) for z in range(first, below))
    if not load.labels:
        return
    begin = max(load.labels_from, load.suggested_from or start)
    if load.labels_shown(begin) >= speed.label_fit and not load.labels_heavy(begin, speed.heavy):
        return  # most of them fit, and not too many to lay out: no load
    width = load.label_width_px

    def placeable(zoom: int) -> bool:
        if load.labels_shown(zoom) < speed.label_fit or load.labels_heavy(zoom, speed.heavy):
            return False
        # A polygon's label inside it: the polygon about as wide as the label.
        return load.kind != "polygon" or load.feature_px * 2 ** zoom >= speed.label_room * width
    if placeable(begin):
        return
    for zoom in range(begin + 1, max_zoom + 1):
        if placeable(zoom):
            load.suggested_labels_from = zoom
            return


def resuggest(loads: List[LayerLoad], max_zoom: int, speed: int) -> None:
    """The suggestions again at another speed (index into SPEEDS)."""
    for load in loads:
        _suggest(load, max_zoom, SPEEDS[max(0, min(len(SPEEDS) - 1, speed))])


def fingerprint(project, profile, extent_3857: QgsRectangle) -> Optional[str]:
    """What ``analyse`` reads, as one string: equal strings give the same
    estimate, so a finished estimate need not run again. The view zooms,
    the extent, the project's scale factor, and for every included vector
    layer its web settings, CRS, source, filter, feature count, the file's
    modification time, its QGIS scale range and its whole style (symbology,
    labels). None (never equal) while a layer has unsaved edits."""
    import hashlib  # pylint: disable=import-outside-toplevel
    import json  # pylint: disable=import-outside-toplevel
    import os  # pylint: disable=import-outside-toplevel
    from qgis.core import QgsProviderRegistry, QgsReadWriteContext  # pylint: disable=import-outside-toplevel
    from qgis.PyQt.QtXml import QDomDocument  # pylint: disable=import-outside-toplevel
    from .profile import dumps  # pylint: disable=import-outside-toplevel
    box = extent_3857 if isinstance(extent_3857, QgsRectangle) else QgsRectangle(*extent_3857)
    parts = [int(profile.view.min_zoom), int(profile.view.max_zoom),
             [round(v, 3) for v in (box.xMinimum(), box.yMinimum(), box.xMaximum(), box.yMaximum())],
             project.crs().authid(), zoom_scale_factor(project, box)]
    for config in profile.layers:
        layer = project.mapLayer(config.layer_id)
        if not (config.included and isinstance(layer, QgsVectorLayer) and layer.isSpatial()):
            continue
        if layer.isEditable() and layer.isModified():
            return None
        path = QgsProviderRegistry.instance().decodeUri(layer.providerType(), layer.source()).get("path") or ""
        try:
            modified = os.path.getmtime(path) if path else 0
        except OSError:
            modified = 0
        document = QDomDocument()
        layer.exportNamedStyle(document, QgsReadWriteContext())
        style = hashlib.sha1(document.toString().encode("utf-8"), usedforsecurity=False).hexdigest()
        parts.append([layer.id(), layer.crs().authid(), layer.source(), layer.subsetString(),
                      layer.featureCount(), modified, layer.hasScaleBasedVisibility(),
                      layer.minimumScale(), layer.maximumScale(), style])
    configs = json.loads(dumps(profile)).get("layers", [])
    return json.dumps([parts, configs], sort_keys=True, default=str)


def analyse(project, profile, extent_3857: QgsRectangle,
            progress=None) -> Optional[Tuple[List[LayerLoad], float]]:
    """(loads of the published vector layers, busiest first; the zoom-0
    scale factor of this project). ``progress(done, total, layer name)``
    before each layer; returning False cancels (None is returned)."""
    factor = zoom_scale_factor(project, extent_3857)
    zooms = (int(profile.view.min_zoom), int(profile.view.max_zoom))
    loads = []
    layers = []
    for config in profile.layers:
        layer = project.mapLayer(config.layer_id)
        if config.included and isinstance(layer, QgsVectorLayer) and layer.isSpatial():
            layers.append((config, layer))
    for done, (config, layer) in enumerate(layers):
        if progress is not None and progress(done, len(layers), layer.name()) is False:
            return None
        load = analyse_layer(layer, config, extent_3857, zooms, factor, project)
        if load is not None:
            loads.append(load)
    loads.sort(key=lambda l: -(l.tile_bytes.get(l.shown_from, 0) + l.label_bytes.get(l.labels_from, 0)))
    return loads, factor
