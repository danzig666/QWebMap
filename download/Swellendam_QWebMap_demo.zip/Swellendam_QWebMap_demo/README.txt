QWebMap demo project: Swellendam
================================

The QGIS project behind the live demo at https://danzig666.github.io/QWebMap/
Open it in QGIS next to the web map to compare the two.

1. Unzip everything into one folder (the project finds its data next to it).
2. Install the Open Sans fonts from the fonts folder (Windows: select the .ttf files,
   right click > Install) and restart QGIS. Without them the labels use another font.
3. Open Swellendam.qgz in QGIS 3.44 or newer.

To publish it yourself, install the QWebMap plugin
(https://github.com/danzig666/QWebMap/releases/latest) and open
Web > QWebMap: Publish Web Map... The settings of the demo (popups, search, zoom range)
are saved in the project. Choose an export folder on the Destination tab, then Export locally.

Data: Swellendam from the QGIS training data (https://github.com/qgis/QGIS-Training-Data,
GPL-2.0), derived from OpenStreetMap data. Open Sans font: Apache License 2.0.
